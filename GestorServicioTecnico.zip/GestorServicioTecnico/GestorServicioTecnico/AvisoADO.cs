﻿using Microsoft.EntityFrameworkCore;
using Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatosEEF
{
    /// <summary>
    /// <autor>Javier Giménez Muñoz</autor>
    /// </summary>
    public class AvisoADO : IDisposable
    {
        // Flag: Se ha llamado a Dispose?
        bool disposed;

        public AvisoADO()
        {
            disposed = false;
        }

        // Métodos CRUD (Listar, Insertar, Actualizar, Borrar)

        /// <summary>
        /// Devuelve el listado de avisos de la base de datos
        /// </summary>
        /// <returns>Lista de avisos existentes en la base de datos</returns>
        public static IList<Aviso> Listar()
        {
            using (var context = new ServicioTecnicoContext())
            {
                var data = context.Avisos.ToList();
                return data;
            }
        }

        /// <summary>
        /// Obtiene una lista de avisos asociados a un coordinador
        /// </summary>
        /// <param name="coordinadorId">id del coordinador</param>
        /// <returns>lista de avisos</returns>
        public static IList<Aviso>? ListarPorCoordinador(int coordinadorId)
        {
            using (var context = new ServicioTecnicoContext())
            {
                var query = from st in context.Avisos
                            where st.CoordinadorId == coordinadorId
                            select st;
                var avisos = query.ToList<Aviso>();
                return avisos;
            }
        }

        /// <summary>
        /// Obtiene una lista de avisos asociados a un técnico
        /// </summary>
        /// <param name="tecnicoId">id del técnico</param>
        /// <returns>lista de avisos</returns>
        public static IList<Aviso>? ListarPorTecnico(int tecnicoId)
        {
            using (var context = new ServicioTecnicoContext())
            {
                var query = from st in context.Avisos
                            where st.TecnicoId == tecnicoId
                            select st;
                var avisos = query.ToList<Aviso>();
                return avisos;
            }
        }

        /// <summary>
        /// Obtiene una lista de avisos asociados a un cliente
        /// </summary>
        /// <param name="clienteId">id del cliente</param>
        /// <returns></returns>
        public static IList<Aviso>? ListarPorCliente(long clienteId)
        {
            using (var context = new ServicioTecnicoContext())
            {
                var query = from st in context.Avisos
                            where st.ClienteId == clienteId
                            select st;
                var avisos = query.ToList<Aviso>();
                return avisos;
            }
        }

        /// <summary>
        /// Obtiene una lista de avisos asociados a un producto
        /// </summary>
        /// <param name="numeroSerieProducto">número de serie del producto</param>
        /// <returns>lista de avisos</returns>
        public static IList<Aviso>? ListarPorProducto(string numeroSerieProducto)
        {
            using (var context = new ServicioTecnicoContext())
            {
                var query = from st in context.Avisos
                            where st.NumeroSerieProducto == numeroSerieProducto
                            select st;
                var avisos = query.ToList<Aviso>();
                return avisos;
            }
        }

        /// <summary>
        /// Obtiene un aviso de la base de datos a partir de su ID
        /// </summary>
        /// <param name="ID">id aviso</param>
        /// <returns>aviso o null si no existe el ID</returns>
        public static Aviso? Listar(long ID)
        {
            using (var context = new ServicioTecnicoContext())
            {
                var query = from st in context.Avisos
                            where st.Id == ID
                            select st;

                var aviso = query.FirstOrDefault<Aviso>();
                return aviso;
            }
        }

        /// <summary>
        /// Inserta un aviso en la base de datos
        /// </summary>
        /// <param name="dato">aviso a insertar en la base de datos</param>
        public static void Insertar(Aviso dato)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(dato).State = EntityState.Added;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Actualiza un aviso en la base de datos
        /// </summary>
        /// <param name="modificado">aviso a modificar en la base de datos</param>
        public static void Actualizar(Aviso modificado)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(modificado).State = EntityState.Modified;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Borra un aviso de la base de datos
        /// </summary>
        /// <param name="dato">aviso a borrar de la base de datos</param>
        public static void Borrar(Aviso dato)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(dato).State = EntityState.Deleted;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Public implementation of Dispose pattern callable by consumers.
        /// </summary>
        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Protected implementation of Dispose pattern.
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Liberar recursos no manejados como ficheros, conexiones a bd, etc.
            }

            disposed = true;
        }
    }
}
