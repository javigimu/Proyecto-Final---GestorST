﻿using Microsoft.EntityFrameworkCore;
using Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatosEEF
{
    /// <summary>
    /// <autor>Javier Giménez Muñoz</autor>
    /// </summary>
    public class InventarioTecnicoADO : IDisposable
    {
        // Flag: Se ha llamado a Dispose?
        bool disposed;

        public InventarioTecnicoADO()
        {
            disposed = false;
        }

        // Métodos CRUD (Listar, Insertar, Actualizar, Borrar)

        /// <summary>
        /// Devuelve el listado con el inventario de los técnicos de la base de datos
        /// </summary>
        /// <returns>Lista de inventarios existentes en la base de datos</returns>
        public static IList<InventarioTecnico> Listar()
        {
            using (var context = new ServicioTecnicoContext())
            {
                var data = context.InventarioTecnicos.ToList();
                return data;
            }
        }

        /// <summary>
        /// Listado de inventarios filtradas por técnico
        /// </summary>
        /// <param name="tecnicoId">id del técnico</param>
        /// <returns>lista de inventarios por técnico</returns>
        public static IList<InventarioTecnico>? ListarPorTecnico(int tecnicoId)
        {
            using (var context = new ServicioTecnicoContext())
            {
                var query = from st in context.InventarioTecnicos
                            where st.IdTecnico == tecnicoId
                            select st;

                var inventario = query.ToList<InventarioTecnico>();
                return inventario;
            }
        }

        /// <summary>
        /// Listado de inventarios filtrados por pieza
        /// </summary>
        /// <param name="piezaId">id de la pieza</param>
        /// <returns>lista de inventaraios por pieza</returns>
        public static IList<InventarioTecnico>? ListarPorPieza(long piezaId)
        {
            using (var context = new ServicioTecnicoContext())
            {
                var query = from st in context.InventarioTecnicos
                            where st.IdPieza == piezaId
                            select st;

                var inventario = query.ToList<InventarioTecnico>();
                return inventario;
            }
        }

        /// <summary>
        /// Obtiene un inventario de la base de datos a partir de su clave primaria (idPieza, idTecnico)
        /// </summary>
        /// <param name="ID">id inventario</param>
        /// <returns>avería o null si no existe el ID</returns>
        public static InventarioTecnico? Listar(long idPieza, int idTecnico)
        {
            using (var context = new ServicioTecnicoContext())
            {
                var query = from st in context.InventarioTecnicos
                            where st.IdPieza == idPieza && st.IdTecnico == idTecnico
                            select st;

                var inventario = query.FirstOrDefault<InventarioTecnico>();
                return inventario;
            }
        }

        /// <summary>
        /// Inserta un inventario en la base de datos
        /// </summary>
        /// <param name="dato">inventario a insertar en la base de datos</param>
        public static void Insertar(InventarioTecnico dato)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(dato).State = EntityState.Added;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Actualiza un inventario en la base de datos
        /// </summary>
        /// <param name="modificado">iventario a modificar en la base de datos</param>
        public static void Actualizar(InventarioTecnico modificado)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(modificado).State = EntityState.Modified;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Borra un iventario de la base de datos
        /// </summary>
        /// <param name="dato">iventario a borrar de la base de datos</param>
        public static void Borrar(InventarioTecnico dato)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(dato).State = EntityState.Deleted;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Public implementation of Dispose pattern callable by consumers.
        /// </summary>
        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Protected implementation of Dispose pattern.
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Liberar recursos no manejados como ficheros, conexiones a bd, etc.
            }

            disposed = true;
        }
    }
}
