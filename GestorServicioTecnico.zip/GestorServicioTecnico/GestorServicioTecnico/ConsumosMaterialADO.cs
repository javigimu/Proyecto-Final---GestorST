﻿using Microsoft.EntityFrameworkCore;
using Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatosEEF
{
    /// <summary>
    /// <autor>Javier Giménez Muñoz</autor>
    /// </summary>
    public class ConsumosMaterialADO : IDisposable
    {
        // Flag: Se ha llamado a Dispose?
        bool disposed;

        public ConsumosMaterialADO()
        {
            disposed = false;
        }

        // Métodos CRUD (Listar, Insertar, Actualizar, Borrar)

        /// <summary>
        /// Devuelve el listado de consumos de material de la base de datos
        /// </summary>
        /// <returns>Lista de consumos de material existentes en la base de datos</returns>
        public static IList<ConsumosMaterial> Listar()
        {
            using (var context = new ServicioTecnicoContext())
            {
                var data = context.ConsumosMaterials.ToList();
                return data;
            }
        }

        /// <summary>
        /// Obtiene un consumo de material de la base de datos a partir de su ID
        /// </summary>
        /// <param name="ID">id consumo de material</param>
        /// <returns>consumo de material o null si no existe el ID</returns>
        public static ConsumosMaterial? Listar(int tecnicoId, long piezaId, long avisoId)
        {
            using (var context = new ServicioTecnicoContext())
            {
                var query = from st in context.ConsumosMaterials
                            where st.TecnicoId == tecnicoId && st.PiezaId == piezaId 
                                    && st.AvisoId == avisoId
                            select st;

                var consumoMaterial = query.FirstOrDefault<ConsumosMaterial>();
                return consumoMaterial;
            }
        }

        /// <summary>
        /// Lista todos los consumos de material asocidados a un aviso
        /// </summary>
        /// <param name="avisoId">id del aviso</param>
        /// <returns>lista con todos los consumos de material de un aviso</returns>
        public static IList<ConsumosMaterial>? ListarPorAviso(long avisoId)
        {
            using (var context = new ServicioTecnicoContext())
            {
                var query = from st in context.ConsumosMaterials
                            where st.AvisoId == avisoId
                            select st;

                var consumosMaterial = query.ToList<ConsumosMaterial>();
                return consumosMaterial;
            }
        }

        /// <summary>
        /// Lista todos los consumos de material asocidados a un técnico
        /// </summary>
        /// <param name="avisoId">id del técnico/param>
        /// <returns>lista con todos los consumos de material de un técnico</returns>
        public static IList<ConsumosMaterial>? ListarPorTecnico(int tecnicoId)
        {
            using (var context = new ServicioTecnicoContext())
            {
                var query = from st in context.ConsumosMaterials
                            where st.TecnicoId == tecnicoId
                            select st;

                var consumosMaterial = query.ToList<ConsumosMaterial>();
                return consumosMaterial;
            }
        }

        /// <summary>
        /// Lista todos los consumos de material asocidados a una pieza
        /// </summary>
        /// <param name="avisoId">id de la pieza</param>
        /// <returns>lista con todos los consumos de material de una pieza</returns>
        public static IList<ConsumosMaterial>? ListarPorPieza(long piezaId)
        {
            using (var context = new ServicioTecnicoContext())
            {
                var query = from st in context.ConsumosMaterials
                            where st.PiezaId == piezaId
                            select st;

                var consumosMaterial = query.ToList<ConsumosMaterial>();
                return consumosMaterial;
            }
        }

        /// <summary>
        /// Inserta un consumo de material en la base de datos
        /// </summary>
        /// <param name="dato">consumo de material a insertar en la base de datos</param>
        public static void Insertar(ConsumosMaterial dato)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(dato).State = EntityState.Added;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Actualiza un consumo de material en la base de datos
        /// </summary>
        /// <param name="modificado">consumo de material a modificar en la base de datos</param>
        public static void Actualizar(ConsumosMaterial modificado)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(modificado).State = EntityState.Modified;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Borra un consumo de material de la base de datos
        /// </summary>
        /// <param name="dato">consumo de material a borrar de la base de datos</param>
        public static void Borrar(ConsumosMaterial dato)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(dato).State = EntityState.Deleted;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Public implementation of Dispose pattern callable by consumers.
        /// </summary>
        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Protected implementation of Dispose pattern.
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Liberar recursos no manejados como ficheros, conexiones a bd, etc.
            }

            disposed = true;
        }

    }
}