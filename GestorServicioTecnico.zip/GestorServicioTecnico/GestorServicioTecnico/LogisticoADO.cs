﻿using Microsoft.EntityFrameworkCore;
using Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatosEEF
{
    /// <summary>
    /// <autor>Javier Giménez Muñoz</autor>
    /// </summary>
    public class LogisticoADO : IDisposable
    {
        // Flag: Se ha llamado a Dispose?
        bool disposed;

        public LogisticoADO()
        {
            disposed = false;
        }

        // Métodos CRUD (Listar, Insertar, Actualizar, Borrar)

        /// <summary>
        /// Devuelve el listado de logísticos de la base de datos
        /// </summary>
        /// <returns>Lista de logísticos existentes en la base de datos</returns>
        public static IList<Logistico> Listar()
        {
            using (var context = new ServicioTecnicoContext())
            {
                var data = context.Logisticos.ToList();
                return data;
            }
        }

        /// <summary>
        /// Obtiene un logístico de la base de datos a partir de su ID
        /// </summary>
        /// <param name="ID">id logístico</param>
        /// <returns>logístico o null si no existe el ID</returns>
        public static Logistico? Listar(int ID)
        {
            using (var context = new ServicioTecnicoContext())
            {
                var query = from st in context.Logisticos
                            where st.Id == ID
                            select st;

                var logistico = query.FirstOrDefault<Logistico>();
                return logistico;
            }
        }

        /// <summary>
        /// Inserta un logístico en la base de datos
        /// </summary>
        /// <param name="dato">logístico a insertar en la base de datos</param>
        public static void Insertar(Logistico dato)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(dato).State = EntityState.Added;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Actualiza un logístico en la base de datos
        /// </summary>
        /// <param name="modificado">logístico a modificar en la base de datos</param>
        public static void Actualizar(Logistico modificado)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(modificado).State = EntityState.Modified;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Borra un logístico de la base de datos
        /// </summary>
        /// <param name="dato">logístico a borrar de la base de datos</param>
        public static void Borrar(Logistico dato)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(dato).State = EntityState.Deleted;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Public implementation of Dispose pattern callable by consumers.
        /// </summary>
        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Protected implementation of Dispose pattern.
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Liberar recursos no manejados como ficheros, conexiones a bd, etc.
            }

            disposed = true;
        }
    }
}
