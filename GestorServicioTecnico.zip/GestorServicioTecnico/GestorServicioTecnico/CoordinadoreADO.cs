﻿using Microsoft.EntityFrameworkCore;
using Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatosEEF
{
    /// <summary>
    /// <autor>Javier Giménez Muñoz</autor>
    /// </summary>
    public class CoordinadoreADO : IDisposable
    {
        // Flag: Se ha llamado a Dispose?
        bool disposed;

        public CoordinadoreADO()
        {
            disposed = false;
        }

        // Métodos CRUD (Listar, Insertar, Actualizar, Borrar)

        /// <summary>
        /// Devuelve el listado de coordinadores de la base de datos
        /// </summary>
        /// <returns>Lista de coordinadores existentes en la base de datos</returns>
        public static IList<Coordinadore> Listar()
        {
            using (var context = new ServicioTecnicoContext())
            {
                var data = context.Coordinadores.ToList();
                return data;
            }
        }

        /// <summary>
        /// Obtiene un coordinador de la base de datos a partir de su ID
        /// </summary>
        /// <param name="ID">id coordinador</param>
        /// <returns>coordinador o null si no existe el ID</returns>
        public static Coordinadore? Listar(int ID)
        {
            using (var context = new ServicioTecnicoContext())
            {
                var query = from st in context.Coordinadores
                            where st.Id == ID
                            select st;

                var coordinador = query.FirstOrDefault<Coordinadore>();
                return coordinador;
            }
        }

        /// <summary>
        /// Inserta un coordinador en la base de datos
        /// </summary>
        /// <param name="dato">coordinador a insertar en la base de datos</param>
        public static void Insertar(Coordinadore dato)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(dato).State = EntityState.Added;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Actualiza un coordinador en la base de datos
        /// </summary>
        /// <param name="modificado">coordinador a modificar en la base de datos</param>
        public static void Actualizar(Coordinadore modificado)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(modificado).State = EntityState.Modified;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Borra un coordinador de la base de datos
        /// </summary>
        /// <param name="dato">coordinador a borrar de la base de datos</param>
        public static void Borrar(Coordinadore dato)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(dato).State = EntityState.Deleted;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Public implementation of Dispose pattern callable by consumers.
        /// </summary>
        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Protected implementation of Dispose pattern.
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Liberar recursos no manejados como ficheros, conexiones a bd, etc.
            }

            disposed = true;
        }
    }
}
