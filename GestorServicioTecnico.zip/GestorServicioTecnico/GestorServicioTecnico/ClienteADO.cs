﻿using Microsoft.EntityFrameworkCore;
using Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatosEEF
{
    /// <summary>
    /// <autor>Javier Giménez Muñoz</autor>
    /// </summary>
    public class ClienteADO : IDisposable
    {
        // Flag: Se ha llamado a Dispose?
        bool disposed;

        public ClienteADO()
        {
            disposed = false;
        }

        // Métodos CRUD (Listar, Insertar, Actualizar, Borrar)

        /// <summary>
        /// Devuelve el listado de clientes de la base de datos
        /// </summary>
        /// <returns>Lista de clientes existentes en la base de datos</returns>
        public static IList<Cliente> Listar()
        {
            using (var context = new ServicioTecnicoContext())
            {
                var data = context.Clientes.ToList();
                return data;
            }
        }

        /// <summary>
        /// Obtiene un cliente de la base de datos a partir de su ID
        /// </summary>
        /// <param name="ID">id cliente</param>
        /// <returns>cliente o null si no existe el ID</returns>
        public static Cliente? Listar(long ID)
        {
            using (var context = new ServicioTecnicoContext())
            {
                var query = from st in context.Clientes
                            where st.Id == ID
                            select st;

                var cliente = query.FirstOrDefault<Cliente>();
                return cliente;
            }
        }

        /// <summary>
        /// Inserta un cliente en la base de datos
        /// </summary>
        /// <param name="dato">cliente a insertar en la base de datos</param>
        public static void Insertar(Cliente dato)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(dato).State = EntityState.Added;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Actualiza un cliente en la base de datos
        /// </summary>
        /// <param name="modificado">cliente a modificar en la base de datos</param>
        public static void Actualizar(Cliente modificado)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(modificado).State = EntityState.Modified;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Borra un cliente de la base de datos
        /// </summary>
        /// <param name="dato">cliente a borrar de la base de datos</param>
        public static void Borrar(Cliente dato)
        {
            using (var context = new ServicioTecnicoContext())
            {
                context.Entry(dato).State = EntityState.Deleted;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Public implementation of Dispose pattern callable by consumers.
        /// </summary>
        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Protected implementation of Dispose pattern.
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Liberar recursos no manejados como ficheros, conexiones a bd, etc.
            }

            disposed = true;
        }
    }
}
