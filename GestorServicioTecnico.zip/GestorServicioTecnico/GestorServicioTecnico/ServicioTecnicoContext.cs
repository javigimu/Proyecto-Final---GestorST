﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Modelos;

namespace DatosEEF;

public partial class ServicioTecnicoContext : DbContext
{
    public ServicioTecnicoContext()
    {
    }

    public ServicioTecnicoContext(DbContextOptions<ServicioTecnicoContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Averia> Averias { get; set; }

    public virtual DbSet<Aviso> Avisos { get; set; }

    public virtual DbSet<Cliente> Clientes { get; set; }

    public virtual DbSet<ConsumosMaterial> ConsumosMaterials { get; set; }

    public virtual DbSet<Coordinadore> Coordinadores { get; set; }

    public virtual DbSet<Empleado> Empleados { get; set; }

    public virtual DbSet<InventarioTecnico> InventarioTecnicos { get; set; }

    public virtual DbSet<Logistico> Logisticos { get; set; }

    public virtual DbSet<Pieza> Piezas { get; set; }

    public virtual DbSet<Producto> Productos { get; set; }

    public virtual DbSet<Reparacione> Reparaciones { get; set; }

    public virtual DbSet<Tecnico> Tecnicos { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseNpgsql("Host=servidorgestorst.postgres.database.azure.com;Database=servicio_tecnico;Username=servicio_tecnico;Password=STaccesobd1");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasPostgresEnum("enum_estado", new[] { "abierto", "cerrado", "desplazamiento", "reparacion" });

        modelBuilder.Entity<Averia>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("averias_pkey");

            entity.Property(e => e.Descripcion).IsFixedLength();
            entity.Property(e => e.Estado).IsFixedLength();
            entity.Property(e => e.FechaAveria).HasDefaultValueSql("CURRENT_DATE");

            entity.HasOne(d => d.Pieza).WithMany(p => p.Averia)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_averias_piezas");

            entity.HasOne(d => d.Tecnico).WithMany(p => p.Averia)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_averias_tecnicos");
        });

        modelBuilder.Entity<Aviso>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("avisos_pkey");

            entity.Property(e => e.CierreConfirmado).HasDefaultValueSql("false");
            entity.Property(e => e.Descripcion).IsFixedLength();
            entity.Property(e => e.Estado).IsFixedLength();
            entity.Property(e => e.FechaEntrada).HasDefaultValueSql("CURRENT_DATE");
            entity.Property(e => e.NumeroSerieProducto).IsFixedLength();

            entity.HasOne(d => d.Cliente).WithMany(p => p.Avisos)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_avisos_clientes");

            entity.HasOne(d => d.Coordinador).WithMany(p => p.Avisos)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_avisos_coordindadores");

            entity.HasOne(d => d.NumeroSerieProductoNavigation).WithMany(p => p.Avisos)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_avisos_productos");

            entity.HasOne(d => d.Tecnico).WithMany(p => p.Avisos).HasConstraintName("fk_avisos_tecnicos");
        });

        modelBuilder.Entity<Cliente>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("clientes_pkey");

            entity.Property(e => e.Ciudad).IsFixedLength();
            entity.Property(e => e.Direccion).IsFixedLength();
            entity.Property(e => e.Mail).IsFixedLength();
            entity.Property(e => e.Nombre).IsFixedLength();
            entity.Property(e => e.Provincia).IsFixedLength();
            entity.Property(e => e.Telefono).IsFixedLength();
        });

        modelBuilder.Entity<ConsumosMaterial>(entity =>
        {
            entity.HasKey(e => new { e.TecnicoId, e.PiezaId, e.AvisoId }).HasName("consumos_material_pkey");

            entity.Property(e => e.Anotaciones).IsFixedLength();
            entity.Property(e => e.Cantidad).HasDefaultValueSql("1");
            entity.Property(e => e.FechaConsumo).HasDefaultValueSql("CURRENT_DATE");

            entity.HasOne(d => d.Aviso).WithMany(p => p.ConsumosMaterials)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_consumos_material_avisos");

            entity.HasOne(d => d.Pieza).WithMany(p => p.ConsumosMaterials)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_consumos_material_piezas");

            entity.HasOne(d => d.Tecnico).WithMany(p => p.ConsumosMaterials)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_consumos_material_tecnicos");
        });

        modelBuilder.Entity<Coordinadore>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("pk_empleado_coordinador");

            entity.Property(e => e.Id).HasDefaultValueSql("nextval('empleado_id_seq'::regclass)");
            entity.Property(e => e.Apellidos).IsFixedLength();
            entity.Property(e => e.Ciudad).IsFixedLength();
            entity.Property(e => e.CodigoPostal).IsFixedLength();
            entity.Property(e => e.Direccion).IsFixedLength();
            entity.Property(e => e.Formacion).IsFixedLength();
            entity.Property(e => e.Nif).IsFixedLength();
            entity.Property(e => e.Nombre).IsFixedLength();
            entity.Property(e => e.Pais).IsFixedLength();
            entity.Property(e => e.Password)
                .HasDefaultValueSql("'password'::bpchar")
                .IsFixedLength();
            entity.Property(e => e.Provincia).IsFixedLength();
            entity.Property(e => e.Telefono).IsFixedLength();
        });

        modelBuilder.Entity<Empleado>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("empleado_pkey");

            entity.Property(e => e.Id).HasDefaultValueSql("nextval('empleado_id_seq'::regclass)");
            entity.Property(e => e.Apellidos).IsFixedLength();
            entity.Property(e => e.Ciudad).IsFixedLength();
            entity.Property(e => e.CodigoPostal).IsFixedLength();
            entity.Property(e => e.Direccion).IsFixedLength();
            entity.Property(e => e.Formacion).IsFixedLength();
            entity.Property(e => e.Nif).IsFixedLength();
            entity.Property(e => e.Nombre).IsFixedLength();
            entity.Property(e => e.Pais).IsFixedLength();
            entity.Property(e => e.Password)
                .HasDefaultValueSql("'password'::bpchar")
                .IsFixedLength();
            entity.Property(e => e.Provincia).IsFixedLength();
            entity.Property(e => e.Telefono).IsFixedLength();
        });

        modelBuilder.Entity<InventarioTecnico>(entity =>
        {
            entity.HasKey(e => new { e.IdPieza, e.IdTecnico }).HasName("inventario_pkey");

            entity.Property(e => e.Cantidad).HasDefaultValueSql("1");

            entity.HasOne(d => d.IdPiezaNavigation).WithMany(p => p.InventarioTecnicos)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_inventario_pieza");

            entity.HasOne(d => d.IdTecnicoNavigation).WithMany(p => p.InventarioTecnicos)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_inventario_tecnico");
        });

        modelBuilder.Entity<Logistico>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("pk_empleado_logistico");

            entity.Property(e => e.Id).HasDefaultValueSql("nextval('empleado_id_seq'::regclass)");
            entity.Property(e => e.Apellidos).IsFixedLength();
            entity.Property(e => e.Ciudad).IsFixedLength();
            entity.Property(e => e.CodigoPostal).IsFixedLength();
            entity.Property(e => e.Direccion).IsFixedLength();
            entity.Property(e => e.Formacion).IsFixedLength();
            entity.Property(e => e.Nif).IsFixedLength();
            entity.Property(e => e.Nombre).IsFixedLength();
            entity.Property(e => e.Pais).IsFixedLength();
            entity.Property(e => e.Password)
                .HasDefaultValueSql("'password'::bpchar")
                .IsFixedLength();
            entity.Property(e => e.Provincia).IsFixedLength();
            entity.Property(e => e.Telefono).IsFixedLength();
        });

        modelBuilder.Entity<Pieza>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("pieza_pkey");

            entity.Property(e => e.Id).HasDefaultValueSql("nextval('pieza_id_seq'::regclass)");
            entity.Property(e => e.Descripcion).IsFixedLength();
            entity.Property(e => e.Nombre).IsFixedLength();
            entity.Property(e => e.Stock).HasDefaultValueSql("1");
        });

        modelBuilder.Entity<Producto>(entity =>
        {
            entity.HasKey(e => e.NumeroSerie).HasName("producto_pkey");

            entity.Property(e => e.NumeroSerie).IsFixedLength();
            entity.Property(e => e.Ciudad).IsFixedLength();
            entity.Property(e => e.Direccion).IsFixedLength();
            entity.Property(e => e.Fabricante).IsFixedLength();
            entity.Property(e => e.Modelo).IsFixedLength();
            entity.Property(e => e.Nombre).IsFixedLength();
            entity.Property(e => e.Provincia).IsFixedLength();

            entity.HasOne(d => d.Cliente).WithMany(p => p.Productos)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_productos_clientes");
        });

        modelBuilder.Entity<Reparacione>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("reparaciones_pkey");

            entity.Property(e => e.Descripcion).IsFixedLength();

            entity.HasOne(d => d.Pieza).WithMany(p => p.Reparaciones)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_reparaciones_piezas");

            entity.HasOne(d => d.Tecnico).WithMany(p => p.Reparaciones)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_reparaciones_tecnicos");
        });

        modelBuilder.Entity<Tecnico>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("pk_empleado_tecnico");

            entity.Property(e => e.Id).HasDefaultValueSql("nextval('empleado_id_seq'::regclass)");
            entity.Property(e => e.Apellidos).IsFixedLength();
            entity.Property(e => e.Ciudad).IsFixedLength();
            entity.Property(e => e.CodigoPostal).IsFixedLength();
            entity.Property(e => e.Direccion).IsFixedLength();
            entity.Property(e => e.Especialista).HasDefaultValueSql("false");
            entity.Property(e => e.Formacion).IsFixedLength();
            entity.Property(e => e.Nif).IsFixedLength();
            entity.Property(e => e.Nombre).IsFixedLength();
            entity.Property(e => e.Pais).IsFixedLength();
            entity.Property(e => e.Password)
                .HasDefaultValueSql("'password'::bpchar")
                .IsFixedLength();
            entity.Property(e => e.Provincia).IsFixedLength();
            entity.Property(e => e.Telefono).IsFixedLength();
            entity.Property(e => e.VehiculoEmpresa).HasDefaultValueSql("false");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
