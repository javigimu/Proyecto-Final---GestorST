﻿using Modelos;
using Negocio;
using PresentacionWPF.Dialogos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PresentacionWPF
{
    /// <summary>
    /// Ventana principal de login de empleado
    /// </summary>
    public partial class MainWindow : Window
    {
        Empleado? empleado;
        //ICollection<Empleado>? empleados = Gestion.ListarEmpleados();
        ICollection<Empleado>? empleados = Gestion.ListarEmpleadosEnActivo();
        string password = "";

        /// <summary>
        /// Constructor principal
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            empleado = new Empleado();
            this.DataContext = empleado;
        }

        /// <summary>
        /// Reacciona a la pulsación del botón Entrar del login
        /// </summary>
        /// <param name="sender">btnEntrar</param>
        /// <param name="e">evento click</param>
        private void btnEntrar_Click(object sender, RoutedEventArgs e)
        {
            AccederEmpleado();
        }

        /// <summary>
        /// Verifica que la entrada del empleado es correcta y si es así, abre el formulario principal
        /// </summary>
        private void AccederEmpleado()
        {
            if (VerificarCamposValidados())
            {
                // si no se ha modificado la contraseña, se le muestra un formulario para cambiarla
                if (empleado != null)
                {

                    if (passwordBox.Password == "password")
                    {
                        SolicitudNuevoPassword solicitudPassword = new SolicitudNuevoPassword();
                        solicitudPassword.ShowDialog();
                        if (solicitudPassword.getPasswordOk())
                        {
                            password = solicitudPassword.getPassword();
                            empleado.Password = password;
                            Gestion.ActualizarEmpleado(empleado);
                            AbrirFormularioPrincipal();
                        }
                    }
                    else
                        AbrirFormularioPrincipal();
                }
            }
        }

        /// <summary>
        /// Abre el formulario principal, dependiendo de la categoría del empleado
        /// </summary>
        private void AbrirFormularioPrincipal()
        {
            ICollection<Coordinadore>? coordinadores = Gestion.ListarCoordinadores();
            ICollection<Logistico>? logisticos = Gestion.ListarLogisticos();
            ICollection<Tecnico>? tecnicos = Gestion.ListarTecnicos();
            int idEmpleado = Convert.ToInt32(tbIdEmpleado.Text.Trim());

            if (coordinadores != null && Gestion.EmpleadoEsCoordinador(coordinadores, idEmpleado))
            {
                Application.Current.MainWindow = new FormularioPrincipal(Gestion.ListarCoordinador(idEmpleado)!);
                Application.Current.MainWindow.Show();
                this.Close();

            }
            else if (logisticos != null && Gestion.EmpleadoEsLogistico(logisticos, idEmpleado))
            {
                Application.Current.MainWindow = new FormularioPrincipal(Gestion.ListarLogistico(idEmpleado)!);
                Application.Current.MainWindow.Show();
                this.Close();
            }
            else if (tecnicos != null && Gestion.EmpleadoEsTecnico(tecnicos, idEmpleado))
            {
                Application.Current.MainWindow = new FormularioPrincipal(Gestion.ListarTecnico(idEmpleado)!);
                Application.Current.MainWindow.Show();
                this.Close();
            }
        }

        /// <summary>
        /// Vacía el contenido de los campos
        /// </summary>
        private void VaciarCampos()
        {
            tbIdEmpleado.Clear();
            passwordBox.Clear();
        }

        /// <summary>
        /// Valida que el id de usuario y la contraseña sean correctos
        /// </summary>
        private bool VerificarCamposValidados()
        {
            bool validacionOk = false;
            MensajeConfirmacion dialogoMensaje;
            if (empleados != null)
            {
                if (tbIdEmpleado.Text.Length == 0)
                {
                    dialogoMensaje = new MensajeConfirmacion("Debes introducir el id de empleado");
                    dialogoMensaje.ShowDialog();
                }
                else if (passwordBox.Password.Length == 0)
                {
                    dialogoMensaje = new MensajeConfirmacion("Debes introducir la contraseña");
                    dialogoMensaje.ShowDialog();
                }
                else if (!Validation.GetHasError(tbIdEmpleado))
                    validacionOk = true;

                if (validacionOk) 
                {
                    int idEmpleado = tbIdEmpleado.Text.Trim() == "" ? -1 : Convert.ToInt32(tbIdEmpleado.Text.Trim());
                    if (Gestion.ComprobarEmpleadoExiste(empleados, idEmpleado))
                    {
                        empleado = Gestion.ListarEmpleado(idEmpleado);
                        if (empleado != null && empleado.Password!.Trim() == passwordBox.Password)
                            validacionOk = true;
                        else
                        {
                            validacionOk = false;
                            dialogoMensaje = new MensajeConfirmacion("el password es incorrecto");
                            dialogoMensaje.ShowDialog();
                            passwordBox.Clear();
                        }                            
                    }
                    else
                    {
                        validacionOk = false;
                        dialogoMensaje = new MensajeConfirmacion("el id empleado no existe");
                        dialogoMensaje.ShowDialog();
                        VaciarCampos();
                    }
                }
            }
            else
            {                
                dialogoMensaje = new MensajeConfirmacion(
                    "No hay empleados en la base de datos");
                if (dialogoMensaje.ShowDialog() == true)
                    Close();
            }
            return validacionOk;
        }

        /// <summary>
        /// Reacciona a la pulsación del botón Salir del login
        /// </summary>
        /// <param name="sender">btnSalir</param>
        /// <param name="e">evento click</param>
        private void btnSalir_Click(object sender, RoutedEventArgs e)
        {
            ConfirmacionSalida dialogoConfirmacion = new ConfirmacionSalida(
                "Se va a cerrar la aplicación, ¿Continuar?");
            if (dialogoConfirmacion.ShowDialog() == true)
                Close();
        }

        /// <summary>
        /// Impide que el usuario introduzca un dato no numérico
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void IdEmpleado_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Utils.ValidarTextoEsNumero(e.Text))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Acción que se realiza una vez cargados todos los datos de la ventana
        /// </summary>
        /// <param name="sender">Window</param>
        /// <param name="e">evento loaded</param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            VaciarCampos();
        }

        /// <summary>
        /// Responde a la pulsación de una tecla, para validar el empleado al pulsar Enter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                AccederEmpleado();
            }
        }
    }
}
