﻿using Modelos;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace PresentacionWPF
{
    /// <summary>
    /// Clase con utilidades
    /// </summary>
    public class Utils
    {
        /// <summary>
        /// Valida si un texto está formado sólo por números
        /// </summary>
        /// <param name="texto">text a validar</param>
        /// <returns>true si el texto está formado sólo por números</returns>
        public static bool ValidarTextoEsNumero(string texto)
        {
            Regex regex = new Regex("^[0-9]+$");
            return regex.IsMatch(texto);
        }

        /// <summary>
        /// Valida si un texto cumple la norma sobre la contraseña.
        /// Debe tener entre 8 y 12 caracteres, como mínimo una mayúscula, una minúscula y un dígito
        /// </summary>
        /// <param name="texto"></param>
        /// <returns></returns>
        public static bool ValidarPassword(string texto)
        {
            Regex regex = new Regex("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{6,15}$");
            return regex.IsMatch(texto);
        }


        /// <summary>
        /// Muestra un byte[] con el contenido de una foto en el campo Image que se le pasa como parámetro
        /// </summary>
        /// <param name="imagen">campo imagen donde se ubicará la foto</param>
        /// <param name="foto">foto en byte[] a mostrar en un Image</param>
        /// <returns>campo Image con la foto</returns>
        public static Image MostrarFotoSeleccionada(Image imagen, byte[] foto)
        {
            BitmapImage bi;
            using (var ms = new MemoryStream(foto))
            {
                bi = new BitmapImage();
                bi.BeginInit();
                bi.CreateOptions = BitmapCreateOptions.None;
                bi.CacheOption = BitmapCacheOption.OnLoad;
                bi.StreamSource = ms;
                bi.EndInit();
            }
            imagen.Source = bi;
            return imagen;
        }

    }
}
