﻿using Negocio;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace PresentacionWPF.ValidationRules
{
    public class VRCampoGenerico: ValidationRule
    {
        public int Max { get; set; }
        public int Min { get; set; }
        public bool EsFoto { get; set; }
        public bool EsFechaNacimiento { get; set; }
        public bool EsFechaContratacion { get; set; }
        public bool EsTelefono { get; set; }
        public bool EsNif { get; set; }


        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            if (EsFechaNacimiento)
            {
                if ((DateTime)value >= DateTime.Now)
                {
                    return new ValidationResult(false,
                        "La fecha de nacimiento debe ser inferior a la fecha actual");
                }
            }
            else if (EsFechaContratacion)
            {
                // no se valida
            }
            else
            {
                if (((string)value).Length < Min)
                {
                    return new ValidationResult(false,
                        "La longitud debe ser superior a " + Min + ".");
                }else if (((string)value).Length > Max)
                {
                    return new ValidationResult(false,
                        "La longitud debe de ser inferior a " + Max + ".");
                }

                if (EsNif)
                {
                    string patronNif = "^[0-9]{8}[a-zA-Z]$";
                    if (!Regex.IsMatch((string)value, patronNif))
                    {
                        return new ValidationResult(false,
                            "No es un Nif bien formado (8 dígitos + 1 letra)");
                    }
                }

                if (EsFoto)
                {
                    string patronHttp = "^http://(www.)?([a-z0-9](-?/?[a-z0-9])*.[a-z]{2,3})+$";
                    string patronHttps = "^https://(www.)?(([a-z0-9]+.){2,}.[a-z]{2,3}.[a-z]{2,3})(/([a-z0-9-]+/?))*$";

                    if (((string)value).Length > 0)
                    {
                        if (((string)value).Length > Max)
                        {
                            return new ValidationResult(false,
                                "La longitud debe de ser inferior a : " + Max + ".");
                        }
                        else if (!Regex.IsMatch((string)value, patronHttp) && !Regex.IsMatch((string)value, patronHttps))
                        {
                            return new ValidationResult(false,
                                "No es una dirección bien formada");
                        }
                    }                    
                }

                if (EsTelefono)
                {
                    string patronPhone = "^[0-9]{9,12}$";

                    if (((string)value).Length > 0 && 
                        (!Regex.IsMatch((string)value, patronPhone) || ((string)value).Length < Min || ((string)value).Length > Max))
                    {
                        return new ValidationResult(false,
                            "El teléfono debe contener entre 9 y 12 dígitos");
                    }
                }
            }

            return ValidationResult.ValidResult;        
        }
    }
}
