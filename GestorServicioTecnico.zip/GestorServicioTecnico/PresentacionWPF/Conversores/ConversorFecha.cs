﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace PresentacionWPF.Conversores
{
    public class ConversorFecha : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string textoHoras = (string)value;
            int horas;

            if (string.IsNullOrEmpty(textoHoras) || textoHoras.Trim().Length > 5)
            {
                return DateTime.Now;
            }
            else
            {
                horas = System.Convert.ToInt32(textoHoras.Trim());
                return DateTime.Now.AddHours(horas);
            }            
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
