﻿using Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentacionWPF
{
    /// <summary>
    /// Clase FormularioPrincipal.
    /// Muestra un menú y unas opciones diferentes según si el empleado validado es un coordinador, técnico de campo, técnico de taller o logístico
    /// </summary>
    public partial class FormularioPrincipal : Window
    {
        public const string VISTA_INFORMATIVO = "informativo";
        public const string VISTA_TECNICO = "vistaTecnico";
        public const string EMPLEADOS_INICIO = "inicio empleados";
        public const string EMPLEADOS_MODIFICAR = "modificar empleados";
        public const string EMPLEADOS_ELIMINAR = "eliminar empleados";
        public const string PIEZA_MODIFICAR = "modificar pieza";
        public const string PIEZA_ELIMINAR = "eliminar pieza";
        public const string AVISOS_VISTA_COORDINADOR = "vistaCoordinador";
        public const string AVISOS_VISTA_TECNICO = "vistaTecnico";
        public const string AVISOS_CREAR = "crear aviso";
        public const string AVISOS_MODIFICAR = "modificar aviso";
        public const string AVISOS_CERRAR = "cerrar aviso";
        public const string AVISO_ESPERA = "espera";
        public const string AVISO_DESPLAZAMIENTO = "desplazamiento";
        public const string AVISO_REPARANDO = "reparando";
        public const string AVISO_CERRADO = "cerrado";

        private bool esCoordinador;
        private bool esTecnico;
        private bool esLogistico;
        private Coordinadore? coordinador;
        private Tecnico? tecnico;
        private Logistico? logistico;
        private Empleado? empleado;

        /// <summary>
        /// Constuctor base
        /// </summary>
        public FormularioPrincipal()
        {
            InitializeComponent();
            esCoordinador = false;
            esTecnico = false;
            esLogistico = false;
        }

        /// <summary>
        /// Constructor que recibe un empleado genérico como parámetro
        /// </summary>
        /// <param name="empleado">empleado</param>
        public FormularioPrincipal(Empleado empleado) : this()
        {
            this.empleado = empleado;
        }


        /// <summary>
        /// Constructor que recibe un coordinador como parámetro
        /// </summary>
        /// <param name="coordinador">coordinador</param>
        public FormularioPrincipal(Coordinadore coordinador) : this()
        {
            esCoordinador = true;
            this.coordinador = coordinador;           
        }

        /// <summary>
        /// Constructor que recibe un técnico como parámetro
        /// </summary>
        /// <param name="tecnico">técnico</param>
        public FormularioPrincipal(Tecnico tecnico) : this()
        {
            esTecnico = true;
            this.tecnico = tecnico;           
        }

        /// <summary>
        /// Constructor que recibe un logístico como parámetro
        /// </summary>
        /// <param name="logistico">logístico</param>
        public FormularioPrincipal(Logistico logistico) : this()
        {
            esLogistico = true;
            this.logistico = logistico;            
        }

        /// <summary>
        /// Al cargar los datos, se muestra la información adaptada al empleado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            MostrarMenuEspecifico();           
        }

        /// <summary>
        /// Muestra el menú específico para el empleado conectado según su categoría
        /// </summary>
        private void MostrarMenuEspecifico()
        {
            if (esCoordinador)
            {
                this.DataContext = coordinador;
                menuCoordinacion.Visibility = Visibility.Visible;
                menuTecnicoCampo.Visibility = Visibility.Collapsed;
                menuTecnicosTaller.Visibility = Visibility.Collapsed;
                menuLogistica.Visibility = Visibility.Collapsed;
            }
            else if (esTecnico)
            {
                menuCoordinacion.Visibility = Visibility.Collapsed;
                menuLogistica.Visibility = Visibility.Collapsed;
                if (tecnico!.EsTecnicoTaller)
                {
                    this.DataContext = tecnico;
                    menuTecnicosTaller.Visibility = Visibility.Visible;
                    menuTecnicoCampo.Visibility = Visibility.Collapsed;
                }
                else
                {
                    this.DataContext = tecnico;
                    menuTecnicoCampo.Visibility = Visibility.Visible;
                    menuTecnicosTaller.Visibility = Visibility.Collapsed;
                }
            }
            else if (esLogistico)
            {
                this.DataContext = logistico;
                menuLogistica.Visibility = Visibility.Visible;
                menuCoordinacion.Visibility = Visibility.Collapsed;
                menuTecnicoCampo.Visibility = Visibility.Collapsed;
                menuTecnicosTaller.Visibility = Visibility.Collapsed;
            }
        }

        /// <summary>
        /// Cierra el formulario y sale de la aplicación
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Salir(object sender, RoutedEventArgs e)
        {
            ConfirmacionSalida dialogoConfirmacion = new ConfirmacionSalida("Se va a cerrar la aplicación, ¿Continuar?");
            dialogoConfirmacion.ShowDialog();
            if (dialogoConfirmacion.DialogResult == true)
                Close();
        }

        /// <summary>
        /// Muestra el formulario de empleados con menú para insertar, modificar y dar de baja empleados
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rbEmpleados_Click(object sender, RoutedEventArgs e)
        {
            stackPanelPrincipal.Children.Clear();
            stackPanelPrincipal.Children.Add(new UserControls.Empleados());
        }

        /// <summary>
        /// Muestra el formulario para insertar nuevos empleados
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MostrarFormInsertarEmpleados(object sender, RoutedEventArgs e)
        {
            stackPanelPrincipal.Children.Clear();
            stackPanelPrincipal.Children.Add(new UserControls.Empleados());
        }

        /// <summary>
        /// Muestra el formulario para modificar un empleado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MostrarFormModificarEmpleados(object sender, RoutedEventArgs e)
        {
            stackPanelPrincipal.Children.Clear();
            stackPanelPrincipal.Children.Add(new UserControls.BuscarEmpleado(EMPLEADOS_MODIFICAR));
        }

        /// <summary>
        /// Muestra el formulario para borrar un empleado, dándolo de baja pero sin borrarlo de la base de datos
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MostrarFormBorrarEmpleados(object sender, RoutedEventArgs e)
        {
            stackPanelPrincipal.Children.Clear();
            stackPanelPrincipal.Children.Add(new UserControls.BuscarEmpleado(EMPLEADOS_ELIMINAR));
        }


        /// <summary>
        /// Muestra el inventario completo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MostrarInventario(object sender, RoutedEventArgs e)
        {
            stackPanelPrincipal.Children.Clear();
            stackPanelPrincipal.Children.Add(new UserControls.Inventario());
        }

        /// <summary>
        /// Muestra el inventario para coordinación
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MostrarInventarioCoordinacion(object sender, RoutedEventArgs e)
        {
            stackPanelPrincipal.Children.Clear();
            stackPanelPrincipal.Children.Add(new UserControls.Inventario(VISTA_INFORMATIVO, null)); // indico null al parámetro específico para los técnicos
        }


        /// <summary>
        /// Muestra los avisos y da opción para añadir, modificar o cerrar los avisos
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MostrarAvisosCoordinador(object sender, RoutedEventArgs e)
        {
            if (coordinador != null)
            {
                stackPanelPrincipal.Children.Clear();
                stackPanelPrincipal.Children.Add(new UserControls.Avisos.Avisos(coordinador, AVISOS_VISTA_COORDINADOR));
            }
            else
            {
                MensajeConfirmacion mensajeConfirmacion = new MensajeConfirmacion("Error, no existe el coordinador");
                mensajeConfirmacion.ShowDialog();
            }
        }

        /// <summary>
        /// Abre la gestión de avisos del técnico
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MostrarAvisosTecnico(object sender, RoutedEventArgs e)
        {
            if (tecnico != null)
            {
                stackPanelPrincipal.Children.Clear();
                stackPanelPrincipal.Children.Add(new UserControls.Avisos.Avisos(tecnico, AVISOS_VISTA_TECNICO));
            }
            else
            {
                MensajeConfirmacion mensajeConfirmacion = new MensajeConfirmacion("Error, no existe el técnico");
                mensajeConfirmacion.ShowDialog();
            }
        }

        /// <summary>
        /// Muestra el inventario del técnico y le permite cargar y descargar material
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GestionarInventarioTecnico(object sender, RoutedEventArgs e)
        {
            stackPanelPrincipal.Children.Clear();
            stackPanelPrincipal.Children.Add(new UserControls.Inventario(VISTA_TECNICO, tecnico));
        }

        /// <summary>
        /// Muestra las estadísticas
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MostrarEstadisticas(object sender, RoutedEventArgs e)
        {
            stackPanelPrincipal.Children.Clear();
            stackPanelPrincipal.Children.Add(new UserControls.Estadisticas.EstadisticasAvisos());
        }

        /// <summary>
        /// Muestra el formulario de generación de los informes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MostrarInformes(object sender, RoutedEventArgs e)
        {
            stackPanelPrincipal.Children.Clear();
            stackPanelPrincipal.Children.Add(new UserControls.Informes.InformeTecnicos());
        }
    }
}
