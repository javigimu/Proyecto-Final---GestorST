﻿using Modelos;
using Negocio;
using PresentacionWPF.Dialogos;
using PresentacionWPF.UserControls.Piezas;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PresentacionWPF.UserControls
{
    /// <summary>
    /// Lógica de interacción para Inventario.xaml
    /// </summary>
    public partial class Inventario : UserControl
    {
        public const string OPERACION_CARGAR = "cargar";
        public const string OPERACION_DESCARGAR = "descargar";

        private Pieza? pieza;
        private ObservableCollection<Pieza>? listaObservablePiezas;
        ICollection<Pieza>? piezasTecnico;
        private ObservableCollection<Pieza>? listaPiezasTecnico;
        private CollectionViewSource miVista;
        private string? textoFiltrado;
        private string? vistaInventario;
        private Tecnico? tecnico;

        public Inventario()
        {
            InitializeComponent();
            pieza = new Pieza();
            miVista = (CollectionViewSource)FindResource("listaPiezas");
            MostrarInventario();
            textoFiltrado = "";
        }

        /// <summary>
        /// Muestra el inventario según la vista que se pasa como parámetro
        /// </summary>
        /// <param name="vistaInventario">vista inventario</param>
        public Inventario(string vistaInventario, Tecnico? tecnico) : this()
        {
            this.vistaInventario = vistaInventario;
            btnNuevaPieza.Visibility = Visibility.Collapsed;
            if (tecnico != null )
            {
                this.tecnico = tecnico;
                piezasTecnico = Gestion.ListarPiezasPorTecnico(tecnico.Id);
                if (piezasTecnico != null)
                    listaPiezasTecnico = new ObservableCollection<Pieza>(piezasTecnico);
            }
        }

        /// <summary>
        /// Oculta la papelera para borrar registros y el menú contextual para limitar la posibilidad de modificar el inventario
        /// en la vista informativa
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgPiezas_LoadingRow(object sender, DataGridRowEventArgs e)
        {
            if (vistaInventario == FormularioPrincipal.VISTA_INFORMATIVO)
            {
                dgPiezas.Columns[0].Visibility = Visibility.Collapsed;
                menuContextualPiezas.Visibility = Visibility.Collapsed;
            }
        }


        /// <summary>
        /// Muestra el inventario completo
        /// </summary>
        private void MostrarInventario()
        {
            ICollection<Pieza>? piezas = Gestion.ListarPiezas();
            if (piezas != null)
                listaObservablePiezas = new ObservableCollection<Pieza>(piezas);
            else
                listaObservablePiezas = new ObservableCollection<Pieza>();     
            
            miVista.Source = listaObservablePiezas;
            OrdenarPiezasPorNombreDescripcion(listaObservablePiezas);
        }
               

        /// <summary>
        /// Reacciona cada vez que se introduce un carácter en el texbox de filtrado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbTextoFiltrado_KeyUp(object sender, KeyEventArgs e)
        {
            textoFiltrado = tbTextoFiltrado.Text.Trim().ToLower();
            miVista.Filter += FiltrarPorNombreDescripcion;
        }

        /// <summary>
        /// Filtra las piezas cuyo nombre o descripción contengan el texto introducido por el usuario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FiltrarPorNombreDescripcion(object sender, FilterEventArgs e)
        {
            Pieza piezaFiltrada = (Pieza)e.Item;
            if (piezaFiltrada != null)
            {
                string nombre = piezaFiltrada.Nombre == null ? "" : piezaFiltrada.Nombre;
                string descripcion = piezaFiltrada.Descripcion == null ? "" : piezaFiltrada.Descripcion;
                string piezaIdTexto = piezaFiltrada.Id.ToString().Trim();

                if (nombre.ToLower().Contains(textoFiltrado!.ToLower()) || 
                    descripcion.ToLower().Contains(textoFiltrado!.ToLower()) ||
                    piezaIdTexto.Contains(textoFiltrado))
                {
                    e.Accepted = true;
                }
                else
                {
                    e.Accepted = false;
                }
            }
        }

        /// <summary>
        /// Inicialmente se muestran los datos de todas las piezas que hay en la base de datos
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            OrdenarPiezasPorNombreDescripcion(listaObservablePiezas);
            pieza = (Pieza)dgPiezas.SelectedItem;

            if (vistaInventario == null) // el usuario por defecto para el inventario es logístico
                OcultarMenuContextualTecnico();
            else if (vistaInventario == FormularioPrincipal.VISTA_TECNICO)
                MostrarMenuContextualTecnico();          
        }

        /// <summary>
        /// Muestra únicamente las opciones específicas del técnico en el menú contextual.
        /// Cargar pieza
        /// Descargar pieza
        /// </summary>
        private void MostrarMenuContextualTecnico()
        {
            MenuItemCargarPieza.Visibility = Visibility.Visible;
            MenuItemDescargarPieza.Visibility = Visibility.Visible;
            MenuItemAnyadirPieza.Visibility = Visibility.Collapsed;
            MenuItemEliminarPieza.Visibility = Visibility.Collapsed;
            MenuItemModificarPieza.Visibility = Visibility.Collapsed;
            cbMiInventario.Visibility = Visibility.Visible; 
        }

        /// <summary>
        /// Oculta las opciones del menú contextual específicas del técnico
        /// Cargar pieza
        /// Descargar pieza
        /// </summary>
        private void OcultarMenuContextualTecnico()
        {
            MenuItemCargarPieza.Visibility = Visibility.Collapsed;
            MenuItemDescargarPieza.Visibility = Visibility.Collapsed;
        }

        /// <summary>
        /// Añadir nueva pieza a través del botón
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AnyadirNuevaPieza(object sender, RoutedEventArgs e)
        {
            AnyadirPieza();
        }

        /// <summary>
        /// Añadir nueva pieza a través del menú contextual
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemAnyadirPieza_Click(object sender, RoutedEventArgs e)
        {
            AnyadirPieza();
        }

        /// <summary>
        /// Abre un diálogo para ir añadiendo nuevas piezas hasta que el usuario pulse en salir
        /// </summary>
        private void AnyadirPieza()
        {
            GestionarPieza dialogoPieza = new GestionarPieza();
            dialogoPieza.ShowDialog();
            MostrarInventario();
        }

        /// <summary>
        /// Modificar una pieza a través del menú contextual
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemModificarPieza_Click(object sender, RoutedEventArgs e)
        {
            ModificarPieza();  
        }

        /// <summary>
        /// Modificar una pieza a través de una doble pulsación del ratón
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgPiezas_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (vistaInventario == FormularioPrincipal.VISTA_INFORMATIVO)
                e.Handled = false;
            else if (vistaInventario == FormularioPrincipal.VISTA_TECNICO)
                GestionarPieza(OPERACION_CARGAR);
            else
                ModificarPieza();
        }

        /// <summary>
        /// Abre un diálogo con la información de la pieza a modificar
        /// </summary>
        private void ModificarPieza()
        {
            pieza = (Pieza)dgPiezas.SelectedItem;
            GestionarPieza dialogoPieza = new GestionarPieza(pieza, FormularioPrincipal.PIEZA_MODIFICAR);
            dialogoPieza.ShowDialog();
            if (dialogoPieza.DialogResult == true)
            {
                MostrarInventario();
            }
        }

        /// <summary>
        /// Elimina la pieza seleccionada a través del icono de la papelera
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEliminarRegistro_Click(object sender, RoutedEventArgs e)
        {
            EliminarPieza();
        }

        /// <summary>
        /// Elimina la pieza seleccionada a través de la opción del menú contextual
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemEliminarPieza_Click(object sender, RoutedEventArgs e)
        {
            EliminarPieza();
        }

        /// <summary>
        /// Elimina la pieza seleccionada
        /// </summary>
        private void EliminarPieza()
        {
            pieza = (Pieza)dgPiezas.SelectedItem;
            GestionarPieza dialogoPieza = new GestionarPieza(pieza, FormularioPrincipal.PIEZA_ELIMINAR);
            dialogoPieza.ShowDialog();
            if (dialogoPieza.DialogResult == true)
            {
                MostrarInventario();
            }
        }

        /// <summary>
        /// Ordena las piezas por certificado, mostrando primero las que sí necesitan certificado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbOrdenCertificado_Checked(object sender, RoutedEventArgs e)
        {
            if (listaObservablePiezas != null)
            {
                if (cbMiInventario.IsChecked == false)
                    miVista.Source = listaObservablePiezas.OrderByDescending(pieza => pieza.NecesitaCertificado).ToList();
                else if (listaPiezasTecnico != null)
                    miVista.Source = listaPiezasTecnico.OrderByDescending(pieza => pieza.NecesitaCertificado).ToList();
                cbOrdenConsumible.IsChecked = false;                
            }               
        }

        /// <summary>
        /// Ordena las piezas por consumible, mostrando primero las que sí lo son
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbOrdenConsumible_Checked(object sender, RoutedEventArgs e)
        {
            if (listaObservablePiezas != null)
            {
                if (cbMiInventario.IsChecked == false)
                    miVista.Source = listaObservablePiezas.OrderByDescending(pieza => pieza.Consumible).ToList();
                else if (listaPiezasTecnico != null)
                    miVista.Source = listaPiezasTecnico.OrderByDescending(pieza => pieza.Consumible).ToList();

                cbOrdenCertificado.IsChecked = false;     
            }
        }

        /// <summary>
        /// Si los dos filtros de ordenación están desmarcados, ordena las piezas por nombre y descripción
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbOrdenCertificado_Click(object sender, RoutedEventArgs e)
        {
            if (cbOrdenCertificado.IsChecked == false)
            {
                if (cbMiInventario.IsChecked == false)
                    OrdenarPiezasPorNombreDescripcion(listaObservablePiezas);
                else
                    OrdenarPiezasPorNombreDescripcion(listaPiezasTecnico);
            }
        }

        /// <summary>
        ///  Si los dos filtros de ordenación están desmarcados, ordena las piezas por nombre y descripción
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbOrdenConsumible_Click(object sender, RoutedEventArgs e)
        {
            if (cbOrdenConsumible.IsChecked == false)
            {
                if (cbMiInventario.IsChecked == false)
                    OrdenarPiezasPorNombreDescripcion(listaObservablePiezas);
                else
                    OrdenarPiezasPorNombreDescripcion(listaPiezasTecnico);
            }                
        }

        /// <summary>
        /// Ordena las piezas por nombre y después por descripción
        /// </summary>
        private void OrdenarPiezasPorNombreDescripcion(ICollection<Pieza>? piezas)
        {
            if (piezas != null)
                miVista.Source = piezas.OrderBy(pieza => pieza.Nombre).ThenBy(pieza => pieza.Descripcion);
        }

        /// <summary>
        /// Carga una pieza seleccionada del inventario general en el inventario específico del técnico y la descarga del inventario general
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemCargarPieza_Click(object sender, RoutedEventArgs e)
        {
            GestionarPieza(OPERACION_CARGAR);            
        }
        

        /// <summary>
        /// Descarga una pieza del inventario específico del técnico y la carga en el inventario general
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemDescargarPieza_Click(object sender, RoutedEventArgs e)
        {
            GestionarPieza(OPERACION_DESCARGAR);
        }

        /// <summary>
        /// Muestra el diálogo para cargar o descargar una pieza en el inventario del técnico
        /// </summary>
        /// <param name="operacion">operación a realizar {cargar, descargar}</param>
        private void GestionarPieza(string operacion)
        {
            MensajeConfirmacion mensaje;
            CargaDescargaPieza cargaDescargaPieza;
            bool cancelarOperacion = false;

            Pieza pieza = (Pieza)dgPiezas.SelectedItem;
            if (pieza != null && tecnico != null)
            {
                if (operacion == OPERACION_DESCARGAR)
                {
                    if (piezasTecnico == null)
                    {
                        cancelarOperacion = true;
                        mensaje = new MensajeConfirmacion("El inventario está vacío!");
                        mensaje.ShowDialog();
                    }
                    else if (!TecnicoTienePieza(pieza))
                    {
                        cancelarOperacion = true;
                        mensaje = new MensajeConfirmacion("La pieza seleccionada no está en tu inventario!");
                        mensaje.ShowDialog();
                    }
                }

                if (!cancelarOperacion)
                {
                    cargaDescargaPieza = new CargaDescargaPieza(pieza, tecnico, operacion);
                    cargaDescargaPieza.ShowDialog();
                    if (cargaDescargaPieza.DialogResult == true)
                    {
                        MostrarInventario();
                    }
                }                             
            }            
        }

        /// <summary>
        /// Comprueba si la pieza que se pasa como parámetro está incluida en el inventario del técnico
        /// </summary>
        /// <param name="pieza">pieza</param>
        /// <returns>true si la pieza está en el inventario del técnico</returns>
        private bool TecnicoTienePieza(Pieza pieza)
        {
            if (piezasTecnico != null)
            {
                foreach (Pieza p in piezasTecnico)
                {
                    if (p.Id == pieza.Id)
                        return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Muestra el inventario del técnico
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbMiInventario_Checked(object sender, RoutedEventArgs e)
        {
            miVista.Source = listaPiezasTecnico;
            OrdenarPiezasPorNombreDescripcion(listaPiezasTecnico);
        }
       

        /// <summary>
        /// Al descarcar el checkbox de "mi inventario" se muestran todas las piezas
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbMiInventario_Click(object sender, RoutedEventArgs e)
        {
            if (cbMiInventario.IsChecked == false)
            {
                miVista.Source = listaObservablePiezas;
                OrdenarPiezasPorNombreDescripcion(listaObservablePiezas);
            }
        }
    }
}
