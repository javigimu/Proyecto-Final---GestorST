﻿using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.Win32;
using Modelos;
using Negocio;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentacionWPF.UserControls.Piezas
{
    /// <summary>
    /// Lógica de interacción para GestionarPieza.xaml
    /// </summary>
    public partial class GestionarPieza : Window
    {
        private Pieza? pieza;
        private string? operacion;

        /// <summary>
        /// Constructor para insertar nueva pieza
        /// </summary>
        public GestionarPieza()
        {
            InitializeComponent();
            pieza = new Pieza();
            operacion = null;
            this.DataContext = pieza;
        }

        /// <summary>
        /// Constructor que recibe la operación de modificar o borrar como parámetro
        /// </summary>
        /// <param name="operacion">operación a realizar</param>
        public GestionarPieza(Pieza pieza, string operacion) : this()
        {
            this.pieza = pieza;
            this.operacion = operacion;
            MostrarTitulo(operacion);
        }

        /// <summary>
        /// Muestra en la parte superior de la ventana, el título correspondiente según la operación, siendo la inserción el valor por defecto
        /// </summary>
        /// <param name="operacion">modificar o borrar</param>
        /// <exception cref="NotImplementedException"></exception>
        private void MostrarTitulo(string operacion)
        {
            tbTituloOperacion.Text = operacion.ToUpper() + " PIEZA";
            if (operacion == FormularioPrincipal.PIEZA_ELIMINAR)
                btnResetear.Visibility = Visibility.Hidden;
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (operacion != null)
            {
                this.DataContext = pieza;
            }

            if (operacion == FormularioPrincipal.PIEZA_ELIMINAR)
                BloquearEdicionDeCampos();
        }

        private void btnResetear_Click(object sender, RoutedEventArgs e)
        {
            ResetearPieza();
        }

        private void ResetearPieza()
        {
            pieza = new Pieza();
            this.DataContext = pieza;
            imgFoto.Source = new BitmapImage();
        }

        /// <summary>
        /// Permite al usuario adjuntar una foto para la pieza y la muestra en imgFoto
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AdjuntarFoto(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                byte[]? foto;
                string imagen = openFileDialog.FileName;
                if (imagen != "")
                {
                    foto = File.ReadAllBytes(imagen);
                    pieza!.Imagen = foto;
                    imgFoto = Utils.MostrarFotoSeleccionada(imgFoto, foto);
                }
            }
        }

        /// <summary>
        /// Verificar que no haya ningún campo con error de validación
        /// </summary>
        /// <returns></returns>
        private bool VerificarCamposValidados()
        {
            bool validacionOk = tbNombre.Text.Length > 0 && tbStock.Text.Length > 0;

            if (Validation.GetHasError(tbNombre)) validacionOk = false;
            if (Validation.GetHasError(tbDescripcion)) validacionOk = false;
            if (Validation.GetHasError(tbStock)) validacionOk = false;

            return validacionOk;
        }

        /// <summary>
        /// Inserta, modifica o elimina la pieza con los valores del formulario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAceptar_Click(object sender, RoutedEventArgs e)
        {
            if (VerificarCamposValidados())
            {                
                textoAceptar.Foreground = (Brush)Application.Current.Resources["colorTextoInformacion"];

                if (pieza != null)
                {
                    if (operacion == FormularioPrincipal.PIEZA_MODIFICAR)
                    {
                        Gestion.ActualizarPieza(pieza);
                        textoAceptar.Content = "Pieza modificada correctamente!!";
                    }
                    else if (operacion == FormularioPrincipal.PIEZA_ELIMINAR)
                    {
                        ConfirmacionSalida dialogoConfirmacion = new ConfirmacionSalida("Se va a eliminar la pieza, ¿Continuar?");
                        if (dialogoConfirmacion.ShowDialog() == true)
                        {
                            Gestion.BorrarPieza(pieza);
                            textoAceptar.Content = "Pieza eliminada correctamente!!";
                            btnAceptar.IsEnabled = false;
                        }
                    }
                    else
                    {
                        Gestion.InsertarPieza(pieza);
                        textoAceptar.Content = "Pieza insertada correctamente!!";
                        ResetearPieza();
                    }
                }                
            }
            else
            {
                if (tbNombre.Text.Length == 0)
                    textoAceptar.Content = "El nombre no puede estar vacío";
                else if (tbStock.Text.Length == 0)
                    textoAceptar.Content = "El stock no puede estar vacío";
                else
                    textoAceptar.Content = "Error: hay campos con error de validación!!";

                textoAceptar.Foreground = (Brush)Application.Current.Resources["colorTextoError"];                
            }

            e.Handled = false;
        }

        /// <summary>
        /// Bloquea los campos para evitar su edición, sólo se muestran los datos y se permite al usuario eliminar el empleado o cancelar
        /// </summary>
        /// <exception cref="NotImplementedException"></exception>
        private void BloquearEdicionDeCampos()
        {
            stackPanelPrincipal.IsEnabled = false;
            btnResetear.Visibility = Visibility.Collapsed;
        }

        /// <summary>
        /// Sólo permite introducir números en un textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            Close();
        }
    }
}
