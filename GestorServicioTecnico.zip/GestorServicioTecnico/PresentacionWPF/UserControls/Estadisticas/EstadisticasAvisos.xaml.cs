﻿using LiveCharts.Wpf;
using LiveCharts;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using Modelos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PresentacionWPF.UserControls.Estadisticas
{
    /// <summary>
    /// Lógica de interacción para EstadisticasAvisos.xaml
    /// </summary>
    public partial class EstadisticasAvisos : UserControl
    {
        public EstadisticasAvisos()
        {
            InitializeComponent();
            CrearGraficosAvisos();
            CrearGraficosTecnicos();
        }

        /// <summary>
        /// Crea los gráficos sobre los avisos
        /// </summary>
        private void CrearGraficosAvisos()
        {
            Dictionary<string, double> avisosPorCliente = new Dictionary<string, double>();
            CargarDiccionarioAvisosPorCliente(avisosPorCliente);

            SeriesCollection serie = new SeriesCollection();

            foreach (KeyValuePair<string, double> dato in avisosPorCliente)
            {
                serie.Add(new PieSeries
                {
                    Title = dato.Key,
                    Values = new ChartValues<double> { dato.Value },
                    DataLabels = true
                });
            }

            graficoAvisosCliente.Series = serie;
        }

        /// <summary>
        /// LLena el diccionario de avisos por cliente con los datos de los avisos
        /// </summary>
        /// <param name="avisosPorCliente"></param>
        private void CargarDiccionarioAvisosPorCliente(Dictionary<string, double> avisosPorCliente)
        {
            IList<Cliente>? clientes = Gestion.ListarClientesCompleto();
            if (clientes != null)
            {
                foreach (Cliente cliente in clientes)
                {
                    avisosPorCliente.Add(cliente.Nombre, cliente.Avisos.Count);
                }
            }            
        }

        /// <summary>
        /// Crea el gráfico que muestra los avisos cerrados por cada técnico
        /// </summary>
        private void CrearGraficosTecnicos()
        {
            ICollection<Tecnico>? tecnicos = Gestion.ListarTecnicosCompleto();
            Dictionary<string, double> avisosPorTecnico = new Dictionary<string, double>();
            if (tecnicos != null)
            {
                foreach (Tecnico tecnico in tecnicos)
                {
                    avisosPorTecnico.Add(tecnico.NombreCompleto, tecnico.Avisos.Count);                    
                }
            }


            SeriesCollection serie = new SeriesCollection();
            serie.Add(new RowSeries
            {
                Title = "Avisos-Técnico",
                Values = new ChartValues<double>(avisosPorTecnico.Values)
            });

            gBarras_eje_y.Labels = new List<string>();
            foreach (KeyValuePair<string, double> dato in avisosPorTecnico)
            {
                gBarras_eje_y.Labels.Add(dato.Key);
            }

            graficoAvisosTecnico.Series = serie;
        }
    }
}
