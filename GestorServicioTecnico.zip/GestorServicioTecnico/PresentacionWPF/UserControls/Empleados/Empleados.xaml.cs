﻿using Microsoft.Win32;
using Modelos;
using Negocio;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PresentacionWPF.UserControls
{
    /// <summary>
    /// Lógica de interacción para Empleados.xaml
    /// </summary>
    public partial class Empleados : UserControl
    {
        private Empleado? empleado;
        private Tecnico? tecnico;
        private string? operacion;
        private bool esTecnico;
        private bool esCoordinador;
        private bool esLogisitico;


        public Empleados()
        {
            InitializeComponent();
            empleado = new Empleado();
            operacion = null;
            this.DataContext = empleado;
            esTecnico = esCoordinador = esLogisitico = false;
        }

        /// <summary>
        /// Constructor para utilizar en la modificación y borrado de un empleado
        /// </summary>
        /// <param name="empleado">empleado</param>
        public Empleados(Empleado empleado, string operacion) : this()
        {           
            AsignarEmpleadoSeleccionado(empleado);
            this.operacion = operacion;
            MostrarTitulo(operacion);
        }

        /// <summary>
        /// Asigna el empleado al datacontext
        /// </summary>
        /// <param name="empleado"></param>
        private void AsignarEmpleadoSeleccionado(Empleado empleado)
        {
            this.empleado = empleado;

            IList<Tecnico>? tecnicos = Gestion.ListarTecnicos();
            IList<Coordinadore>? coordinadores = Gestion.ListarCoordinadores();
            IList<Logistico>? logisticos = Gestion.ListarLogisticos();
            
            if (tecnicos != null && Gestion.EmpleadoEsTecnico(tecnicos, empleado.Id))
            {
                tecnico = Gestion.ListarTecnico(empleado.Id);
                spDatosTecnico.DataContext = tecnico;
                esTecnico = true;
            } 
            else if (coordinadores != null && Gestion.EmpleadoEsCoordinador(coordinadores, empleado.Id))
            {
                esCoordinador = true;
                rbCoordinador.IsChecked = true;
            }
            else if (logisticos != null && Gestion.EmpleadoEsLogistico(logisticos, empleado.Id))
            {
                esLogisitico = true;
                rbLogistico.IsChecked = true;
            }
        }

        /// <summary>
        /// Muestra en la parte superior de la ventana, el título correspondiente según la operación, siendo la inserción el valor por defecto
        /// </summary>
        /// <param name="operacion">modificar o borrar</param>
        /// <exception cref="NotImplementedException"></exception>
        private void MostrarTitulo(string operacion)
        {
            tbTituloOperacion.Text = operacion.ToUpper() + " EMPLEADO";
            if (operacion == FormularioPrincipal.EMPLEADOS_ELIMINAR)
                btnResetear.Visibility = Visibility.Hidden;
        }


        /// <summary>
        /// Permite al usuario adjuntar una foto para el empleado y la muestra en imgFoto
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AdjuntarFoto(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                byte[]? foto;
                string imagen = openFileDialog.FileName;
                if (imagen != "")
                {
                    foto = File.ReadAllBytes(imagen);
                    empleado!.Foto = foto;
                    imgFoto = Utils.MostrarFotoSeleccionada(imgFoto, foto);
                }
                imgFoto.DataContext = empleado;
            }
        }

        /// <summary>
        /// Verificar que no haya ningún campo con error de validación
        /// </summary>
        /// <returns></returns>
        private bool VerificarCamposValidados()
        {
            bool validacionOk = tbNombre.Text.Length > 0 && tbApellido.Text.Length > 0;

            if (Validation.GetHasError(tbNombre)) validacionOk = false;
            if (Validation.GetHasError(tbApellido)) validacionOk = false;
            if (Validation.GetHasError(tbDireccion)) validacionOk = false;
            if (Validation.GetHasError(tbCiudad)) validacionOk = false;
            if (Validation.GetHasError(tbRegion)) validacionOk = false;
            if (Validation.GetHasError(tbCodigoPostal)) validacionOk = false;
            if (Validation.GetHasError(tbPais)) validacionOk = false;
            if (Validation.GetHasError(dtFechaNacimiento)) validacionOk = false;
            if (Validation.GetHasError(tbTelefono)) validacionOk = false;
            if (Validation.GetHasError(tbFormacion)) validacionOk = false;
            if (Validation.GetHasError(dtFechaContratacion)) validacionOk = false;
            if (Validation.GetHasError(tbNif)) validacionOk = false;

            return validacionOk;
        }

        /// <summary>
        /// Inserta, modifica o elimina el empleado con los valores del formulario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAceptar_Click(object sender, RoutedEventArgs e)
        {
            if (VerificarCamposValidados())
            {
                textoAceptar.Foreground = (Brush)Application.Current.Resources["colorTextoInformacion"];

                if (empleado != null)
                {
                    if (operacion == FormularioPrincipal.EMPLEADOS_MODIFICAR)
                    {
                        if (rbTecnico.IsChecked == true)
                            ModificarTecnico(empleado);       
                        else if (rbCoordinador.IsChecked == true)
                            ModificarCoordinador(empleado);
                        else if (rbLogistico.IsChecked == true)                        
                            ModificarLogistico(empleado);    

                        textoAceptar.Content = "Empleado modificado correctamente!!";
                    }
                    else if (operacion == FormularioPrincipal.EMPLEADOS_ELIMINAR)
                    {
                        //ConfirmacionSalida dialogoConfirmacion = new ConfirmacionSalida("Se va a eliminar el empleado, ¿Continuar?");
                        ConfirmacionSalida dialogoConfirmacion = new ConfirmacionSalida("Se va a a dar de baja el empleado, ¿Continuar?");
                        if (dialogoConfirmacion.ShowDialog() == true)
                        {
                            //Gestion.BorrarEmpleado(empleado);
                            Gestion.DarDeBajaEmpleado(empleado);
                            //textoAceptar.Content = "Empleado eliminado correctamente!!";
                            textoAceptar.Content = "Empleado dado de baja correctamente!!";
                            btnAceptar.IsEnabled = false;
                        }
                    }
                    else
                    {              
                        // Dependiendo de la categoría, se convierte el empleado para poder realizar la inserción
                        if (rbTecnico.IsChecked == true)
                        {
                            Tecnico tecnico = new Tecnico(empleado);
                            tecnico.Especialista = cbEspecialista.IsChecked;
                            tecnico.VehiculoEmpresa = cbVehiculoEmpresa.IsChecked;
                            tecnico.EsTecnicoTaller = (bool)cbEsTecnicoTaller.IsChecked!;
                            tecnico.TieneCertificado = (bool)cbTieneCertificado.IsChecked!;
                            Gestion.InsertarTecnico(tecnico);
                        }
                        else if (rbCoordinador.IsChecked == true)
                        {
                            if (tecnico != null)
                                Gestion.ListarTecnico(tecnico.Id);
                                //Gestion.BorrarTecnico(tecnico);
                            Coordinadore coordinador = new Coordinadore(empleado);
                            Gestion.InsertarCoordinador(coordinador);
                        }
                        else if (rbLogistico.IsChecked == true)
                        {
                            if (tecnico != null)
                                Gestion.ListarTecnico(tecnico.Id);
                                //Gestion.BorrarTecnico(tecnico);
                            Logistico logistico = new Logistico(empleado);
                            Gestion.InsertarLogistico(logistico);
                        }
                        
                        textoAceptar.Content = "Empleado insertado correctamente!!";
                        ResetearEmpleado();
                    }
                }
            }
            
            else
            {
                if (tbNombre.Text.Length == 0)
                    textoAceptar.Content = "El nombre no puede estar vacío";
                else if (tbApellido.Text.Length == 0)
                    textoAceptar.Content = "El apellido no puede estar vacío";
                else
                    textoAceptar.Content = "Error: hay campos con error de validación!!";

                textoAceptar.Foreground = (Brush)Application.Current.Resources["colorTextoError"];
            }
        }

        /// <summary>
        /// Actualiza los datos de un técnico, comprobando si previamente era un técnico, logístico o coordinador
        /// </summary>
        /// <param name="empleado">empleado modificado</param>
        private void ModificarTecnico(Empleado empleado)
        {
            Tecnico tecnico = new Tecnico(empleado);
            tecnico.Especialista = cbEspecialista.IsChecked;
            tecnico.VehiculoEmpresa = cbVehiculoEmpresa.IsChecked;
            tecnico.EsTecnicoTaller = (bool)cbEsTecnicoTaller.IsChecked!;
            tecnico.TieneCertificado = (bool)cbTieneCertificado.IsChecked!;

            if (esTecnico)
                Gestion.ActualizarTecnico(tecnico);
            else
            {
                Coordinadore? coordinador = Gestion.ListarCoordinador(tecnico.Id);
                Logistico? logistico = Gestion.ListarLogistico(tecnico.Id);
                if (coordinador != null)
                    Gestion.BorrarCoordinador(coordinador);
                if (logistico != null)
                    Gestion.BorrarLogistico(logistico);

                Gestion.InsertarTecnico(tecnico);
            }
        }

        /// <summary>
        /// Actualiza los datos de un coordinador, comprobando si previamente era un técnico, logístico o coordinador
        /// </summary>
        /// <param name="empleado">empleado modificado</param>
        private void ModificarCoordinador(Empleado empleado)
        {
            Coordinadore coordinador = new Coordinadore(empleado);

            if (esTecnico || esLogisitico)
            {
                Gestion.BorrarEmpleado(empleado);
                Gestion.InsertarCoordinador(coordinador);
            }
            else
            {
                Gestion.ActualizarCoordinador(coordinador);
            }              
        }

        /// <summary>
        /// Actualiza los datos de un logístico, comprobando si previamente era un técnico, logístico o coordinador
        /// </summary>
        /// <param name="empleado">empleado modificado</param>
        private void ModificarLogistico(Empleado empleado)
        {
            Logistico logistico = new Logistico(empleado);

            if (esTecnico || esCoordinador)
            {
                Gestion.BorrarEmpleado(empleado);
                Gestion.InsertarLogistico(logistico);
            }
            else
            {
                Gestion.ActualizarLogistico(logistico);
            }
        }

        /// <summary>
        /// Resetea el empleado y se vacían los campos
        /// </summary>
        public void ResetearEmpleado()
        {
            empleado = new Empleado();
            this.DataContext = empleado;
        }

        /// <summary>
        /// Resetea todos los valores del formulario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnResetear_Click(object sender, RoutedEventArgs e)
        {
            ResetearEmpleado();
        }

        

        /// <summary>
        /// Bloquea los campos para evitar su edición, sólo se muestran los datos y se permite al usuario eliminar el empleado o cancelar
        /// </summary>
        /// <exception cref="NotImplementedException"></exception>
        private void BloquearEdicionDeCampos()
        {
            groupDatosPersonales.IsEnabled = false;
            groupDatosProfesionales.IsEnabled = false;
        }

        /// <summary>
        /// Al cargar el user control, se establece su DataContext
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (operacion != null)
            {
                this.DataContext = empleado;
            }

            if (operacion == "eliminar")
                BloquearEdicionDeCampos();
        }

        private void rbTecnico_Click(object sender, RoutedEventArgs e)
        {
            spDatosTecnico.Visibility = Visibility.Visible;
        }

        private void rbTecnico_Unchecked(object sender, RoutedEventArgs e)
        {
            spDatosTecnico.Visibility = Visibility.Collapsed;
        }

        /// <summary>
        /// Tras pulsar una tecla, se convierte a mayúscula
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbNif_KeyUp(object sender, KeyEventArgs e)
        {
            tbNif.Text = tbNif.Text.ToUpper();
        }

        /// <summary>
        /// Muestra el formulario con la inserción de empleados
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MostrarFormInsertarEmpleados(object sender, RoutedEventArgs e)
        {
            var padre = Window.GetWindow(this) as FormularioPrincipal;
            if (padre != null)
            {
                padre.stackPanelPrincipal.Children.Clear();
                padre.stackPanelPrincipal.Children.Add(new UserControls.Empleados());
            }
        }

        /// <summary>
        /// Muestra un diálogo de búsqueda de empleados para, una vez seleccionado, poder modificarlo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MostrarFormModificarEmpleados(object sender, RoutedEventArgs e)
        {
            var padre = Window.GetWindow(this) as FormularioPrincipal;
            if (padre != null)
            {
                padre.stackPanelPrincipal.Children.Clear();
                padre.stackPanelPrincipal.Children.Add(
                    new BuscarEmpleado(FormularioPrincipal.EMPLEADOS_MODIFICAR));
            }
        }

        /// <summary>
        /// Muestra un diálogo de búsqueda de empleados para, una vez seleccionado, poder borrarlo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MostrarFormBorrarEmpleados(object sender, RoutedEventArgs e)
        {
            var padre = Window.GetWindow(this) as FormularioPrincipal;
            if (padre != null)
            {
                padre.stackPanelPrincipal.Children.Clear();
                padre.stackPanelPrincipal.Children.Add(
                    new BuscarEmpleado(FormularioPrincipal.EMPLEADOS_ELIMINAR));
            }
        }
    }
}
