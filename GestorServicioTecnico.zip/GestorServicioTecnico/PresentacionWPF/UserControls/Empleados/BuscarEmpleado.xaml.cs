﻿using Modelos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace PresentacionWPF.UserControls
{
    /// <summary>
    /// <autor>Javier Giménez Muñoz</autor>
    /// Lógica de interacción para BuscarEmpleado.xaml
    /// </summary>
    public partial class BuscarEmpleado : UserControl
    {
        private Empleado? empleado;
        private ObservableCollection<Empleado>? listaObservableEmpleados;
        private CollectionViewSource MiVista;
        private string? textoFiltrado;
        // variable para recibir si la operación a realizar en la búsqueda es una modificación o borrado
        string? operacion; 

        /// <summary>
        /// Constructor principal
        /// </summary>
        public BuscarEmpleado()
        {
            InitializeComponent();
            empleado = new Empleado();
            MiVista = (CollectionViewSource)FindResource("listaEmpleados");
            MostrarEmpleados();
        }

        /// <summary>
        /// Constructor que recibe como parámetro la opción a realizar tras la búsqueda
        /// </summary>
        /// <param name="operacion"></param>
        public BuscarEmpleado(string operacion) : this()
        {
            this.operacion = operacion;
        }

        /// <summary>
        /// Muestra un listado de todos los empleados
        /// </summary>
        private void MostrarEmpleados()
        {
            ICollection<Empleado>? empleados = Gestion.ListarEmpleados();

            if (empleados != null)
            {
                //foreach (Empleado e in empleados)
                //{
                //    e.Nombre = e.Nombre.Trim();
                //    e.Apellidos = e.Apellidos.Trim();
                //    e.Provincia= e.Provincia == null ? null : e.Provincia.Trim();
                //}

                listaObservableEmpleados = new ObservableCollection<Empleado>(empleados);
            }
            else
                listaObservableEmpleados = new ObservableCollection<Empleado>();
            textoFiltrado = "";
        }
        

        /// <summary>
        /// Inicialmente se muestran los datos obtenidos de la tabla empleados en la base de datos
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            MiVista.Source = listaObservableEmpleados;
        }

        /// <summary>
        /// Envía el empleado seleccionado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSeleccionar_Click(object sender, RoutedEventArgs e)
        {
            EnviarEmpleadoSeleccionado();
        }

        /// <summary>
        /// Abre el formulario de empleados con el empleado seleccionado y la opción de modificar o eliminar
        /// </summary>
        private void EnviarEmpleadoSeleccionado()
        {
            empleado = (Empleado)lvEmpleados.SelectedItem;
            var padre = Window.GetWindow(this) as PresentacionWPF.FormularioPrincipal; 
            if (padre != null)
            {
                padre.stackPanelPrincipal.Children.Clear();
                padre.stackPanelPrincipal.Children.Add(new Empleados(empleado, operacion!));
            }
        }


        /// <summary>
        /// Controla el doble click del ratón sobre un item del listview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void manejarDoubleClick(object sender, MouseButtonEventArgs e)
        {            
            empleado = (Empleado)lvEmpleados.SelectedItem;
            EnviarEmpleadoSeleccionado();
        }

        /// <summary>
        /// Filtra los empleados tras introducir texto en el campo tbTextoFiltrado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbTextoFiltrado_KeyUp(object sender, KeyEventArgs e)
        {
            textoFiltrado = tbTextoFiltrado.Text.Trim().ToLower();
            MiVista.Filter += FiltrarPorNombreApellidoCiudad;
        }

        /// <summary>
        /// Filtra los empleados cuyo nombre, apellido o ciudad contengan el texto introducido por el usuario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FiltrarPorNombreApellidoCiudad(object sender, FilterEventArgs e)
        {
            Empleado empFiltrado = (Empleado)e.Item;
            if (empFiltrado != null)
            {
                string provincia = empFiltrado.Provincia == null ? "" : empFiltrado.Provincia;
                if (empFiltrado.Nombre.ToLower().Contains(textoFiltrado!) ||
                    empFiltrado.Apellidos.ToLower().Contains(textoFiltrado!) ||
                    provincia.ToLower().Contains(textoFiltrado!))
                {
                    e.Accepted = true;
                }
                else
                {
                    e.Accepted = false;
                }
            }      
        }
    }
}
