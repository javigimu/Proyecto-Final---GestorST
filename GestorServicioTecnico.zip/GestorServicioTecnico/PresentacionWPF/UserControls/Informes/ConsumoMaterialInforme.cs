﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PresentacionWPF.UserControls.Informes
{
    /// <summary>
    /// Clase auxiliar para mostrar los datos del informe sobre los técnicos
    /// </summary>
    public class ConsumoMaterialInforme
    {
        public long PiezaId { get; set; }
        public string Nombre { get; set; }
        public bool Consumible { get; set; }
        public int CantidadTotal { get; set; }

        public ConsumoMaterialInforme(long piezaId, string nombre, bool consumible, int cantidadTotal) 
        { 
            PiezaId = piezaId;
            Nombre = nombre;
            Consumible = consumible;
            CantidadTotal = cantidadTotal;
        }
        
    }
}
