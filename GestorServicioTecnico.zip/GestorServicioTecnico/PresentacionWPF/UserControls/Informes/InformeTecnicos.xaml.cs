﻿using Modelos;
using Negocio;
using PresentacionWPF.Dialogos;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Xps.Packaging;
using System.Windows.Xps;
using System.Windows.Markup;

namespace PresentacionWPF.UserControls.Informes
{
    /// <summary>
    /// Lógica de interacción para InformeTecnicos.xaml
    /// </summary>
    public partial class InformeTecnicos : UserControl
    {
        public FixedDocumentSequence? Document { get; set; }
        private Tecnico? tecnico;
        private List<ConsumoMaterialInforme> listaConsumosMaterialInforme;

        public InformeTecnicos()
        {
            InitializeComponent();
            tbFechaInforme.Text = DateTime.Now.ToString("dd/MM/yyyy");   
            listaConsumosMaterialInforme = new List<ConsumoMaterialInforme>();
            this.DataContext = tecnico;
        }

        /// <summary>
        /// Abre un diálogo para seleccionar el técnico sobre el que realizar el informe
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSeleccionTecnico_Click(object sender, RoutedEventArgs e)
        {
            BuscarTecnico buscarTecnico = new BuscarTecnico();
            buscarTecnico.ShowDialog();
            if (buscarTecnico.DialogResult == true)
            {
                tecnico = buscarTecnico.TecnicoSeleccionado;
                if (tecnico != null)
                    MostrarDatosTecnico();
            }
        }

        /// <summary>
        /// Muestra los datos del técnico
        /// </summary>
        private void MostrarDatosTecnico()
        {
            if (tecnico != null)
            {
                tecnico = Gestion.ListarTecnicoCompleto(tecnico.Id);
                if (tecnico != null)
                {
                    tbNombreTecnico.DataContext = tecnico;
                    lbAvisosCerrados.Content = tecnico.Avisos.Count;

                    if (tecnico.Especialista == true)
                        lbEspecialista.Visibility = Visibility.Visible;
                    if (tecnico.TieneCertificado == true)
                        lbCertificado.Visibility = Visibility.Visible;

                    ICollection<ConsumosMaterial>? consumosMaterial = tecnico.ConsumosMaterials;
                    if (consumosMaterial != null)
                    {
                        consumosMaterial = Gestion.ListarConsumosMaterialCompleto(consumosMaterial.ToList());
                        if (consumosMaterial != null)
                        {
                            foreach (ConsumosMaterial cm in consumosMaterial)
                            {
                                if (!ConsumoMaterialInformeContiene(cm.PiezaId, listaConsumosMaterialInforme))
                                {
                                    listaConsumosMaterialInforme.Add(new ConsumoMaterialInforme(
                                        cm.PiezaId, cm.Pieza.Nombre, cm.Pieza.Consumible,
                                        Gestion.CalcularCantidadTotalConsumida(cm.PiezaId, cm.TecnicoId, consumosMaterial)));
                                }
                            }
                        }                        
                    }
                    foreach (ConsumoMaterialInforme cmi in listaConsumosMaterialInforme)
                    {
                        dgConsumosMaterial.Items.Add(cmi);
                    }
                    //dgConsumosMaterial.DataContext = listaConsumosMaterialInforme;
                }                
            }             
        }

        /// <summary>
        /// Comprueba si la pieza que se pasa como parámtero, ya existe en la lista de consumos de material
        /// </summary>
        /// <param name="piezaId">id de la pieza</param>
        /// <param name="consumosMaterialInforme">lista de consumos de material</param>
        /// <returns></returns>
        public bool ConsumoMaterialInformeContiene(long piezaId, List<ConsumoMaterialInforme> consumosMaterialInforme)
        {
            foreach (ConsumoMaterialInforme cmi in consumosMaterialInforme)
            {
                if (cmi.PiezaId == piezaId)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Abre la ventana de impresión del documento generado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnImprimir_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog pd = new PrintDialog();
            if (pd.ShowDialog() == true)
            {
                IDocumentPaginatorSource idp = informe;
                pd.PrintDocument(idp.DocumentPaginator, "Informe técnico");
            }

            FlowDocumentPageViewer visual = (FlowDocumentPageViewer)(FindName("informeTecnico"));
            visual.MaxHeight = 2000;            

            /*
            try
            {
                // write the XPS document
                using (XpsDocument doc = new XpsDocument("printPreview.xps", FileAccess.Write))
                {
                    XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(doc);
                    writer.Write(visual);
                }

                // Read the XPS document into a dynamically generated
                // preview Window 
                Window preview = new ImpresionInformeTecnico(visual);
                using (XpsDocument doc = new XpsDocument("printPreview.xps", FileAccess.Read))
                {
                    FixedDocumentSequence fds = doc.GetFixedDocumentSequence();

                    DocumentViewer dv1 = LogicalTreeHelper.FindLogicalNode(preview, "vistaPrevia") as DocumentViewer;
                    dv1.Document = fds as IDocumentPaginatorSource;

                    // Eliminamos la ventana de búsqueda
                    ContentControl cc = dv1.Template.FindName("PART_FindToolBarHost", dv1) as ContentControl;
                    cc.Visibility = Visibility.Collapsed;
                }
                preview.ShowDialog();

            }
            finally
            {
                if (File.Exists("printPreview.xps"))
                {
                    try
                    {
                        File.Delete("printPreview.xps");
                    }
                    catch
                    {
                    }
                }
            }*/
        }
    }    
}
