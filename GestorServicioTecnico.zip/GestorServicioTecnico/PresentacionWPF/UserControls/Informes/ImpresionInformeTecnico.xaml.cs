﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentacionWPF.UserControls.Informes
{
    /// <summary>
    /// Lógica de interacción para ImpresionInformeTecnico.xaml
    /// </summary>
    public partial class ImpresionInformeTecnico : Window
    {
        private FlowDocumentScrollViewer? _document;

        public ImpresionInformeTecnico()
        {
            InitializeComponent();
        }

        public ImpresionInformeTecnico(FlowDocumentScrollViewer document)
        {
            _document = document;
            InitializeComponent();
            vistaPrevia.Document = document as IDocumentPaginatorSource;
            // Eliminamos la ventana de búsqueda
            DocumentViewer dv1 = LogicalTreeHelper.FindLogicalNode(this, "vistaPrevia") as DocumentViewer;
            ContentControl cc = dv1.Template.FindName("PART_FindToolBarHost", dv1) as ContentControl;
            if (cc != null)
                cc.Visibility = Visibility.Collapsed;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            _document = null;
        }
    }
}
