﻿using Modelos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentacionWPF.UserControls.Avisos
{
    /// <summary>
    /// Lógica de interacción para InformacionCompletaAviso.xaml
    /// </summary>
    public partial class InformacionCompletaAviso : Window
    {
        private Aviso? aviso;
        private Producto? producto;
        private IList<Aviso>? historicoAvisosProducto;

        /// <summary>
        /// Constructor sin parámetros
        /// </summary>
        public InformacionCompletaAviso()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Constructor que recibe el aviso para mostrar la información
        /// </summary>
        /// <param name="aviso"></param>
        public InformacionCompletaAviso(Aviso aviso) : this()
        {
            this.aviso = Gestion.ListarAvisoCompleto(aviso.Id);
            this.DataContext = aviso;
            if (aviso.Km == null)
                lbKm.Content = "Sin desplazamiento";

            producto = Gestion.ListarProductoCompleto(aviso.NumeroSerieProducto);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (aviso != null)
            {
                stackAviso.DataContext = aviso;
                MarcarAvisoFueraDePlazo();    
                MostrarConsumosMaterial();
                MostrarHistoricoAvisosProducto();
            }
        }

        /// <summary>
        /// Muestra el histórico de avisos asociados al producto del aviso del que se muestra la información
        /// </summary>
        private void MostrarHistoricoAvisosProducto()
        {
            if (producto != null)
            {
                historicoAvisosProducto = producto.Avisos.ToList();
                // Extraigo la información completa de los avisos asociados al producto, para mostrar correctamente datos como el nombre del técnico
                if (historicoAvisosProducto != null)
                {
                    IList<Aviso> historicoAvisosCompleto = new List<Aviso>();
                    foreach (Aviso aviso in historicoAvisosProducto)
                    {
                        Aviso? a = Gestion.ListarAvisoCompleto(aviso.Id);
                        if (a != null)
                            historicoAvisosCompleto.Add(a);
                    }
                    stackHistorico.DataContext = historicoAvisosCompleto;
                }
            }            
        }

        /// <summary>
        /// Muestra el valor de aviso incumplido y las fechas en rojo, si se ha cerrado fuera de plazo
        /// </summary>
        private void MarcarAvisoFueraDePlazo()
        {
            if (aviso != null && aviso.AvisoFueraDePlazo)
            {
                lbIncumplido.Visibility = Visibility.Visible;
                lbIncumplido.Foreground = (Brush)Application.Current.Resources["colorTextoError"];                
            }
        }

        /// <summary>
        /// Muestra los consumos de material
        /// </summary>
        private void MostrarConsumosMaterial()
        {
            IList<ConsumosMaterial>? consumosMaterial = Gestion.ListarConsumosMaterialPorAvisoCompleto(aviso!.Id);
            dgConsumosMaterial.DataContext = consumosMaterial;
        }

        /// <summary>
        /// Cierra el formulario y vuelve a la vista de los avisos
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnVolver_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Muestra información adicional del aviso
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void iconoMasInformacion_Click(object sender, RoutedEventArgs e)
        {
            aviso = (Aviso)dgAvisos.SelectedItem;
            InformacionCompletaAviso infoCompleta = new InformacionCompletaAviso(aviso);
            infoCompleta.ShowDialog();
        }
    }
}
