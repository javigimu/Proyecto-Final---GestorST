﻿using Modelos;
using Negocio;
using PresentacionWPF.Dialogos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentacionWPF.UserControls.Avisos
{
    /// <summary>
    /// Lógica de interacción para GestionarAviso.xaml
    /// </summary>
    public partial class GestionarAviso : Window
    {
        Aviso? aviso;
        Coordinadore? coordinador;
        Tecnico? tecnico;
        string? vistaAviso;
        string? operacion;
        IList<Producto>? productos;
        private IList<ConsumosMaterial>? listaConsumosMaterial;

        public GestionarAviso()
        {
            InitializeComponent();
            aviso = new Aviso();
            this.DataContext = aviso;
        }

        /// <summary>
        /// Constructor con el aviso, vistaAviso (coordinador o técnico) y operación
        /// </summary>
        /// <param name="aviso">aviso</param>
        /// <param name="vistaAviso">vista del aviso</param>
        /// <param name="operacion">operacion</param>
        public GestionarAviso(Aviso aviso, Coordinadore coordinador, string vistaAviso, string operacion) : this()
        {
            if (operacion == FormularioPrincipal.AVISOS_CREAR)
                this.aviso = new Aviso();
            else
            {
                this.aviso = aviso;
                MostrarEstado();
                lbNombreCliente.DataContext = aviso.Cliente;
            }               

            if (coordinador != null)
            {
                this.coordinador = coordinador;
                aviso.CoordinadorId = coordinador.Id;
            }                

            this.vistaAviso = vistaAviso;
            this.operacion = operacion;
            MostrarTitulo();
        }


        /// <summary>
        /// Constructor con el aviso, el técnico, vista del aviso y la operación
        /// </summary>
        /// <param name="aviso">aviso</param>
        /// <param name="tecnico">técnico</param>
        /// <param name="vistaAviso">vista del aviso</param>
        /// <param name="operacion">operación</param>
        public GestionarAviso(Aviso aviso, Tecnico tecnico, string vistaAviso, string operacion) : this()
        {
            if (operacion == FormularioPrincipal.AVISOS_CREAR)
                this.aviso = new Aviso();
            else
            {
                this.aviso = aviso;
                MostrarEstado();
                lbNombreCliente.DataContext = aviso.Cliente;
            }

            if (vistaAviso == FormularioPrincipal.AVISOS_VISTA_TECNICO)
            {
                this.tecnico = tecnico;
                aviso.Tecnico = tecnico;
            }                

            this.vistaAviso = vistaAviso;
            this.operacion = operacion;
            MostrarTitulo();
        }

        /// <summary>
        /// Al cargar el formulario se preparan los datos
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            productos = Gestion.ListarProductos();
            this.DataContext = aviso;
            if (aviso != null && aviso.TecnicoId != null)
            {
                aviso.Tecnico = Gestion.ListarTecnico((int)aviso.TecnicoId);                
                stackTecnico.DataContext = aviso.Tecnico;
            }

            if (vistaAviso == FormularioPrincipal.AVISOS_VISTA_COORDINADOR)
            {
                switch (operacion)
                {
                    case FormularioPrincipal.AVISOS_CREAR:                    
                        gbEstado.Visibility = Visibility.Hidden;
                        stackKilometros.Visibility = Visibility.Hidden;
                        break;

                    case FormularioPrincipal.AVISOS_MODIFICAR:
                        this.DataContext = aviso;
                        BloquearCamposNoModificables();

                        break;
                    case FormularioPrincipal.AVISOS_CERRAR:                        
                        this.DataContext = aviso;
                        BloquearCamposNoModificables();
                        BloquearEstados();
                        MostrarCamposCierre();                        
                        break;                    
                }
            } 
            else if (vistaAviso == FormularioPrincipal.AVISOS_VISTA_TECNICO)
            {               
                BloquearCamposNoModificables();
                tbHorasResolucion.IsReadOnly = true;
                tbDescripcion.IsReadOnly = true;
                switch (operacion)
                {
                    case FormularioPrincipal.AVISOS_MODIFICAR:
                        if (rbEstadoEspera.IsChecked == true)
                        {
                            rbEstadoDesplazamiento.IsChecked = true;
                            rbEstadoCerrado.Visibility = Visibility.Collapsed;
                        }
                        
                        break;
                    case FormularioPrincipal.AVISOS_CERRAR:
                        BloquearEstados();
                        stackReparacion.Visibility = Visibility.Visible;
                        stackConsumoMaterial.Visibility = Visibility.Visible;

                        break;
                }
            }
        }

        /// <summary>
        /// Muestra los campos ocultos para rellenar en un cierre de aviso
        /// </summary>
        private void MostrarCamposCierre()
        {
            stackReparacion.Visibility = Visibility.Visible;
            stackConsumoMaterial.Visibility = Visibility.Visible;
        }

        /// <summary>
        /// Oculta y vacía los campos de cierre de aviso
        /// </summary>
        private void OcultarCamposCierre()
        {
            stackReparacion.Visibility = Visibility.Collapsed;
            stackConsumoMaterial.Visibility = Visibility.Collapsed;
            
        }

        /// <summary>
        /// Muestra en la parte superior de la ventana, el título correspondiente según la operación, siendo la inserción el valor por defecto
        /// </summary>
        /// <param name="operacion">modificar o borrar</param>
        /// <exception cref="NotImplementedException"></exception>
        private void MostrarTitulo()
        {
            tbTituloOperacion.Text = operacion!.ToUpper();
            if (operacion == FormularioPrincipal.AVISOS_CERRAR)
                btnResetear.Visibility = Visibility.Hidden;
        }

        /// <summary>
        /// Bloquea los estados, para permitir únicamente el cierre del aviso
        /// </summary>
        private void BloquearEstados()
        {
            rbEstadoCerrado.IsChecked = true;
            rbEstadoDesplazamiento.Visibility = Visibility.Collapsed;
            rbEstadoReparando.Visibility = Visibility.Collapsed;
            rbEstadoEspera.Visibility = Visibility.Collapsed;
        }

        /// <summary>
        /// En la modificación de un aviso se bloquean los campos no editables
        /// </summary>
        private void BloquearCamposNoModificables()
        {
            btnBuscarCliente.Visibility = Visibility.Hidden;
            btnBuscarProducto.Visibility = Visibility.Hidden;
            tbNumeroSerie.IsReadOnly = true;
        }

        /// <summary>
        /// Sólo permite introducir números en un textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        /// <summary>
        /// Muestra el formulario de búsqueda de producto
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBuscarProducto_Click(object sender, RoutedEventArgs e)
        {
            BuscarProducto dialogoProducto;
            if (aviso != null && aviso.Cliente != null)
                dialogoProducto = new BuscarProducto(aviso.ClienteId);                         
            else
                dialogoProducto = new BuscarProducto();

            dialogoProducto.ShowDialog();
            if (aviso != null && dialogoProducto.DialogResult == true)
            {
                aviso.NumeroSerieProducto = dialogoProducto.ProductoSeleccionado!.NumeroSerie;
                aviso.NumeroSerieProductoNavigation = dialogoProducto.ProductoSeleccionado!;
                this.DataContext = aviso;
            }
        }

        /// <summary>
        /// Muestra el formulario de búsqueda de técnico
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBuscarTecnico_Click(object sender, RoutedEventArgs e)
        {
            BuscarTecnico dialogoTecnico = new BuscarTecnico();
            dialogoTecnico.ShowDialog();
            if (aviso != null && dialogoTecnico.DialogResult == true)
            {
                aviso.TecnicoId = dialogoTecnico.TecnicoSeleccionado!.Id;
                aviso.Tecnico = dialogoTecnico.TecnicoSeleccionado!;
                stackTecnico.DataContext = aviso.Tecnico;
            }
        }

        /// <summary>
        /// Muestra el formulario de búsqueda de cliente
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBuscarCliente_Click(object sender, RoutedEventArgs e)
        {
            BuscarCliente dialogoCliente = new BuscarCliente();
            dialogoCliente.ShowDialog();
            if (aviso != null && dialogoCliente.ClienteSeleccionado!= null && dialogoCliente.DialogResult == true)
            {
                aviso.ClienteId = dialogoCliente.ClienteSeleccionado.Id;
                aviso.Cliente = dialogoCliente.ClienteSeleccionado;
                lbNombreCliente.DataContext = aviso.Cliente;
                tbNumeroSerie.Clear();
            }
        }

        /// <summary>
        /// Verificar que no haya ningún campo con error de validación
        /// </summary>
        /// <returns></returns>
        private bool VerificarCamposValidados()
        {
            bool validacionOk = tbNumeroSerie.Text.Length > 0 && tbDescripcion.Text.Length > 0;

            if (Validation.GetHasError(tbNumeroSerie)) validacionOk = false;
            if (Validation.GetHasError(tbDescripcion)) validacionOk = false;
            if (Validation.GetHasError(tbReparacion)) validacionOk = false;
            if (Validation.GetHasError(tbKilometros)) validacionOk = false;
            if (Validation.GetHasError(tbHorasResolucion)) validacionOk = false;

            return validacionOk;
        }

        /// <summary>
        /// Verifica que todos los datos son correctas y crea el aviso
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAceptar_Click(object sender, RoutedEventArgs e)
        {
            if (VerificarCamposValidados())
            {
                textoAceptar.Foreground = (Brush)Application.Current.Resources["colorTextoInformacion"];

                if (aviso != null)
                {
                    IntroducirEstado();
                    string? fechaMaxResolucion = lbFechaMaximaResolucion.Content != null ? lbFechaMaximaResolucion.Content.ToString() : null;
                    if (fechaMaxResolucion != null)
                    {
                        DateTime fechaMaximaResolucion = DateTime.Parse(fechaMaxResolucion);
                        aviso.FechaMaximaFinalizacion = fechaMaximaResolucion;
                    }
                    
                    if (operacion == FormularioPrincipal.AVISOS_MODIFICAR)
                    {
                        Gestion.ActualizarAviso(aviso);
                        textoAceptar.Content = "Aviso modificado correctamente!!";
                    }
                    else if (operacion == FormularioPrincipal.AVISOS_CREAR)
                    {
                        if (coordinador != null)
                            aviso.CoordinadorId = coordinador.Id;

                        Gestion.InsertarAviso(aviso);
                        textoAceptar.Content = "Aviso insertado correctamente!!";
                        ResetearAviso();
                    } 
                    else if (operacion == FormularioPrincipal.AVISOS_CERRAR)
                    {
                        aviso.FechaFinalizacion = DateTime.Now;
                        Gestion.ActualizarAviso(aviso);
                        ActualizarInventarioTecnico();
                        textoAceptar.Content = "Aviso cerrado correctamente!!";
                    }
                }
            }
            else
            {
                if (rbEstadoCerrado.IsChecked == true)
                {
                    if (lbNombreCliente.Text.Length == 0)
                        textoAceptar.Content = "El cliente no puede estar vacío";
                    else if (tbNumeroSerie.Text.Length == 0)
                        textoAceptar.Content = "El número de serie del producto no puede estar vacío";
                    else if (tbReparacion.Text.Length == 0)
                        textoAceptar.Content = "Debes indicar la reparación realizada";
                }  
                   
                textoAceptar.Foreground = (Brush)Application.Current.Resources["colorTextoError"];
                textoAceptar.Visibility = Visibility.Visible;
            }
        }

        /// <summary>
        /// Cambia el estado
        /// </summary>
        /// <exception cref="NotImplementedException"></exception>
        private void IntroducirEstado()
        {
            if (aviso != null)
            {
                if (rbEstadoEspera.IsChecked == true)
                    aviso.Estado = "espera";
                else if (rbEstadoDesplazamiento.IsChecked == true)
                    aviso.Estado = "desplazamiento";
                else if (rbEstadoReparando.IsChecked == true)
                    aviso.Estado = "reparando";
                else
                    aviso.Estado = "cerrado";
            }
        }

        /// <summary>
        /// Muestra el estado en el radiobutton correspondiente
        /// </summary>
        /// <exception cref="NotImplementedException"></exception>
        private void MostrarEstado()
        {
            if (aviso != null)
            {                  
                switch (aviso.Estado.Trim())
                {
                    case "espera": rbEstadoEspera.IsChecked = true; break;
                    case "desplazamiento": rbEstadoDesplazamiento.IsChecked = true; break;
                    case "reparando": rbEstadoReparando.IsChecked = true; break;
                    case "cerrado": rbEstadoCerrado.IsChecked = true; break;
                    default: rbEstadoEspera.IsChecked = true; break;
                }
            }
        }

        /// <summary>
        /// Resetea el aviso y se vacían los campos
        /// </summary>
        public void ResetearAviso()
        {
            aviso = new Aviso();            
            this.DataContext = aviso;
            lbNombreCliente.DataContext = aviso;
            stackTecnico.DataContext = aviso;
        }

        /// <summary>
        /// Resetea todos los campos del formulario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnResetear_Click(object sender, RoutedEventArgs e)
        {
            ResetearAviso();
        }

        /// <summary>
        /// Salir del formulario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            ConfirmacionSalida mensaje = new ConfirmacionSalida("Confirma que desea salir?");
            mensaje.ShowDialog();
            if (mensaje.DialogResult == true)
            {
                this.DialogResult = true;
                Close();
            }                
        }

        /// <summary>
        /// Añadir consumo de material
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnConsumirMaterial_Click(object sender, RoutedEventArgs e)
        {
            ConsumirMaterial consumirMaterial = new ConsumirMaterial(aviso!.Tecnico!, aviso!.Id);
            consumirMaterial.ShowDialog();
            if (consumirMaterial.DialogResult == true)
            {
                listaConsumosMaterial = consumirMaterial.ListaConsumosMaterial;
            }
        }

        /// <summary>
        /// Actualiza el inventario del técnico retirando los consumos de material
        /// </summary>
        private void ActualizarInventarioTecnico()
        {
            if (listaConsumosMaterial != null)
            {
                foreach (ConsumosMaterial cm in listaConsumosMaterial)
                {
                    List<InventarioTecnico> listaInventariosTecnico = cm.Pieza.InventarioTecnicos.ToList();
                    listaInventariosTecnico[0].Cantidad -= cm.Cantidad;
                    if (listaInventariosTecnico[0].Cantidad <= 0)
                        Gestion.BorrarInventarioTecnico(listaInventariosTecnico[0]);
                    else
                        Gestion.ActualizarInventarioTecnico(listaInventariosTecnico[0]);
                }

                Gestion.InsertarListaConsumosMaterial(listaConsumosMaterial);
            }
        }
    }
}
