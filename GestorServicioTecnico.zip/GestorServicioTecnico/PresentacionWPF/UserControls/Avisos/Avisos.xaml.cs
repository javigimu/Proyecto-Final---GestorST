﻿using Modelos;
using Negocio;
using PresentacionWPF.UserControls.Piezas;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PresentacionWPF.UserControls.Avisos
{
    /// <summary>
    /// Lógica de interacción para Avisos.xaml
    /// </summary>
    public partial class Avisos : UserControl
    {
        private Aviso? aviso;
        private Coordinadore? coordinador;
        private Tecnico? tecnico;
        private ObservableCollection<Aviso>? listaObservableAvisos;
        private CollectionViewSource miVista;
        private string? textoFiltrado;
        string? vistaAviso;
        string? operacion;

        public Avisos()
        {
            InitializeComponent();
            aviso = new Aviso();
            miVista = (CollectionViewSource)FindResource("listaAvisos");
            textoFiltrado = "";
        }

        /// <summary>
        /// Constructor específico para los coordinadores
        /// </summary>
        /// <param name="coordinador"></param>
        /// <param name="vistaAvisos"></param>
        public Avisos(Coordinadore coordinador, string operacion) : this()
        {           
            this.coordinador = coordinador;            
            this.operacion = operacion;
            vistaAviso = FormularioPrincipal.AVISOS_VISTA_COORDINADOR;
        }

        /// <summary>
        /// Constructor específico para los técnicos
        /// </summary>
        /// <param name="tecnico"></param>
        /// <param name="operacion"></param>
        public Avisos(Tecnico tecnico, string operacion) : this()
        {
            this.tecnico = tecnico;
            this.operacion = operacion;
            vistaAviso = FormularioPrincipal.AVISOS_VISTA_TECNICO;            
        }

        /// <summary>
        /// Para los técnicos, se elimina la opción de cierre definitivo del aviso
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgAvisos_LoadingRow(object sender, DataGridRowEventArgs e)
        {         
            if (coordinador == null)
                colCerrarAviso.Visibility = Visibility.Collapsed;
        }

        /// <summary>
        /// Muestra la información básica de los avisos con opción a ver toda la información detallada
        /// </summary>
        private void MostrarAvisos()
        {
            ICollection<Aviso>? avisos;
            if (vistaAviso == FormularioPrincipal.AVISOS_VISTA_TECNICO && tecnico != null)
                avisos = Gestion.ListarAvisosTecnicoCompleto(tecnico.Id);
            else
                avisos = Gestion.ListarAvisosCompleto();

            if (avisos != null)
                avisos = avisos.OrderByDescending(aviso => aviso.FechaMaximaFinalizacion)
                    .ThenBy(aviso => aviso.FechaEntrada).ToList();

            if (avisos != null)
                listaObservableAvisos = new ObservableCollection<Aviso>(avisos);
            else
                listaObservableAvisos = new ObservableCollection<Aviso>();

            miVista.Source = listaObservableAvisos;
        }

        /// <summary>
        /// Inicialmente se muestran los datos de todos los avisos que hay en la base de datos
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            miVista.Source = listaObservableAvisos;
            aviso = (Aviso)dgAvisos.SelectedItem;

            if (vistaAviso == FormularioPrincipal.AVISOS_VISTA_TECNICO)
            {
                DeshabilitarOpcionesCoordinador();                
            }
            MostrarAvisos();
        }

        /// <summary>
        /// Oculta las opciones no accesibles para un técnico
        /// </summary>
        private void DeshabilitarOpcionesCoordinador()
        {
            btnNuevoAviso.Visibility = Visibility.Collapsed;
            MenuItemAnyadirAviso.Visibility = Visibility.Collapsed;
            MenuItemConfirmarCierreAviso.Visibility = Visibility.Collapsed;
        }

        /// <summary>
        /// Reacciona cada vez que se introduce un carácter en el texbox de filtrado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbTextoFiltrado_KeyUp(object sender, KeyEventArgs e)
        {
            textoFiltrado = tbTextoFiltrado.Text.Trim().ToLower();
            miVista.Filter += FiltrarPorNumeroSerieDescripcion;
        }

        /// <summary>
        /// Filtra las piezas cuyo nombre o descripción contengan el texto introducido por el usuario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FiltrarPorNumeroSerieDescripcion(object sender, FilterEventArgs e)
        {
            Aviso avisoFiltrado = (Aviso)e.Item;
            if (avisoFiltrado != null)
            {
                string numeroSerie = avisoFiltrado.NumeroSerieProducto == null ? "" : avisoFiltrado.NumeroSerieProducto;
                string descripcion = avisoFiltrado.Descripcion == null ? "" : avisoFiltrado.Descripcion;

                if (numeroSerie.ToLower().Contains(textoFiltrado!.ToLower()) ||
                    descripcion.ToLower().Contains(textoFiltrado!.ToLower()))
                {
                    e.Accepted = true;
                }
                else
                {
                    e.Accepted = false;
                }
            }
        }

        /// <summary>
        /// Crear nuevo aviso a través del botón
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AnyadirNuevoAviso(object sender, RoutedEventArgs e)
        {
            CrearAviso();
        }


        /// <summary>
        /// Crear nuevo aviso a través del menú contextual
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemCrearAviso_Click(object sender, RoutedEventArgs e)
        {
            CrearAviso();
        }

        /// <summary>
        /// Abre un diálogo para crear un nuevo aviso
        /// </summary>
        private void CrearAviso()
        {
            aviso = new Aviso();
            GestionarAviso dialogoAviso = new GestionarAviso(aviso, coordinador!,
                FormularioPrincipal.AVISOS_VISTA_COORDINADOR, FormularioPrincipal.AVISOS_CREAR);
            dialogoAviso.ShowDialog();
            MostrarAvisos();
        }


        /// <summary>
        /// Cierra un aviso a través de una doble pulsación del ratón
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgAvisos_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            CerrarAviso();
        }

        /// <summary>
        /// Modificar un aviso a través del menú contextual
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemModificarAviso_Click(object sender, RoutedEventArgs e)
        {
            ModificarAviso();
        }

        /// <summary>
        /// Abre un diálogo con la información del aviso a modificar
        /// </summary>
        private void ModificarAviso()
        {
            aviso = (Aviso)dgAvisos.SelectedItem;
            if (aviso.CierreConfirmado == true)
            {
                MensajeConfirmacion mensaje = new MensajeConfirmacion("El aviso tiene cierre confirmado y no se puede modificar");
                mensaje.ShowDialog();
            }
            else if (aviso != null)
            {
                GestionarAviso dialogoAviso;
                if (coordinador != null)
                    dialogoAviso = new GestionarAviso(aviso, coordinador, FormularioPrincipal.AVISOS_VISTA_COORDINADOR, FormularioPrincipal.AVISOS_MODIFICAR!);
                else
                    dialogoAviso = new GestionarAviso(aviso, tecnico!, FormularioPrincipal.AVISOS_VISTA_TECNICO, FormularioPrincipal.AVISOS_MODIFICAR!);

                dialogoAviso.ShowDialog();
                if (dialogoAviso.DialogResult == true)
                {
                    MostrarAvisos();
                }
            }
            else
            {
                MensajeConfirmacion mensaje = new MensajeConfirmacion("Debes seleccionar un aviso a modificar");
                mensaje.ShowDialog();
            }
        }

        /// <summary>
        /// Cierrar el aviso seleccionado a través del botón
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnContextualCerrarAviso_Click(object sender, RoutedEventArgs e)
        {
            CerrarAviso();
        }

        /// <summary>
        /// Cierra el aviso seleccionado a través de la opción del menú contextual
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemCerrarAviso_Click(object sender, RoutedEventArgs e)
        {
            CerrarAviso();
        }

        /// <summary>
        /// Cierra un aviso, si es un coordinador lo podrá cerrar definitivamente
        /// </summary>
        private void CerrarAviso()
        {
            GestionarAviso gestionarAviso;
            aviso = (Aviso)dgAvisos.SelectedItem;
            if (aviso.CierreConfirmado == true)
            {
                MensajeConfirmacion mensaje = new MensajeConfirmacion("El aviso tiene cierre confirmado y no se puede volver a cerrar");
                mensaje.ShowDialog();
            }
            else if (aviso.Estado == "cerrado")
            {
                MensajeConfirmacion mensaje = new MensajeConfirmacion("El aviso ya está cerrado");
                mensaje.ShowDialog();
            }
            else if (aviso != null)
            {
                if (coordinador != null)
                {
                    gestionarAviso = new GestionarAviso(aviso, coordinador, vistaAviso!, FormularioPrincipal.AVISOS_CERRAR);                    
                }
                else
                {
                    gestionarAviso = new GestionarAviso(aviso, tecnico!, vistaAviso!, FormularioPrincipal.AVISOS_CERRAR);
                }       
                
                gestionarAviso.ShowDialog();
                if (gestionarAviso.DialogResult == true)
                {
                    MostrarAvisos();
                }
            }
            else
            {
                MensajeConfirmacion mensaje = new MensajeConfirmacion("Debes seleccionar un aviso a cerrar");
            }
        }
        

        /// <summary>
        /// Confirma el cierre del aviso definitivamente
        /// </summary>
        private void ConfirmarCierreAvisoDefinitivo()
        {
            aviso = (Aviso)dgAvisos.SelectedItem;
            if (aviso.CierreConfirmado == true)
            {
                MensajeConfirmacion mensaje = new MensajeConfirmacion("El aviso ya está cerrado y confirmado");
                mensaje.ShowDialog();
            }
            else if (aviso.Estado == FormularioPrincipal.AVISO_CERRADO)
            {
                ConfirmacionSalida dialogoConfirmacion = new ConfirmacionSalida("El aviso se cerrará definitivamente, ¿desea continuar?");
                dialogoConfirmacion.ShowDialog();
                if (dialogoConfirmacion.DialogResult == true)
                {
                    aviso.CierreConfirmado = true;
                    Gestion.ActualizarAviso(aviso);
                    MostrarAvisos();
                }
            }
            else
            {
                MensajeConfirmacion mensaje;
                if (aviso.CierreConfirmado == true)
                    mensaje = new MensajeConfirmacion("El aviso está cerrado definitivamente y no se puede modificar");                
                else
                    mensaje = new MensajeConfirmacion("El aviso está en estado \"" + aviso.Estado.Trim() + "\"\nPrimero debe cerrar el aviso");

                mensaje.ShowDialog();
                if (mensaje.DialogResult == true)
                {
                    MostrarAvisos();
                }
            }
           
        }

        /// <summary>
        /// Cierra definitivamente el aviso seleccionado a través del icono de cierre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCerrarAviso_Click(object sender, RoutedEventArgs e)
        {
            ConfirmarCierreAvisoDefinitivo();
        }

        /// <summary>
        /// Cierra un aviso definitivamente
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemConfirmarCierreAviso_Click(object sender, RoutedEventArgs e)
        {
            ConfirmarCierreAvisoDefinitivo();
        }

        /// <summary>
        /// Abre el formulario de modificación del aviso a través del botón
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnContextualModificarAviso_Click(object sender, RoutedEventArgs e)
        {
            ModificarAviso();
        }

        /// <summary>
        /// Cerrar Aviso a gravés del botón superior
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCerrarAviso_Click_1(object sender, RoutedEventArgs e)
        {
            CerrarAviso();
        }

        /// <summary>
        /// Modificar aviso a través del botón superior
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnModificarAviso_Click(object sender, RoutedEventArgs e)
        {
            ModificarAviso();
        }

        /// <summary>
        /// Muestra información adicional del aviso
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void iconoMasInformacion_Click(object sender, RoutedEventArgs e)
        {
            aviso = (Aviso)dgAvisos.SelectedItem;
            InformacionCompletaAviso infoCompleta = new InformacionCompletaAviso(aviso);
            infoCompleta.ShowDialog();
        }

        /// <summary>
        /// Al marcar el checkbox, se desmarca el checkbox de avisos sin asignar.
        /// Si se queda desmarcado, se muestran todos los avisos
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbVerAvisosAbiertos_Click(object sender, RoutedEventArgs e)
        {
            cbVerAvisosSinAsignar.IsChecked = false;
            miVista.Filter += DesmarcarFiltro;

            if (cbVerAvisosAbiertos.IsChecked == true)
            {
                miVista.Filter += FiltrarPorEstadoAbierto;
            }
        }

        /// <summary>
        /// Al marcar el checkbox, se desmarca el checkbox de avisos abiertos.
        /// Si se queda desmarcado, se muestran todos los avisos
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbVerAvisosSinAsignar_Click(object sender, RoutedEventArgs e)
        {
            cbVerAvisosAbiertos.IsChecked = false;
            miVista.Filter += DesmarcarFiltro;

            if (cbVerAvisosSinAsignar.IsChecked == true)
            {
                miVista.Filter += FiltrarPorEstadoEspera;
            }
        }

        /// <summary>
        /// Filtra las piezas cuyo estado no es cerrado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FiltrarPorEstadoAbierto(object sender, FilterEventArgs e)
        {
            Aviso avisoFiltrado = (Aviso)e.Item;
            if (avisoFiltrado != null)
            {
                string estado = avisoFiltrado.Estado;
                if (estado.ToLower() != "cerrado")
                {
                    e.Accepted = true;
                }
                else
                {
                    e.Accepted = false;
                }
            }
        }

        /// <summary>
        /// Filtra las piezas cuyo estado no es cerrado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FiltrarPorEstadoEspera(object sender, FilterEventArgs e)
        {
            Aviso avisoFiltrado = (Aviso)e.Item;
            if (avisoFiltrado != null)
            {
                string estado = avisoFiltrado.Estado;
                if (estado.ToLower() == "espera" && avisoFiltrado.TecnicoId == null)
                {
                    e.Accepted = true;
                }
                else
                {
                    e.Accepted = false;
                }
            }
        }

        /// <summary>
        /// Retira el filtro del estado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DesmarcarFiltro(object sender, FilterEventArgs e)
        {
            Aviso avisoFiltrado = (Aviso)e.Item;
            if (avisoFiltrado != null)
            {
                string estado = avisoFiltrado.Estado;
                if (estado.ToLower() != "todos")
                {
                    e.Accepted = true;
                }
                else
                {
                    e.Accepted = false;
                }
            }
        }
    }
}
