﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentacionWPF
{
    /// <summary>
    /// Lógica de interacción para ConfirmacionSalida.xaml
    /// </summary>
    public partial class ConfirmacionSalida : Window
    {
        /// <summary>
        /// Pide confirmación al usuario
        /// </summary>
        /// <param name="pregunta">pregunta para que el usuario confirme o cancele</param>
        public ConfirmacionSalida(string pregunta)
        {
            InitializeComponent();
            lbPregunta.Content = pregunta;
        }

        /// <summary>
        /// Reacciona a la pulsación del botón aceptar
        /// </summary>
        /// <param name="sender">btnDialogOk</param>
        /// <param name="e">evento click</param>
        private void btnDialogOk_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }
    }
}
