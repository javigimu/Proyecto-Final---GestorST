﻿using Modelos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentacionWPF.Dialogos
{
    /// <summary>
    /// Lógica de interacción para ConsumirMaterial.xaml
    /// </summary>
    public partial class ConsumirMaterial : Window
    {
        private long avisoId;
        private Tecnico? tecnico;
        public IList<ConsumosMaterial> ListaConsumosMaterial { get; set; }        

        /// <summary>
        /// Constructor principal con la inicialización de la lista de consumos de material
        /// </summary>
        public ConsumirMaterial()
        {
            InitializeComponent();
            ListaConsumosMaterial= new List<ConsumosMaterial>();
        }

        /// <summary>
        /// Constructor que recibe el técnico que realiza el consumo de material y el aviso donde realiza el consumo
        /// </summary>
        /// <param name="tecnico">técnico</param>
        /// <param name="avisoId">id del aviso</param>
        public ConsumirMaterial(Tecnico tecnico, long avisoId) : this()
        {
            this.tecnico = tecnico;
            this.avisoId = avisoId;
        }

        /// <summary>
        /// Carga los datos y en caso de no ser técnico, se pide el técnico del que se desea crear el consumo de material
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ActualizarConsumosMaterial();
        }

        /// <summary>
        /// Añade un nuevo consumo de material
        /// </summary>
        private void AnyadirConsumoMaterial()
        {
            BuscarPieza buscarPieza;
            if (tecnico != null)
                buscarPieza = new BuscarPieza(tecnico);
            else
                buscarPieza= new BuscarPieza();

            buscarPieza.ShowDialog();
            if (buscarPieza.DialogResult == true && tecnico != null && buscarPieza.PiezaSeleccionada != null)
            {
                ConsumosMaterial consumoMaterial = new ConsumosMaterial(tecnico.Id, buscarPieza.PiezaSeleccionada.Id, avisoId);
                Pieza? piezaConsumida = Gestion.ListarPieza(consumoMaterial.PiezaId);
                if (piezaConsumida != null)
                {
                    piezaConsumida.InventarioTecnicos = buscarPieza.PiezaSeleccionada.InventarioTecnicos;
                    consumoMaterial.Pieza = piezaConsumida;
                }                    
                ListaConsumosMaterial.Add(consumoMaterial);
                
                ActualizarConsumosMaterial();
            }
        }

        /// <summary>
        /// Actualiza los consumos de material
        /// </summary>
        private void ActualizarConsumosMaterial()
        {
            dgConsumosMaterial.Items.Clear();
            foreach (ConsumosMaterial cm in ListaConsumosMaterial)
            {                
                dgConsumosMaterial.Items.Add(cm);
            }
        }

        /// <summary>
        /// Llama a AñadirConsumoMaterial desde el botón de nuevo consumo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNuevoConsumo_Click(object sender, RoutedEventArgs e)
        {
            AnyadirConsumoMaterial();
        }

        /// <summary>
        /// Llama a AñadirConsumoMaterial desde el menú contextual
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemAnyadirConsumoMaterial_Click(object sender, RoutedEventArgs e)
        {
            AnyadirConsumoMaterial();
        }

        /// <summary>
        /// Elimina un consumo de material
        /// </summary>
        private void EliminarConsumo()
        {
            ConsumosMaterial consumoMaterial = (ConsumosMaterial)dgConsumosMaterial.SelectedItem;
            ListaConsumosMaterial.Remove(consumoMaterial);
            ActualizarConsumosMaterial();
        }

        private void btnEliminarConsumo_Click(object sender, RoutedEventArgs e)
        {
            EliminarConsumo();
        }

        private void MenuItemEliminarConsumoMaterial_Click(object sender, RoutedEventArgs e)
        {
            EliminarConsumo();
        }

        private void btnEliminarRegistro_Click(object sender, RoutedEventArgs e)
        {
            EliminarConsumo();
        }

        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            Close();
        }

        /// <summary>
        /// Sólo permite introducir números en un textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        /// <summary>
        /// Verifica que la cantidad no sea superior a la que el técnico tiene en el inventario ni menor que 1
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbCantidad_KeyUp(object sender, KeyEventArgs e)
        {
            ConsumosMaterial cm = (ConsumosMaterial)dgConsumosMaterial.SelectedItem;
            List<InventarioTecnico> listaInventariosTecnico = cm.Pieza.InventarioTecnicos.ToList();
            if (cm.Cantidad < 1)
                cm.Cantidad = 1;
            else if (cm.Cantidad > listaInventariosTecnico[0].Cantidad)
                cm.Cantidad = listaInventariosTecnico[0].Cantidad;
        }

        /// <summary>
        /// Finaliza la introducción de consumos de material
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAceptar_Click(object sender, RoutedEventArgs e)
        {
            if (ListaConsumosMaterial.Count > 0)
            {
                this.DialogResult = true;
                Close();  
            }
        }        
    }
}
