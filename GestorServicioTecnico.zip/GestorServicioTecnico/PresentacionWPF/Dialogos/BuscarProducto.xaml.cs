﻿using Modelos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentacionWPF.Dialogos
{
    /// <summary>
    /// Lógica de interacción para BuscarProducto.xaml
    /// </summary>
    public partial class BuscarProducto : Window
    {
        public Producto? ProductoSeleccionado { get; set; }
        private Cliente? cliente;
        private ObservableCollection<Producto>? listaObservableProductos;
        private CollectionViewSource MiVista;
        private string? textoFiltrado;
        // variable para recibir si la operación a realizar en la búsqueda es una modificación o borrado
        string? operacion;

        /// <summary>
        /// Constructor principal
        /// </summary>
        public BuscarProducto()
        {
            InitializeComponent();
            ProductoSeleccionado = new Producto();
            MiVista = (CollectionViewSource)FindResource("listaProductos");
            MostrarProductos();
        }

        /// <summary>
        /// Constructor para buscar productos de un cliente
        /// </summary>
        /// <param name="cliente"></param>
        public BuscarProducto(long clienteId) : this()
        {
            cliente = Gestion.ListarClienteCompleto(clienteId);
            MostrarProductos();
        }

        /// <summary>
        /// Constructor que recibe como parámetro la opción a realizar tras la búsqueda
        /// </summary>
        /// <param name="operacion"></param>
        public BuscarProducto(string operacion) : this()
        {
            this.operacion = operacion;
        }

        /// <summary>
        /// Al cargar la página se establece la vista
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            MiVista.Source = listaObservableProductos;
        }

        /// <summary>
        /// Muestra un listado de todos los productos
        /// </summary>
        private void MostrarProductos()
        {
            ICollection<Producto>? productos;
            if (cliente == null)
                productos = Gestion.ListarProductos();
            else
                productos = cliente.Productos;

            if (productos != null)
            {
                foreach (Producto p in productos)
                {
                    p.NumeroSerie = p.NumeroSerie.Trim();
                    p.Fabricante = p.Fabricante.Trim();
                    p.Modelo = p.Modelo.Trim();
                    p.Ciudad = p.Ciudad != null? p.Ciudad.Trim() : null;
                    p.Direccion = p.Direccion != null? p.Direccion.Trim() : null;
                }

                listaObservableProductos = new ObservableCollection<Producto>(productos);
            }
            else
                listaObservableProductos = new ObservableCollection<Producto>();
            textoFiltrado = "";
        }

        /// <summary>
        /// Controla el doble click del ratón sobre un item del listview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void manejarDoubleClick(object sender, MouseButtonEventArgs e)
        {
            EnviarProductoSeleccionado();
        }

        /// <summary>
        /// Filtra los productos tras introducir texto en el campo tbTextoFiltrado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbTextoFiltrado_KeyUp(object sender, KeyEventArgs e)
        {
            textoFiltrado = tbTextoFiltrado.Text.Trim().ToLower();
            MiVista.Filter += Filtrar;
        }

        /// <summary>
        /// Filtra los productos cuyo nombre contengan el texto introducido por el usuario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Filtrar(object sender, FilterEventArgs e)
        {
            Producto prodFiltrado = (Producto)e.Item;
            if (prodFiltrado != null)
            {
                string numeroSerie = prodFiltrado.NumeroSerie == null ? "" : prodFiltrado.NumeroSerie;
                string fabricante = prodFiltrado.Fabricante == null ? "" : prodFiltrado.Fabricante;
                string modelo = prodFiltrado.Modelo == null ? "" : prodFiltrado.Modelo;
                string ciudad = prodFiltrado.Ciudad == null ? "" : prodFiltrado.Ciudad;
                string direccion = prodFiltrado.Direccion == null ? "" : prodFiltrado.Direccion;
                if (prodFiltrado.Nombre != null && prodFiltrado.Nombre.ToLower().Contains(textoFiltrado!) ||
                    prodFiltrado.Fabricante != null && prodFiltrado.Fabricante.ToLower().Contains(textoFiltrado!) ||
                    prodFiltrado.Modelo != null && prodFiltrado.Modelo.ToLower().Contains(textoFiltrado!) ||
                    prodFiltrado.Ciudad != null && prodFiltrado.Ciudad.ToLower().Contains(textoFiltrado!) ||
                    prodFiltrado.Direccion != null && prodFiltrado.Direccion.ToLower().Contains(textoFiltrado!))
                {
                    e.Accepted = true;
                }
                else
                {
                    e.Accepted = false;
                }
            }
        }

        /// <summary>
        /// Envía el producto seleccionado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSeleccionar_Click(object sender, RoutedEventArgs e)
        {
            EnviarProductoSeleccionado();
        }

        /// <summary>
        /// cierra el formulario con el cliente seleccionado
        /// </summary>
        private void EnviarProductoSeleccionado()
        {
            ProductoSeleccionado = (Producto)lvProductos.SelectedItem;
            DialogResult = true;
            this.Close();
        }
    }
}
