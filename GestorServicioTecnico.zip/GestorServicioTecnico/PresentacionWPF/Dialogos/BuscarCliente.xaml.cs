﻿using Modelos;
using Negocio;
using PresentacionWPF.UserControls;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentacionWPF.Dialogos
{
    /// <summary>
    /// Lógica de interacción para BuscarCliente.xaml
    /// </summary>
    public partial class BuscarCliente : Window
    {
        public Cliente? ClienteSeleccionado { get; set; }
        private ObservableCollection<Cliente>? listaObservableClientes;
        private CollectionViewSource MiVista;
        private string? textoFiltrado;
        // variable para recibir si la operación a realizar en la búsqueda es una modificación o borrado
        string? operacion;

        /// <summary>
        /// Constructor por defecto
        /// </summary>
        public BuscarCliente()
        {
            InitializeComponent();
            ClienteSeleccionado = new Cliente();
            MiVista = (CollectionViewSource)FindResource("listaClientes");
            MostrarClientes();
        }

        /// <summary>
        /// Constructor que recibe como parámetro la opción a realizar tras la búsqueda
        /// </summary>
        /// <param name="operacion"></param>
        public BuscarCliente(string operacion) : this()
        {
            this.operacion = operacion;
        }

        /// <summary>
        /// Al cargar la página se establece la vista
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            MiVista.Source = listaObservableClientes;
        }

        /// <summary>
        /// Muestra un listado de todos los clientes
        /// </summary>
        private void MostrarClientes()
        {
            ICollection<Cliente>? clientes = Gestion.ListarClientes();

            if (clientes != null)
            {
                foreach (Cliente c in clientes)
                {
                    c.Nombre = c.Nombre.Trim();                    
                }

                listaObservableClientes = new ObservableCollection<Cliente>(clientes);
            }
            else
                listaObservableClientes = new ObservableCollection<Cliente>();
            textoFiltrado = "";
        }


        /// <summary>
        /// Controla el doble click del ratón sobre un item del listview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void manejarDoubleClick(object sender, MouseButtonEventArgs e)
        {
            EnviarClienteSeleccionado();
        }

        /// <summary>
        /// Filtra los empleados tras introducir texto en el campo tbTextoFiltrado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbTextoFiltrado_KeyUp(object sender, KeyEventArgs e)
        {
            textoFiltrado = tbTextoFiltrado.Text.Trim().ToLower();
            MiVista.Filter += FiltrarPorNombre;
        }

        /// <summary>
        /// Filtra los clientes cuyo nombre contengan el texto introducido por el usuario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FiltrarPorNombre(object sender, FilterEventArgs e)
        {
            Cliente clienteFiltrado = (Cliente)e.Item;
            if (clienteFiltrado != null)
            {
                string nombre = clienteFiltrado.Nombre == null ? "" : clienteFiltrado.Nombre;
                if (clienteFiltrado.Nombre != null && clienteFiltrado.Nombre.ToLower().Contains(textoFiltrado!))
                {
                    e.Accepted = true;
                }
                else
                {
                    e.Accepted = false;
                }
            }
        }

        /// <summary>
        /// Envía el cliente seleccionado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSeleccionar_Click(object sender, RoutedEventArgs e)
        {
            EnviarClienteSeleccionado();
        }

        /// <summary>
        /// cierra el formulario con el cliente seleccionado
        /// </summary>
        private void EnviarClienteSeleccionado()
        {
            ClienteSeleccionado = (Cliente)lvClientes.SelectedItem;
            DialogResult = true;
            this.Close();
        }
    }
}
