﻿using Modelos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentacionWPF.Dialogos
{
    /// <summary>
    /// Lógica de interacción para SolicitudNuevoPassword.xaml
    /// </summary>
    public partial class SolicitudNuevoPassword : Window
    {
        private bool passwordOk;
        private string password;
        private Empleado empleado1;
        private Empleado empleado2;

        /// <summary>
        /// Constructor sin parámetros
        /// </summary>
        public SolicitudNuevoPassword()
        {
            InitializeComponent();
            passwordOk = false;
            empleado1 = new Empleado();
            empleado2 = new Empleado();
            tbPassword.DataContext = empleado1;
            tbPasswordConfirmacion.DataContext = empleado2;
        }

        /// <summary>
        /// Evento al pulsar el botón aceptar para comprobar que las contraseñas coinciden 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDialogOk_Click(object sender, RoutedEventArgs e)
        {
            if (!Validation.GetHasError(tbPassword) &&
                !Validation.GetHasError(tbPasswordConfirmacion))
            {
                if (tbPassword.Text != tbPasswordConfirmacion.Text)
                {
                    MensajeConfirmacion dialogoMensaje = new MensajeConfirmacion("Las contraseñas no coinciden");
                    dialogoMensaje.ShowDialog();
                }
                else
                {
                    password = tbPassword.Text;
                    if (Utils.ValidarPassword(password))
                    {
                        passwordOk = true;
                        MensajeConfirmacion mensajeConfirmacion = new MensajeConfirmacion("Contraseña cambiada correctamente!");
                        mensajeConfirmacion.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        MensajeConfirmacion mensajeConfirmacion = new MensajeConfirmacion("La contraseña no cumple los requisitos de seguridad: " +
                            "Debe tener entre 8 y 12 caracteres, al menos una mayúcula, una minúscula y un dígito");
                        mensajeConfirmacion.ShowDialog();
                    }                   
                }
            }
        }

        /// <summary>
        /// Devuelve el valor del booleano de control passwordOk
        /// </summary>
        /// <returns>true si la contraseña se ha cambiado correctamente</returns>
        public bool getPasswordOk()
        {
            return passwordOk;
        }

        /// <summary>
        /// Devuelve la contraseña actualizada
        /// </summary>
        /// <returns>contraseña</returns>
        public string getPassword()
        {
            return password;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            VaciarCampos();
        }

        /// <summary>
        /// Vacía el contenido de los campos
        /// </summary>
        private void VaciarCampos()
        {
            empleado1.Password = "";
            empleado2.Password = "";
        }
    }
}
