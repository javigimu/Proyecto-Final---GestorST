﻿using Modelos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentacionWPF.Dialogos
{
    /// <summary>
    /// Lógica de interacción para BuscarTecnico.xaml
    /// </summary>
    public partial class BuscarTecnico : Window
    {
        public Tecnico? TecnicoSeleccionado { get; set; }
        private ObservableCollection<Tecnico>? listaObservableTecnicos;
        private CollectionViewSource MiVista;
        private string? textoFiltrado;

        /// <summary>
        /// Constructor principal
        /// </summary>
        public BuscarTecnico()
        {
            InitializeComponent();
            TecnicoSeleccionado = new Tecnico();
            MiVista = (CollectionViewSource)FindResource("listaTecnicos");
            MostrarTecnicos();
        }

        /// <summary>
        /// Al cargar la página se establece la vista
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            MiVista.Source = listaObservableTecnicos;
        }

        /// <summary>
        /// Muestra un listado de todos los técnicos
        /// </summary>
        private void MostrarTecnicos()
        {
            ICollection<Tecnico>? tecnicos = Gestion.ListarTecnicos();            

            if (tecnicos != null)
            {
                tecnicos = tecnicos.OrderBy(t => t.Nombre).ThenBy(t => t.Apellidos).ToList();

                foreach (Tecnico t in tecnicos)
                {
                    t.Nombre = t.Nombre.Trim();
                    t.Apellidos = t.Apellidos.Trim();
                    t.Provincia = t.Provincia != null? t.Provincia.Trim() : null;
                }

                listaObservableTecnicos = new ObservableCollection<Tecnico>(tecnicos);
            }
            else
                listaObservableTecnicos = new ObservableCollection<Tecnico>();
            textoFiltrado = "";
        }


        /// <summary>
        /// Controla el doble click del ratón sobre un item del listview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void manejarDoubleClick(object sender, MouseButtonEventArgs e)
        {
            EnviarTecnicoSeleccionado();
        }

        /// <summary>
        /// Filtra los técnicos tras introducir texto en el campo tbTextoFiltrado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbTextoFiltrado_KeyUp(object sender, KeyEventArgs e)
        {
            textoFiltrado = tbTextoFiltrado.Text.Trim().ToLower();
            MiVista.Filter += Filtrar;
        }

        /// <summary>
        /// Filtra los técnicos cuyo nombre, apellidos o provincia contengan el texto introducido por el usuario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Filtrar(object sender, FilterEventArgs e)
        {
            Tecnico tecnicoFiltrado = (Tecnico)e.Item;
            if (tecnicoFiltrado != null)
            {
                string nombre = tecnicoFiltrado.Nombre == null ? "" : tecnicoFiltrado.Nombre.Trim().ToLower();
                string apellidos = tecnicoFiltrado.Apellidos == null ? "" : tecnicoFiltrado.Apellidos.Trim().ToLower();
                string provincia = tecnicoFiltrado.Provincia == null ? "" : tecnicoFiltrado.Provincia.Trim().ToLower();
                if (nombre != null && nombre.Contains(textoFiltrado!.ToLower()) ||
                    apellidos != null && apellidos.Contains(textoFiltrado!.ToLower()) ||
                    provincia != null && provincia.Contains(textoFiltrado!.ToLower()))
                {
                    e.Accepted = true;
                }
                else
                {
                    e.Accepted = false;
                }
            }
        }

        /// <summary>
        /// Envía el técnico seleccionado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSeleccionar_Click(object sender, RoutedEventArgs e)
        {
            EnviarTecnicoSeleccionado();
        }

        /// <summary>
        /// cierra el formulario con el técnico seleccionado
        /// </summary>
        private void EnviarTecnicoSeleccionado()
        {
            TecnicoSeleccionado = (Tecnico)dgTecnicos.SelectedItem;
            DialogResult = true;
            this.Close();
        }

        /// <summary>
        /// Selecciona y envía el técnico
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgTecnicos_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            EnviarTecnicoSeleccionado();
        }

    }
}
