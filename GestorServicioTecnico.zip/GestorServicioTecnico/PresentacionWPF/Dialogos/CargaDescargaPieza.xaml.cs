﻿using Modelos;
using Negocio;
using PresentacionWPF.UserControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentacionWPF.Dialogos
{
    /// <summary>
    /// Lógica de interacción para CargaDescargaPieza.xaml
    /// </summary>
    public partial class CargaDescargaPieza : Window
    {
        Pieza? pieza;
        Tecnico? tecnico;
        InventarioTecnico? inventarioTecnico;
        string? operacion;
        int cantidadInvetariada;

        public CargaDescargaPieza()
        {
            InitializeComponent();
            cantidadInvetariada = 0;
        }

        /// <summary>
        /// Constructor que recibe la pieza, el técnico y la operación 
        /// </summary>
        /// <param name="pieza">pieza</param>
        /// <param name="tecnico">técnico</param>
        /// <param name="operacion">operación {carga, descarga}</param>
        public CargaDescargaPieza(Pieza pieza, Tecnico tecnico, string operacion) : this()
        {
            this.pieza = pieza;
            this.tecnico = tecnico;
            this.operacion = operacion;
            inventarioTecnico = Gestion.ListarInventarioTecnicoCompleto(pieza.Id, tecnico.Id);
        }

        /// <summary>
        /// Al cargar, completa los datos con el inventario del técnico para la pieza seleccionada.
        /// Pone la cantidad a 1 si todavía no existe el inventario de esa pieza para el técnico
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            MostrarTitulo();
            if (inventarioTecnico == null)
            {
                lbCantidadInventariada.Content = 0;
                if (pieza != null && tecnico != null)
                    inventarioTecnico = new InventarioTecnico(pieza.Id, tecnico.Id, 1);
                else
                    inventarioTecnico = new InventarioTecnico();
            }
            else
            {
                lbCantidadInventariada.Content = inventarioTecnico.Cantidad;
                cantidadInvetariada = inventarioTecnico.Cantidad;
            }

            inventarioTecnico.Cantidad = 1;
            stackPanelInfoPieza.DataContext = pieza;
            stackPanelCantidad.DataContext = inventarioTecnico;
        }

        /// <summary>
        /// Muestra el título adecuado según la operación a realizar con la pieza
        /// Cargar o descargar
        /// También muestra correctamente el stock del inventario general para la carga
        /// y la cantidad previamente cargada por el técnico en las descargas
        /// </summary>
        private void MostrarTitulo()
        {
            if (operacion == Inventario.OPERACION_DESCARGAR)
            {
                tbTituloOperacion.Text = "DESCARGAR PIEZA";
                stackStockActual.Visibility = Visibility.Collapsed;
            }                
            else
            {
                tbTituloOperacion.Text = "CARGAR PIEZA";
            }
                
        }

        /// <summary>
        /// Sólo permite introducir números en un textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        /// <summary>
        /// Realiza la operación y cierra la ventana retornando DialogResult a true
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAceptar_Click(object sender, RoutedEventArgs e)
        {
            if (operacion == Inventario.OPERACION_CARGAR)
                CargarPieza();
            else if (operacion == Inventario.OPERACION_DESCARGAR)
                DescargarPieza();            
        }

        /// <summary>
        /// Descargar pieza del inventario del técnico
        /// </summary>
        private void DescargarPieza()
        {
            MensajeConfirmacion mensaje;
            int cantidadSeleccionada = tbCantidad.Text.Trim().Length > 0 ? Convert.ToInt32(tbCantidad.Text.Trim()) : -1;
            if (cantidadSeleccionada > cantidadInvetariada)
                cantidadSeleccionada = cantidadInvetariada;
            
            if (cantidadSeleccionada <= 0)
            {
                mensaje = new MensajeConfirmacion("Debes introducir la cantidad que deseas descargar");
                mensaje.ShowDialog();
            }
            else
            {
                if (pieza != null && inventarioTecnico != null)
                {
                    pieza.Stock += cantidadSeleccionada;
                    Gestion.ActualizarPieza(pieza);
                    inventarioTecnico.Cantidad = cantidadInvetariada - cantidadSeleccionada;
                    Gestion.ActualizarInventarioTecnico(inventarioTecnico);

                    mensaje = new MensajeConfirmacion("Descarga realizada correctamente!");
                    mensaje.ShowDialog();

                    this.DialogResult = true;
                }
            }
        }

        /// <summary>
        /// Carga la pieza en el inventario del técnico
        /// </summary>
        private void CargarPieza()
        {
            MensajeConfirmacion mensaje;
            int cantidadSeleccionada = tbCantidad.Text.Trim().Length > 0 ? Convert.ToInt32(tbCantidad.Text.Trim()) : -1;
            if (cantidadSeleccionada > pieza!.Stock)
            {
                mensaje = new MensajeConfirmacion("La cantidad seleccionada no puede ser superior al stock: " + pieza!.Stock);
                mensaje.ShowDialog();
            }
            else if (inventarioTecnico != null)
            {
                if (cantidadSeleccionada > 0)
                {
                    // crear o actualizar el inventario
                    inventarioTecnico.Cantidad += cantidadInvetariada;
                    if (cantidadInvetariada <= 0)
                        Gestion.InsertarInventarioTecnico(inventarioTecnico);
                    else
                        Gestion.ActualizarInventarioTecnico(inventarioTecnico);

                    // actualizar el stock del inventario general
                    pieza.Stock -= cantidadSeleccionada;
                    Gestion.ActualizarPieza(pieza);

                    mensaje = new MensajeConfirmacion("Carga realizada correctamente!");
                    mensaje.ShowDialog();

                    this.DialogResult = true;
                }
                else if (cantidadSeleccionada <= 0)
                {
                    mensaje = new MensajeConfirmacion("Debes introducir la cantidad que deseas cargar");
                    mensaje.ShowDialog();
                }
            }
        }

        /// <summary>
        /// Cancela la operación y cierra la ventana retornando DialogResult a false
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}
