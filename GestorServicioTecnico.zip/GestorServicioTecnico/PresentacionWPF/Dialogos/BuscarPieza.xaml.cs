﻿using Modelos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentacionWPF.Dialogos
{
    /// <summary>
    /// Lógica de interacción para BuscarPieza.xaml
    /// </summary>
    public partial class BuscarPieza : Window
    {
        public Pieza? PiezaSeleccionada { get; set; }
        private ObservableCollection<Pieza>? listaObservablePiezas;
        private CollectionViewSource miVista;
        private string? textoFiltrado;
        private Tecnico? tecnico;

        public BuscarPieza()
        {
            InitializeComponent();
            PiezaSeleccionada = new Pieza();
            miVista = (CollectionViewSource)FindResource("listaPiezas");
            textoFiltrado = "";
        }

        /// <summary>
        /// Formulario para seleccionar una pieza del inventario del técnico que se pasa como parámetro
        /// </summary>
        /// <param name="tecnico"></param>
        public BuscarPieza(Tecnico tecnico) : this()
        {
            this.tecnico = tecnico;
        }

        /// <summary>
        /// Al cargar la página se muestran todas las piezas
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            miVista.Source = listaObservablePiezas;
            PiezaSeleccionada = (Pieza)dgPiezas.SelectedItem;
            MostrarInventario();
        }

        /// <summary>
        /// Muestra el inventario completo o el inventario específico de un técnico en caso de ser distinto de null
        /// </summary>
        private void MostrarInventario()
        {
            ICollection<Pieza>? piezas = null;

            if (tecnico == null)
                piezas = Gestion.ListarPiezas();
            else
            {
                IList<InventarioTecnico>? inventariosTecnico = Gestion.ListarInventarioTecnico(tecnico.Id);
                if (inventariosTecnico != null)
                {
                    stackCantidadDelTecnico.Visibility = Visibility.Visible;
                    piezas = Gestion.ListarPiezasDeInventario(inventariosTecnico);
                }
            }                

            if (piezas != null)
                listaObservablePiezas = new ObservableCollection<Pieza>(piezas);
            else
                listaObservablePiezas = new ObservableCollection<Pieza>();

            miVista.Source = listaObservablePiezas;
        }

        /// <summary>
        /// Reacciona cada vez que se introduce un carácter en el texbox de filtrado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbTextoFiltrado_KeyUp(object sender, KeyEventArgs e)
        {
            textoFiltrado = tbTextoFiltrado.Text.Trim().ToLower();
            miVista.Filter += FiltrarPorNombreDescripcion;
        }

        /// <summary>
        /// Filtra las piezas cuyo nombre o descripción contengan el texto introducido por el usuario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FiltrarPorNombreDescripcion(object sender, FilterEventArgs e)
        {
            Pieza piezaFiltrada = (Pieza)e.Item;
            if (piezaFiltrada != null)
            {
                string nombre = piezaFiltrada.Nombre == null ? "" : piezaFiltrada.Nombre;
                string descripcion = piezaFiltrada.Descripcion == null ? "" : piezaFiltrada.Descripcion;

                if (nombre.ToLower().Contains(textoFiltrado!.ToLower()) ||
                    descripcion.ToLower().Contains(textoFiltrado!.ToLower()))
                {
                    e.Accepted = true;
                }
                else
                {
                    e.Accepted = false;
                }
            }
        }

        /// <summary>
        /// Selecciona la pieza y cierra el formulario
        /// </summary>
        private void EnviarPiezaSeleccionada()
        {
            PiezaSeleccionada = (Pieza)dgPiezas.SelectedItem;
            this.DialogResult = true;
            Close();
        }

        /// <summary>
        /// Añade la pieza seleccionada al consumo de material a través del botón
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AnyadirNuevaPieza(object sender, RoutedEventArgs e)
        {
            EnviarPiezaSeleccionada();
        }

        /// <summary>
        /// Añade la pieza seleccionada al consumo de material a través del menú contextual
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemAnyadirPieza_Click(object sender, RoutedEventArgs e)
        {
            EnviarPiezaSeleccionada();
        }
       
        /// <summary>
        /// Añade la pieza seleccionada al consumo de material a través de doble click con el ratón
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgPiezas_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            EnviarPiezaSeleccionada();
        }

        /// <summary>
        /// Cierra el formulario
        /// </summary>
        private void CerrarFormulario()
        {
            this.DialogResult = false;
            Close();
        }
       
        private void MenuItemCancelar_Click(object sender, RoutedEventArgs e)
        {
            CerrarFormulario();
        }


        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            CerrarFormulario();
        }

        /// <summary>
        /// Sólo permite introducir números en un textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }
    }
}
