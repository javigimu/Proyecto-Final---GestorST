﻿using DatosEEF;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    /// <summary>
    /// <autor>Javier Giménez Muñoz</autor>
    /// </summary>
    public class Gestion : IDisposable
    {
        // Flag: Se ha llamado a Dispose?
        bool disposed;

        #region "constructores"
        public Gestion() { }
        #endregion

        #region "averias"
        /// <summary>
        /// Listado de averías
        /// </summary>
        /// <returns>listado de todas las averías de la base de datos</returns>
        public static IList<Averia> ListarAverias()
        {
            return AveriaADO.Listar();
        }

        /// <summary>
        /// Obtiene un listado de todas las averías con la información completa del técnico y la pieza
        /// </summary>
        /// <returns>listado de averías con la información completa del técnico y la pieza</returns>
        public static IList<Averia>? ListarAveriasCompleto()
        {
            IList<Averia>? averias = AveriaADO.Listar();
            IList<Averia> averiasCompleto = new List<Averia>();
            if (averias != null)
            {
                foreach (Averia averia in averias)
                {
                    Averia? averiaCompleta = ListarAveriaCompleta(averia.Id);
                    if (averiaCompleta != null)
                        averiasCompleto.Add(averiaCompleta);
                }
            }
            return averiasCompleto;
        }

        /// <summary>
        /// Obtiene una avería de la base de datos a partir de su Id
        /// </summary>
        /// <param name="id">id de la avería a obtener</param>
        /// <returns></returns>
        public static Averia? ListarAveria(int id)
        {
            return AveriaADO.Listar(id);
        }

        /// <summary>
        /// Obtiene una avería con toda la información sobre el técnico y la pieza
        /// </summary>
        /// <param name="id">id de la avería</param>
        /// <returns></returns>
        public static Averia? ListarAveriaCompleta(int id)
        {
            Averia? averia = AveriaADO.Listar(id);
            if (averia != null)
            {
                Tecnico? tecnico = TecnicoADO.Listar(averia.TecnicoId);
                if (tecnico != null)
                    averia.Tecnico = tecnico;

                Pieza? pieza = PiezaADO.Listar(averia.PiezaId);
                if (pieza != null)
                    averia.Pieza = pieza;
            }

            return averia;
        }

        /// <summary>
        /// Inserta una avería en la base de datos
        /// </summary>
        /// <param name="averia">avería a insertar</param>
        public static void InsertarAveria(Averia averia)
        {
            averia.Id = 0;
            AveriaADO.Insertar(averia);
        }

        /// <summary>
        /// Actualiza una avería en la base de datos
        /// </summary>
        /// <param name="averia">avería con los datos actualizados</param>
        public static void ActualizarAveria(Averia averia)
        {
            AveriaADO.Actualizar(averia);
        }

        /// <summary>
        /// Borra una avería de la base de datos
        /// </summary>
        /// <param name="averia">avería a borrar</param>
        public static void BorrarAveria(Averia averia)
        {
            AveriaADO.Borrar(averia);
        }
        #endregion

        #region "avisos"
        /// <summary>
        /// Listado de avisos en la base de datos
        /// </summary>
        /// <returns>lista con todos los avisos de la base de datos</returns>
        public static IList<Aviso> ListarAvisos()
        {
            return AvisoADO.Listar();
        }

        /// <summary>
        /// Obtiene un listado de todos los avisos con la información completa del técnico,
        /// el coordinador y los consumos de material
        /// </summary>
        /// <returns>listado de avisos con la información completa del técnico, 
        /// el coordinador y los consumos de material</returns>
        public static IList<Aviso>? ListarAvisosCompleto()
        {
            IList<Aviso>? avisos = AvisoADO.Listar();
            IList<Aviso> avisosCompleto = new List<Aviso>();
            if (avisos != null)
            {
                foreach (Aviso aviso in avisos)
                {
                    Aviso? avisoCompleto = ListarAvisoCompleto(aviso.Id);
                    if (avisoCompleto != null)
                        avisosCompleto.Add(avisoCompleto);
                }
            }
            return avisosCompleto;
        }

        /// <summary>
        /// Lista todos los avisos de un técnico
        /// </summary>
        /// <param name="tecnico"></param>
        /// <returns></returns>
        public static IList<Aviso>? ListarAvisosTecnicoCompleto(int tecnicoId)
        {
            IList<Aviso>? avisos = AvisoADO.ListarPorTecnico(tecnicoId);
            IList<Aviso> avisosCompleto = new List<Aviso>();
            if (avisos != null)
            {
                foreach (Aviso aviso in avisos)
                {
                    Aviso? avisoCompleto = ListarAvisoCompleto(aviso.Id);
                    if (avisoCompleto != null)
                        avisosCompleto.Add(avisoCompleto);
                }
            }
            return avisosCompleto;
        }

        /// <summary>
        /// Obtiene el aviso con el id pasado por parámetro
        /// </summary>
        /// <param name="id">id del aviso a obtener</param>
        /// <returns>el aviso asociado al id o null si no existe</returns>
        public static Aviso? ListarAviso(long id)
        {
            return AvisoADO.Listar(id);
        }

        /// <summary>
        /// Obtiene el aviso con id pasado por parámetro con información completa del técnico, 
        /// el coordinador, sus consumos de material, el cliente y el producto
        /// </summary>
        /// <param name="id">id del aviso a obtener</param>
        /// <returns>aviso con la información completa o null si no existe el aviso</returns>
        public static Aviso? ListarAvisoCompleto(long id)
        {
            Aviso? aviso = AvisoADO.Listar(id);
            if (aviso != null)
            {
                Coordinadore? coordinador = CoordinadoreADO.Listar(aviso.CoordinadorId);
                if (coordinador != null)
                    aviso.Coordinador = coordinador;

                if (aviso.TecnicoId != null)
                {
                    Tecnico? tecnico = TecnicoADO.Listar((int)aviso.TecnicoId);
                    if (tecnico != null)
                        aviso.Tecnico = tecnico;
                }

                IList<ConsumosMaterial>? consumosMaterial = ConsumosMaterialADO.ListarPorAviso(id);
                if (consumosMaterial != null)
                    aviso.ConsumosMaterials = consumosMaterial;

                Cliente? cliente = ClienteADO.Listar(aviso.ClienteId);
                if (cliente != null)
                {
                    aviso.Cliente = cliente;
                }

                Producto? producto = ProductoADO.Listar(aviso.NumeroSerieProducto);
                if (producto != null)
                {
                    aviso.NumeroSerieProductoNavigation = producto;
                }
            }
            return aviso;
        }

        /// <summary>
        /// Inserta un aviso en la base de datos
        /// </summary>
        /// <param name="aviso">aviso a insertar</param>
        public static void InsertarAviso(Aviso aviso)
        {
            aviso.Id = 0;
            AvisoADO.Insertar(aviso);
        }

        /// <summary>
        /// Actualiza un aviso de la base de datos
        /// </summary>
        /// <param name="aviso">aviso a actualizar</param>
        public static void ActualizarAviso(Aviso aviso)
        {
            AvisoADO.Actualizar(aviso);
        }

        /// <summary>
        /// Borra un aviso de la base de datos
        /// </summary>
        /// <param name="aviso">aviso a borrar</param>
        public static void BorrarAviso(Aviso aviso)
        {
            AvisoADO.Borrar(aviso);
        }
        #endregion

        #region "consumos de material"

        /// <summary>
        /// Lista todos los consumos de material de la base de datos
        /// </summary>
        /// <returns>lista de consumos de material</returns>
        public static IList<ConsumosMaterial>? ListarConsumosMaterial()
        {
            return ConsumosMaterialADO.Listar();
        }

        /// <summary>
        /// Obtiene un consumo de material a partir de su clave primaria
        /// </summary>
        /// <param name="tecnicoId">id del técnico</param>
        /// <param name="piezaId">id de la pieza</param>
        /// <param name="avisoId">id del aviso</param>
        /// <returns>consumo de material de una pieza en un aviso realizado por un técnico</returns>
        public static ConsumosMaterial? ListarConsumoMaterial(int tecnicoId, long piezaId, long avisoId)
        {
            return ConsumosMaterialADO.Listar(tecnicoId, piezaId, avisoId);
        }

        /// <summary>
        /// Obtiene un consumo de material con la información completa del técnico, la pieza y el aviso
        /// </summary>
        /// <param name="tecnicoId">id del técnico</param>
        /// <param name="piezaId">id de la pieza</param>
        /// <param name="avisoId">id del aviso</param>
        /// <returns></returns>
        public static ConsumosMaterial? ListarConsumoMaterialCompleto(int tecnicoId, long piezaId, long avisoId)
        {
            ConsumosMaterial? consumoMaterial = ConsumosMaterialADO.Listar(tecnicoId, piezaId, avisoId);
            if (consumoMaterial != null)
            {
                Tecnico? tecnico = TecnicoADO.Listar(tecnicoId);
                if (tecnico != null)
                    consumoMaterial.Tecnico = tecnico;

                Pieza? pieza = PiezaADO.Listar(piezaId);
                if (pieza != null)
                    consumoMaterial.Pieza = pieza;

                Aviso? aviso = AvisoADO.Listar(avisoId);
                if (aviso != null)
                    consumoMaterial.Aviso = aviso;
            }
            return consumoMaterial;
        }

        /// <summary>
        /// Obtiene la información completa de un consumo de material,
        /// a partir de la información básica de un consumo de material
        /// </summary>
        /// <param name="cm"></param>
        /// <returns></returns>
        public static ConsumosMaterial? ListarConsumoMaterialCompleto(ConsumosMaterial cm)
        {
            return ListarConsumoMaterialCompleto(cm.TecnicoId, cm.PiezaId, cm.AvisoId);
        }

        /// <summary>
        /// Obtiene la información completa de los consumos de material de una lista
        /// </summary>
        /// <param name="consumosMaterial">lista de consumos de material</param>
        /// <returns>lista de consumos de material con la información completa de los técnicos, 
        /// las piezas y lo avisos</returns>
        public static IList<ConsumosMaterial>? ListarConsumosMaterialCompleto(IList<ConsumosMaterial> consumosMaterial)
        {
            IList<ConsumosMaterial>? consumosMaterialCompleto = new List<ConsumosMaterial>();
            if (consumosMaterial != null)
            {
                foreach (ConsumosMaterial cm in consumosMaterial)
                {
                    ConsumosMaterial? cmCompleto = ListarConsumoMaterialCompleto(cm);
                    if (cmCompleto != null)
                        consumosMaterialCompleto.Add(cmCompleto);
                }
            }
            return consumosMaterialCompleto;
        }

        /// <summary>
        /// Obtiene el listado de consumos de material de un técnico
        /// </summary>
        /// <param name="tecnicoId">id del técnico</param>
        /// <returns>lista de consumos de material de un técnico</returns>
        public static IList<ConsumosMaterial>? ListarConsumosMaterialPorTecnico(int tecnicoId)
        {
            return ConsumosMaterialADO.ListarPorTecnico(tecnicoId);
        }

        /// <summary>
        /// Obtiene el listado de consumos de material por técnico,
        /// con la información completa del técnico, las piezas y los avisos
        /// </summary>
        /// <param name="tecnicoId">id del técnico</param>
        /// <returns>listado de consumos de material con la información completa 
        /// del técnico, las piezas y los avisos</returns>
        public static IList<ConsumosMaterial>? ListarConsumosMaterialPorTecnicoCompleto(int tecnicoId)
        {
            IList<ConsumosMaterial>? consumosMaterial = ListarConsumosMaterialPorTecnico(tecnicoId);
            IList<ConsumosMaterial>? consumosMaterialCompleto = new List<ConsumosMaterial>();
            if (consumosMaterial != null)
                consumosMaterialCompleto = ListarConsumosMaterialCompleto(consumosMaterial);
            return consumosMaterialCompleto;
        }

        /// <summary>
        /// Obtiene el listado de consumos de material que ha tenido una pieza
        /// </summary>
        /// <param name="tecnicoId">id de la pieza</param>
        /// <returns>lista de consumos de material de una pieza</returns>
        public static IList<ConsumosMaterial>? ListarConsumosMaterialPorPieza(long piezaId)
        {
            return ConsumosMaterialADO.ListarPorPieza(piezaId);
        }

        /// <summary>
        /// Obtiene el listado de consumos de material por pieza,
        /// con la información completa la pieza, de los técnicos y los avisos
        /// </summary>
        /// <param name="piezaId">id de la pieza</param>
        /// <returns>listado de consumos de material con la información completa 
        /// de la pieza, los técnicos y los avisos</returns>
        public static IList<ConsumosMaterial>? ListarConsumosMaterialPorPiezaCompleto(long piezaId)
        {
            IList<ConsumosMaterial>? consumosMaterial = ListarConsumosMaterialPorPieza(piezaId);
            IList<ConsumosMaterial>? consumosMaterialCompleto = new List<ConsumosMaterial>();
            if (consumosMaterial != null)
                consumosMaterialCompleto = ListarConsumosMaterialCompleto(consumosMaterial);
            return consumosMaterialCompleto;
        }

        /// <summary>
        /// Obtiene el listado de consumos de material de un aviso
        /// </summary>
        /// <param name="avisoId">id del aviso</param>
        /// <returns>lista de consumos de material de una aviso</returns>
        public static IList<ConsumosMaterial>? ListarConsumosMaterialPorAviso(long avisoId)
        {
            return ConsumosMaterialADO.ListarPorAviso(avisoId);
        }

        /// <summary>
        /// Obtiene el listado de consumos de material por aviso,
        /// con la información completa de los técnicos, las piezas y el aviso
        /// </summary>
        /// <param name="avisoId">id del aviso</param>
        /// <returns>listado de consumos de material con la información completa 
        /// del aviso, los técnicos y las piezas</returns>
        public static IList<ConsumosMaterial>? ListarConsumosMaterialPorAvisoCompleto(long avisoId)
        {
            IList<ConsumosMaterial>? consumosMaterial = ListarConsumosMaterialPorAviso(avisoId);
            IList<ConsumosMaterial>? consumosMaterialCompleto = new List<ConsumosMaterial>();
            if (consumosMaterial != null)
                consumosMaterialCompleto = ListarConsumosMaterialCompleto(consumosMaterial);
            return consumosMaterialCompleto;
        }

        /// <summary>
        /// Obtiene la cantidad total de una pieza consumida por un técnico a partir de una lista de consumos de material
        /// </summary>
        /// <param name="piezaId">id de la pieza</param>
        /// <param name="tecnicoId">id del técnico</param>
        /// <param name="consumosMaterial">lista de consumos de material</param>
        /// <returns></returns>
        public static int CalcularCantidadTotalConsumida(long piezaId, int tecnicoId, ICollection<ConsumosMaterial> consumosMaterial)
        {
            int cantidadTotal = 0;
            foreach (ConsumosMaterial cm in consumosMaterial)
            {
                if (cm.PiezaId == piezaId && cm.TecnicoId == tecnicoId)
                    cantidadTotal += cm.Cantidad;
            }
            return cantidadTotal;
        }

        /// <summary>
        /// Inserta un consumo de material en la base de datos
        /// </summary>
        /// <param name="consumoMaterial">consumo de material a insertar</param>
        public static void InsertarConsumoMaterial(ConsumosMaterial consumoMaterial)
        {
            ConsumosMaterialADO.Insertar(consumoMaterial);
        }

        /// <summary>
        /// Inserta todos los consumos de material de una lista
        /// </summary>
        /// <param name="consumosMaterial">lista de consumos de material</param>
        public static void InsertarListaConsumosMaterial(IList<ConsumosMaterial> consumosMaterial)
        {
            foreach (ConsumosMaterial cm in consumosMaterial)
                ConsumosMaterialADO.Insertar(cm);
        }

        /// <summary>
        /// Actualiza un consumo de material en la base de datos
        /// </summary>
        /// <param name="consumoMaterial">consumo de material a actualizar</param>
        public static void ActualizarConsumoMaterial(ConsumosMaterial consumoMaterial)
        {
            ConsumosMaterialADO.Actualizar(consumoMaterial);
        }

        /// <summary>
        /// Actualiza todos los consumos de material de una lista
        /// </summary>
        /// <param name="consumosMaterial">lista de consumos de material</param>
        public static void ActualizarListaConsumosMaterial(IList<ConsumosMaterial> consumosMaterial)
        {
            foreach (ConsumosMaterial cm in consumosMaterial)
                ConsumosMaterialADO.Actualizar(cm);
        }

        /// <summary>
        /// Borra un consumo de material de la base de datos
        /// </summary>
        /// <param name="consumoMaterial">consumo de material a borrar</param>
        public static void BorrarConsumoMaterial(ConsumosMaterial consumoMaterial)
        {
            ConsumosMaterialADO.Borrar(consumoMaterial);
        }

        /// <summary>
        /// Borra todos los consumos de material de una lista
        /// </summary>
        /// <param name="consumosMaterial">lista de consumos de material</param>
        public void BorrarListaConsumosMaterial(IList<ConsumosMaterial> consumosMaterial)
        {
            foreach (ConsumosMaterial cm in consumosMaterial)
                ConsumosMaterialADO.Borrar(cm);
        }
        #endregion

        #region "coordinadores"
        /// <summary>
        /// Lista todos los coordinadores de la base de datos
        /// </summary>
        /// <returns>lista de coordinadores</returns>
        public static IList<Coordinadore>? ListarCoordinadores()
        {
            return CoordinadoreADO.Listar();
        }

        /// <summary>
        /// Obtiene un listado de todos los coordinadores con la información completa de sus avisos
        /// </summary>
        /// <returns>listado de coordinadores con la información completa de los avisos</returns>
        public static IList<Coordinadore>? ListarCoordinadoresCompleto()
        {
            IList<Coordinadore>? coordinadores = CoordinadoreADO.Listar();
            IList<Coordinadore> coordinadoresCompleto = new List<Coordinadore>();
            if (coordinadoresCompleto != null)
            {
                foreach (Coordinadore coordinador in coordinadores)
                {
                    Coordinadore? coordinadorCompleto = ListarCoordinadorCompleto(coordinador.Id);
                    if (coordinadorCompleto != null)
                        coordinadoresCompleto.Add(coordinadorCompleto);
                }
            }
            return coordinadoresCompleto;
        }

        /// <summary>
        /// Obtiene el coordinador de la base de datos con el id pasado por parámetro
        /// </summary>
        /// <param name="id">id del coordinador</param>
        /// <returns>coordinador asociado al id</returns>
        public static Coordinadore? ListarCoordinador(int id)
        {
            return CoordinadoreADO.Listar(id);
        }

        /// <summary>
        /// Obtiene un listado de los coordinadores con la información completa de sus avisos
        /// </summary>
        /// <param name="id">id del coordinador</param>
        /// <returns>coordinador con la información completa de los avisos</returns>
        public static Coordinadore? ListarCoordinadorCompleto(int id)
        {
            Coordinadore? coordinador = CoordinadoreADO.Listar(id);
            if (coordinador != null)
            {
                IList<Aviso>? avisos = AvisoADO.ListarPorCoordinador(id);
                if (avisos != null)
                    coordinador.Avisos = avisos;
            }
            return coordinador;
        }

        /// <summary>
        /// Inserta un coordinador en la base de datos
        /// </summary>
        /// <param name="coordinador">coordinador a insertar</param>
        public static void InsertarCoordinador(Coordinadore coordinador)
        {
            CoordinadoreADO.Insertar(coordinador);
        }

        /// <summary>
        /// Actualiza un coordinador de la base de datos
        /// </summary>
        /// <param name="coordinador">coordinador a actualizar</param>
        public static void ActualizarCoordinador(Coordinadore coordinador)
        {
            CoordinadoreADO.Actualizar(coordinador);
        }

        /// <summary>
        /// Borra un coordinador de la base de datos
        /// </summary>
        /// <param name="coordinador">coordinador a borrar</param>
        public static void BorrarCoordinador(Coordinadore coordinador)
        {
            CoordinadoreADO.Borrar(coordinador);
        }

        /// <summary>
        /// Comprueba si existe el id en la lista de coordinadores
        /// </summary>
        /// <param name="coordinadores">lista de coordinadores</param>
        /// <param name="id">id identificativo del coordinadore</param>
        /// <returns></returns>
        public static bool EmpleadoEsCoordinador(ICollection<Coordinadore> coordinadores, int id)
        {
            foreach (Coordinadore coordinador in coordinadores)
            {
                if (coordinador.Id == id)
                    return true;
            }
            return false;
        }
        #endregion

        #region "empleados"
        /// <summary>
        /// Lista todos los empleados de la base de datos
        /// </summary>
        /// <returns>lista de empleados</returns>
        public static IList<Empleado>? ListarEmpleados()
        {
            return EmpleadoADO.Listar();
        }

        /// <summary>
        /// Obtiene los empleados que están en activo
        /// </summary>
        /// <returns>lista de empleados en activo</returns>
        public static IList<Empleado>? ListarEmpleadosEnActivo()
        {
            return EmpleadoADO.ListarSinExtrabajadores();
        }

        /// <summary>
        /// Obtiene el empleado de la base de datos con el id pasado por parámetro
        /// </summary>
        /// <param name="id">id del empleado</param>
        /// <returns>empleado asociado al id</returns>
        public static Empleado? ListarEmpleado(int id)
        {
            return EmpleadoADO.Listar(id);
        }

        /// <summary>
        /// Inserta un empleado en la base de datos
        /// </summary>
        /// <param name="empleado">empleado a insertar</param>
        public static void InsertarEmpleado(Empleado empleado)
        {
            EmpleadoADO.Insertar(empleado);
        }

        /// <summary>
        /// Actualiza un empleado de la base de datos
        /// </summary>
        /// <param name="empleado">empleado a actualizar</param>
        public static void ActualizarEmpleado(Empleado empleado)
        {
            EmpleadoADO.Actualizar(empleado);
        }

        /// <summary>
        /// Borra un empleado de la base de datos
        /// </summary>
        /// <param name="empleado">empleado a borrar</param>
        public static void BorrarEmpleado(Empleado empleado)
        {
            EmpleadoADO.Borrar(empleado);
        }

        /// <summary>
        /// Da de baja un empleado, manteniéndolo en la base de datos
        /// </summary>
        /// <param name="empleado">empleado a dar de baja</param>
        public static void DarDeBajaEmpleado(Empleado empleado)
        {
            empleado.Extrabajador = true;
            ActualizarEmpleado(empleado);
        }

        /// <summary>
        /// Comprueba si el id que se pasa por parámetro existe en la lista de empleados
        /// </summary>
        /// <param name="empleados">lista de empleados</param>
        /// <param name="id">id del empleado a comprobar</param>
        /// <returns></returns>
        public static bool ComprobarEmpleadoExiste(ICollection<Empleado> empleados, int id)
        {
            foreach (Empleado empleado in empleados)
            {
                if (empleado.Id == id)
                    return true;
            }
            return false;
        }
        #endregion

        #region "logisticos"
        /// <summary>
        /// Lista todos los logisticos de la base de datos
        /// </summary>
        /// <returns>lista de logisticos</returns>
        public static IList<Logistico>? ListarLogisticos()
        {
            return LogisticoADO.Listar();
        }

        /// <summary>
        /// Obtiene el logístico de la base de datos con el id pasado por parámetro
        /// </summary>
        /// <param name="id">id del logístico</param>
        /// <returns>logístico asociado al id</returns>
        public static Logistico? ListarLogistico(int id)
        {
            return LogisticoADO.Listar(id);
        }

        /// <summary>
        /// Inserta un logístico en la base de datos
        /// </summary>
        /// <param name="logistico">logístico a insertar</param>
        public static void InsertarLogistico(Logistico logistico)
        {
            LogisticoADO.Insertar(logistico);
        }

        /// <summary>
        /// Actualiza un logístico de la base de datos
        /// </summary>
        /// <param name="logistico">logístico a actualizar</param>
        public static void ActualizarLogistico(Logistico logistico)
        {
            LogisticoADO.Actualizar(logistico);
        }

        /// <summary>
        /// Borra un logístico de la base de datos
        /// </summary>
        /// <param name="logistico">logístico a borrar</param>
        public static void BorrarLogistico(Logistico logistico)
        {
            LogisticoADO.Borrar(logistico);
        }

        /// <summary>
        /// Comprueba si existe el id en la lista de logísticos
        /// </summary>
        /// <param name="logisticos">lista de logísticos</param>
        /// <param name="id">id identificativo del logístico</param>
        /// <returns></returns>
        public static bool EmpleadoEsLogistico(ICollection<Logistico> logisticos, int id)
        {
            foreach(Logistico logistico in logisticos)
            {
                if (logistico.Id == id)
                    return true;
            }
            return false;
        }
        #endregion

        #region "técnicos"
        /// <summary>
        /// Lista todos los técnicos de la base de datos
        /// </summary>
        /// <returns>lista de técnicos</returns>
        public static IList<Tecnico>? ListarTecnicos()
        {
            return TecnicoADO.Listar();
        }        

        /// <summary>
        /// Obtiene un listado de todos los técnicos con la información completa de sus avisos,
        /// averías, consumos de material y reparaciones
        /// </summary>
        /// <returns>listado de técnicos con la información completa de los avisos,
        /// averías, consumos de material, inventario y reparaciones</returns>
        public static IList<Tecnico>? ListarTecnicosCompleto()
        {
            IList<Tecnico>? tecnicos = TecnicoADO.Listar();
            IList<Tecnico> tecnicosCompleto = new List<Tecnico>();
            if (tecnicos != null)
            {
                foreach (Tecnico tecnico in tecnicos)
                {
                    Tecnico? tecnicoCompleto = ListarTecnicoCompleto(tecnico.Id);
                    if (tecnicoCompleto != null)
                        tecnicosCompleto.Add(tecnicoCompleto);                    
                }
            }
            return tecnicosCompleto;
        }

        /// <summary>
        /// Obtiene el técnico de la base de datos con el id pasado por parámetro
        /// </summary>
        /// <param name="id">id del técnico</param>
        /// <returns>técnico asociado al id</returns>
        public static Tecnico? ListarTecnico(int id)
        {
            return TecnicoADO.Listar(id);
        }

        /// <summary>
        /// Obtiene un listado de los técnicos con la información completa de sus avisos,
        /// averías, consumos de material y reparaciones
        /// </summary>
        /// <param name="id">id del técnico</param>
        /// <returns>técnico con la información completa de los avisos, averías,
        /// consumos de material, inventario y reparaciones</returns>
        public static Tecnico? ListarTecnicoCompleto(int id)
        {
            Tecnico? tecnico = TecnicoADO.Listar(id);
            if (tecnico != null)
            {
                IList<Aviso>? avisos = AvisoADO.ListarPorTecnico(tecnico.Id);
                if (avisos != null)
                    tecnico.Avisos = avisos;
                IList<Averia>? averias = AveriaADO.ListarPorTecnico(tecnico.Id);
                if (averias != null)
                    tecnico.Averia = averias;
                IList<ConsumosMaterial>? consumosMaterial = ConsumosMaterialADO.ListarPorTecnico(tecnico.Id);
                if (consumosMaterial != null)
                    tecnico.ConsumosMaterials = consumosMaterial;
                IList<Reparacione>? reparaciones = ReparacioneADO.ListarPorTecnico(tecnico.Id);
                if (reparaciones != null)
                    tecnico.Reparaciones = reparaciones;
                IList<InventarioTecnico>? inventario = InventarioTecnicoADO.ListarPorTecnico(tecnico.Id);
                if (inventario != null)
                    tecnico.InventarioTecnicos = inventario;

            }
            return tecnico;
        }

        /// <summary>
        /// Inserta un técnico en la base de datos
        /// </summary>
        /// <param name="tecnico">técnico a insertar</param>
        public static void InsertarTecnico(Tecnico tecnico)
        {
            TecnicoADO.Insertar(tecnico);
        }

        /// <summary>
        /// Actualiza un técnico de la base de datos
        /// </summary>
        /// <param name="tecnico">técnico a actualizar</param>
        public static void ActualizarTecnico(Tecnico tecnico)
        {
            TecnicoADO.Actualizar(tecnico);
        }

        /// <summary>
        /// Borra un técnico de la base de datos
        /// </summary>
        /// <param name="tecnico">técnico a borrar</param>
        public static void BorrarTecnico(Tecnico tecnico)
        {
            TecnicoADO.Borrar(tecnico);
        }

        /// <summary>
        /// Comprueba si existe el id en la lista de técnicos
        /// </summary>
        /// <param name="tecnicos">lista de técnicos</param>
        /// <param name="id">id identificativo del técnico</param>
        /// <returns></returns>
        public static bool EmpleadoEsTecnico(ICollection<Tecnico> tecnicos, int id)
        {
            foreach (Tecnico tecnico in tecnicos)
            {
                if (tecnico.Id == id)
                    return true;
            }
            return false;
        }
        #endregion

        #region "piezas"
        /// <summary>
        /// Lista todas las piezas de la base de datos
        /// </summary>
        /// <returns>lista de piezas</returns>
        public static IList<Pieza>? ListarPiezas()
        {
            return PiezaADO.Listar();
        }

        /// <summary>
        /// Obtiene un listado de todas las piezas con la información completa de sus 
        /// averías, consumos de material y reparaciones
        /// </summary>
        /// <returns>listado de piezas con la información completa de las averías, 
        /// consumos de material y reparaciones</returns>
        public static IList<Pieza>? ListarPiezasCompleto()
        {
            IList<Pieza>? piezas = PiezaADO.Listar();
            IList<Pieza> piezasCompleta = new List<Pieza>();
            if (piezas != null)
            {
                foreach (Pieza pieza in piezas)
                {
                    Pieza? piezaCompleta = ListarPiezaCompleta(pieza.Id);
                    if (piezaCompleta != null)
                        piezasCompleta.Add(piezaCompleta);
                }
            }
            return piezasCompleta;
        }

        /// <summary>
        /// Obtiene la pieza de la base de datos con el id pasado por parámetro
        /// </summary>
        /// <param name="id">id de la pieza</param>
        /// <returns>pieza asociada al id</returns>
        public static Pieza? ListarPieza(long id)
        {
            return PiezaADO.Listar(id);
        }

        /// <summary>
        /// Obtiene un listado de las piezas con la información completa de sus averías,
        /// consumos de material y reparaciones
        /// </summary>
        /// <param name="id">id de la pieza</param>
        /// <returns>pieza con la información completa de las averías,
        /// consumos de material, inventario y reparaciones</returns>
        public static Pieza? ListarPiezaCompleta(long id)
        {
            Pieza? pieza = PiezaADO.Listar(id);
            if (pieza != null)
            {
                IList<Averia>? averias = AveriaADO.ListarPorPieza(pieza.Id);
                if (averias != null)
                    pieza.Averia = averias;
                IList<ConsumosMaterial>? consumosMaterial = ConsumosMaterialADO.ListarPorPieza(pieza.Id);
                if (consumosMaterial != null)
                    pieza.ConsumosMaterials = consumosMaterial;
                IList<Reparacione>? reparaciones = ReparacioneADO.ListarPorPieza(pieza.Id);
                if (reparaciones != null)
                    pieza.Reparaciones = reparaciones;
                IList<InventarioTecnico>? inventario = InventarioTecnicoADO.ListarPorPieza(pieza.Id);
                if (inventario != null)
                    pieza.InventarioTecnicos = inventario;
            }
            return pieza;
        }

        /// <summary>
        /// Inserta una pieza en la base de datos
        /// </summary>
        /// <param name="pieza">pieza a insertar</param>
        public static void InsertarPieza(Pieza pieza)
        {
            PiezaADO.Insertar(pieza);
        }

        /// <summary>
        /// Actualiza una pieza de la base de datos
        /// </summary>
        /// <param name="pieza">pieza a actualizar</param>
        public static void ActualizarPieza(Pieza pieza)
        {
            PiezaADO.Actualizar(pieza);
        }

        /// <summary>
        /// Borra una pieza de la base de datos
        /// </summary>
        /// <param name="pieza">pieza a borrar</param>
        public static void BorrarPieza(Pieza pieza)
        {
            PiezaADO.Borrar(pieza);
        }
        #endregion

        #region "reparaciones"
        /// <summary>
        /// Lista todas las reparaciones de la base de datos
        /// </summary>
        /// <returns>lista de reparaciones</returns>
        public static IList<Reparacione>? ListarReparaciones()
        {
            return ReparacioneADO.Listar();
        }

        /// <summary>
        /// Obtiene un listado de todas las reparaciones con la información completa del técnico y la pieza
        /// </summary>
        /// <returns>listado de reparaciones con la información completa del técnico y la pieza</returns>
        public static IList<Reparacione>? ListarReparacionesCompleto()
        {
            IList<Reparacione>? reparaciones = ReparacioneADO.Listar();
            IList<Reparacione> reparacionesCompleta = new List<Reparacione>();
            if (reparaciones != null)
            {
                foreach (Reparacione reparacion in reparaciones)
                {
                    Reparacione? reparacionCompleta = ListarReparacionCompleta(reparacion.Id);
                    if (reparacionCompleta != null)
                        reparacionesCompleta.Add(reparacionCompleta);
                }
            }
            return reparacionesCompleta;
        }

        /// <summary>
        /// Obtiene la reparación de la base de datos con el id pasado por parámetro
        /// </summary>
        /// <param name="id">id de la reparaciones</param>
        /// <returns>reparaciones asociada al id</returns>
        public static Reparacione? ListarReparacion(int id)
        {
            return ReparacioneADO.Listar(id);
        }

        /// <summary>
        /// Obtiene una reparacióin con toda la información sobre el técnico y la pieza
        /// </summary>
        /// <param name="id">id de la reparación</param>
        /// <returns></returns>
        public static Reparacione? ListarReparacionCompleta(int id)
        {
            Reparacione? reparacion = ReparacioneADO.Listar(id);
            if (reparacion != null)
            {
                Tecnico? tecnico = TecnicoADO.Listar(reparacion.TecnicoId);
                if (tecnico != null)
                    reparacion.Tecnico = tecnico;

                Pieza? pieza = PiezaADO.Listar(reparacion.PiezaId);
                if (pieza != null)
                    reparacion.Pieza = pieza;
            }

            return reparacion;
        }

        /// <summary>
        /// Inserta una reparación en la base de datos
        /// </summary>
        /// <param name="reparacion">reparación a insertar</param>
        public static void InsertarReparacion(Reparacione reparacion)
        {
            ReparacioneADO.Insertar(reparacion);
        }

        /// <summary>
        /// Actualiza una reparación de la base de datos
        /// </summary>
        /// <param name="reparacion">reparación a actualizar</param>
        public static void ActualizarReparacion(Reparacione reparacion)
        {
            ReparacioneADO.Actualizar(reparacion);
        }

        /// <summary>
        /// Borra una reparación de la base de datos
        /// </summary>
        /// <param name="reparacion">reparación a borrar</param>
        public static void BorrarReparacion(Reparacione reparacion)
        {
            ReparacioneADO.Borrar(reparacion);
        }
        #endregion

        #region "inventarios"
        /// <summary>
        /// Lista todos los inventarios de la base de datos
        /// </summary>
        /// <returns>lista de técnicos</returns>
        public static IList<InventarioTecnico> ListarInventarioTecnicos()
        {
            return InventarioTecnicoADO.Listar();
        }

        /// <summary>
        /// Lista todos los inventarios de un técnico
        /// </summary>
        /// <param name="tecnicoId">id del técnico</param>
        /// <returns></returns>
        public static IList<InventarioTecnico>? ListarInventarioTecnico(int tecnicoId)
        {
            return InventarioTecnicoADO.ListarPorTecnico(tecnicoId);
        }

        /// <summary>
        /// Devuelve el listado de piezas que hay en una lista de inventarios
        /// </summary>
        /// <param name="inventarios"></param>
        /// <returns></returns>
        public static IList<Pieza>? ListarPiezasDeInventario(IList<InventarioTecnico> inventarios)
        {
            IList<Pieza>? piezas = new List<Pieza>();
            foreach (InventarioTecnico it in inventarios)
            {
                Pieza? pieza = ListarPieza(it.IdPieza);
                if (pieza != null)
                {
                    pieza.InventarioTecnicos.Add(it);
                    piezas.Add(pieza);
                }                    
            }
            return piezas;
        }

        /// <summary>
        /// Lista todas las piezas que el técnico tiene inventariadas
        /// </summary>
        /// <param name="tecnicoId"></param>
        /// <returns></returns>
        public static IList<Pieza>? ListarPiezasPorTecnico(int tecnicoId)
        {
            IList<InventarioTecnico>? inventariosTecnico = ListarInventarioTecnico(tecnicoId);
            if (inventariosTecnico != null)
                return ListarPiezasDeInventario(inventariosTecnico);
            else
                return null;
        }

        /// <summary>
        /// Obtiene un listado de todos los inventarios con la información completa del técnico y la pieza
        /// </summary>
        /// <returns>listado de inventarios con la información completa del técnico y la pieza</returns>
        public static IList<InventarioTecnico>? ListarInventarioTecnicosCompleto()
        {
            IList<InventarioTecnico>? inventarios = InventarioTecnicoADO.Listar();
            IList<InventarioTecnico> inventariosCompleto = new List<InventarioTecnico>();
            if (inventarios != null)
            {
                foreach (InventarioTecnico inventario in inventarios)
                {
                    InventarioTecnico? inventarioCompleto = ListarInventarioTecnicoCompleto(
                        inventario.IdPieza, inventario.IdTecnico);
                    if (inventarioCompleto!= null)
                        inventariosCompleto.Add(inventarioCompleto);
                }
            }
            return inventariosCompleto;
        }

        /// <summary>
        /// Obtiene un invenario de la base de datos a partir de su pieza y técnico
        /// </summary>
        /// <param name="idPieza">id de la pieza</param>
        /// <param name="idTecnico">id del técnico</param>
        /// <returns></returns>
        public static InventarioTecnico? ListarInventarioTecnico(long idPieza, int idTecnico)
        {
            return InventarioTecnicoADO.Listar(idPieza, idTecnico);
        }

        /// <summary>
        /// Obtiene un inventario con toda la información sobre el técnico y la pieza
        /// </summary>
        /// <param name="idPieza">id de la pieza</param>
        /// <param name="idTecnico">id del técnico</param>
        /// <returns></returns>
        public static InventarioTecnico? ListarInventarioTecnicoCompleto(long idPieza, int idTecnico)
        {
            InventarioTecnico? inventario = InventarioTecnicoADO.Listar(idPieza, idTecnico);
            if (inventario != null)
            {
                Tecnico? tecnico = TecnicoADO.Listar(inventario.IdTecnico);
                if (tecnico != null)
                    inventario.IdTecnicoNavigation = tecnico;

                Pieza? pieza = PiezaADO.Listar(inventario.IdPieza);
                if (pieza != null)
                    inventario.IdPiezaNavigation = pieza;
            }

            return inventario;
        }

        /// <summary>
        /// Inserta un inventario en la base de datos
        /// </summary>
        /// <param name="inventario">inventario a insertar</param>
        public static void InsertarInventarioTecnico(InventarioTecnico inventario)
        {
            InventarioTecnicoADO.Insertar(inventario);
        }

        /// <summary>
        /// Actualiza un inventario en la base de datos
        /// </summary>
        /// <param name="inventario">inventario con los datos actualizados</param>
        public static void ActualizarInventarioTecnico(InventarioTecnico inventario)
        {
            InventarioTecnicoADO.Actualizar(inventario);
        }

        /// <summary>
        /// Borra un inventario de la base de datos
        /// </summary>
        /// <param name="inventario">inventario a borrar</param>
        public static void BorrarInventarioTecnico(InventarioTecnico inventario)
        {
            InventarioTecnicoADO.Borrar(inventario);
        }
        #endregion

        #region "clientes"
        /// <summary>
        /// Lista todos los clientes de la base de datos
        /// </summary>
        /// <returns>lista de clientes</returns>
        public static IList<Cliente>? ListarClientes()
        {
            return ClienteADO.Listar();
        }

        /// <summary>
        /// Obtiene un listado de todos los clientes con la información completa de sus avisos
        /// </summary>
        /// <returns>listado de clientes con la información completa de los avisos</returns>
        public static IList<Cliente>? ListarClientesCompleto()
        {
            IList<Cliente>? clientes = ClienteADO.Listar();
            IList<Cliente> clientesCompleto = new List<Cliente>();
            if (clientesCompleto != null)
            {
                foreach (Cliente cliente in clientes)
                {
                    Cliente? clienteCompleto = ListarClienteCompleto(cliente.Id);
                    if (clienteCompleto != null)
                        clientesCompleto.Add(clienteCompleto);
                }
            }
            return clientesCompleto;
        }

        /// <summary>
        /// Obtiene el cliente de la base de datos con el id pasado por parámetro
        /// </summary>
        /// <param name="id">id del cliente</param>
        /// <returns>cliente asociado al id</returns>
        public static Cliente? ListarCliente(long id)
        {
            return ClienteADO.Listar(id);
        }

        /// <summary>
        /// Lista un cliente a partir del número de serie de un producto
        /// </summary>
        /// <param name="numeroSerieProducto">número de serie del producto</param>
        /// <returns></returns>
        public static Cliente? ListarClientePorProducto(string numeroSerieProducto)
        {
            Producto? producto = Gestion.ListarProducto(numeroSerieProducto);
            Cliente? cliente = null;
            if (producto != null)
                cliente = ListarCliente(producto.ClienteId);

            return cliente;
        }

        /// <summary>
        /// Obtiene un listado de los clientes con la información completa de sus avisos
        /// </summary>
        /// <param name="id">id del cliente</param>
        /// <returns>cliente con la información completa de los avisos</returns>
        public static Cliente? ListarClienteCompleto(long id)
        {
            Cliente? cliente = ClienteADO.Listar(id);
            if (cliente != null)
            {
                IList<Aviso>? avisos = AvisoADO.ListarPorCliente(id);
                if (avisos != null)
                    cliente.Avisos = avisos;

                IList<Producto>? productos = ProductoADO.ListarPorCliente(id);
                if (productos != null)
                {
                    cliente.Productos = productos;
                }
            }
            return cliente;
        }

        /// <summary>
        /// Inserta un cliente en la base de datos
        /// </summary>
        /// <param name="cliente">cliente a insertar</param>
        public static void InsertaCliente(Cliente cliente)
        {
            ClienteADO.Insertar(cliente);
        }

        /// <summary>
        /// Actualiza un cliente de la base de datos
        /// </summary>
        /// <param name="cliente">cliente a actualizar</param>
        public static void ActualizarCliente(Cliente cliente)
        {
            ClienteADO.Actualizar(cliente);
        }

        /// <summary>
        /// Borra un cliente de la base de datos
        /// </summary>
        /// <param name="cliente">cliente a borrar</param>
        public static void BorrarCliente(Cliente cliente)
        {
            ClienteADO.Borrar(cliente);
        }
        #endregion

        #region "productos"
        /// <summary>
        /// Lista todos los productos de la base de datos
        /// </summary>
        /// <returns>lista de productos</returns>
        public static IList<Producto>? ListarProductos()
        {
            return ProductoADO.Listar();
        }

        /// <summary>
        /// Obtiene un listado de todos los productos con la información completa de sus 
        /// avisos
        /// </summary>
        /// <returns>listado de productos con la información completa de los avisos</returns>
        public static IList<Producto>? ListarProductosCompleto()
        {
            IList<Producto>? productos = ProductoADO.Listar();
            IList<Producto> productosCompleto = new List<Producto>();
            if (productos != null)
            {
                foreach (Producto producto in productos)
                {
                    Producto? productoCompleto = ListarProductoCompleto(producto.NumeroSerie);
                    if (productoCompleto != null)
                        productosCompleto.Add(productoCompleto);
                }
            }
            return productosCompleto;
        }

        /// <summary>
        /// Obtiene el producto de la base de datos con el número de serie pasado por parámetro
        /// </summary>
        /// <param name="numeroSerie">número de serie del producto</param>
        /// <returns>producto asocidado al número de serie</returns>
        public static Producto? ListarProducto(string numeroSerie)
        {
            return ProductoADO.Listar(numeroSerie);
        }

        /// <summary>
        /// Obtiene un listado de los productos con la información completa de sus avisos
        /// </summary>
        /// <param name="numeroSerie">número de serie del producto</param>
        /// <returns>producto con la información completa de los avisos</returns>
        public static Producto? ListarProductoCompleto(string numeroSerie)
        {
            Producto? producto = ProductoADO.Listar(numeroSerie);
            if (producto != null)
            {
                IList<Aviso>? avisos = AvisoADO.ListarPorProducto(producto.NumeroSerie);
                if (avisos != null)
                    producto.Avisos = avisos;

                Cliente? cliente = ClienteADO.Listar(producto.ClienteId);
                if (cliente != null)
                {
                    producto.Cliente = cliente;
                }
            }
            return producto;
        }

        /// <summary>
        /// Inserta un producto en la base de datos
        /// </summary>
        /// <param name="producto">producto a insertar</param>
        public static void InsertarProducto(Producto producto)
        {
            ProductoADO.Insertar(producto);
        }

        /// <summary>
        /// Actualiza un producto de la base de datos
        /// </summary>
        /// <param name="producto">producto a actualizar</param>
        public static void ActualizarProducto(Producto producto)
        {
            ProductoADO.Actualizar(producto);
        }

        /// <summary>
        /// Borra un producto de la base de datos
        /// </summary>
        /// <param name="producto">producto a borrar</param>
        public static void BorrarProducto(Producto producto)
        {
            ProductoADO.Borrar(producto);
        }
        #endregion

        #region "dispose"
        // Public implementation of Dispose pattern callable by consumers.
        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        // Protected implementation of Dispose pattern.
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Liberar recursos no manejados como ficheros, conexiones a bd, etc.
            }

            disposed = true;
        }
        #endregion
    }
}
