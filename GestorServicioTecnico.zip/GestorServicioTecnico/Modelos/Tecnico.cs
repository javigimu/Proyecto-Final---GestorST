﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using Microsoft.EntityFrameworkCore;

namespace Modelos;

/// <summary>
/// <autor>Javier Giménez Muñoz</autor>
/// Clase Tecnico
/// Version 1.0
/// </summary>
[Table("tecnicos")]
public partial class Tecnico : INotifyPropertyChanged
{
    private int _id;
    private string _nombre;
    private string _apellidos;
    private string? _telefono;
    private string? _direccion;
    private string? _ciudad;
    private string? _provincia;
    private string? _codigoPostal;
    private string? _pais;
    private DateTime? _fechaNacimiento;
    private DateTime? _fechaContratacion;
    private byte[]? _foto;
    private string? _nif;
    private string? _formacion;
    private bool _extrabajador;
    private bool? _especialista;
    private bool? _vehiculoEmpresa;
    private bool _esTecnicoTaller;
    private bool _tieneCertificado;
    private string _password;

    // propiedad autocalculada para mostrar nombre y apellidos juntos
    public string NombreCompleto => Nombre + " " + Apellidos;
    
    /// <summary>
    /// Clave primaria.
    /// Id del empleado
    /// </summary>
    [Key]
    [Column("id")]
    public int Id
    {
        get { return _id; }
        set { _id = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Nombre del empleado
    /// </summary>
    [Column("nombre")]
    [StringLength(100)]
    public string Nombre
    {
        get { return _nombre; }
        set { _nombre = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Apellidos del empleado
    /// </summary>
    [Column("apellidos")]
    [StringLength(150)]
    public string Apellidos
    {
        get { return _apellidos; }
        set { _apellidos = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Teléfono del empleado
    /// </summary>
    [Column("telefono")]
    [StringLength(12)]
    public string? Telefono
    {
        get { return _telefono; }
        set { _telefono = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Dirección del empleado
    /// </summary>
    [Column("direccion")]
    [StringLength(150)]
    public string? Direccion
    {
        get { return _direccion; }
        set { _direccion = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Ciudad 
    /// </summary>
    [Column("ciudad")]
    [StringLength(100)]
    public string? Ciudad
    {
        get { return _ciudad; }
        set { _ciudad = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Provincia
    /// </summary>
    [Column("provincia")]
    [StringLength(100)]
    public string? Provincia
    {
        get { return _provincia; }
        set { _provincia = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Código Postal
    /// </summary>
    [Column("codigo_postal")]
    public string? CodigoPostal
    {
        get { return _codigoPostal; }
        set { _codigoPostal = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// País
    /// </summary>
    [Column("pais")]
    [StringLength(100)]
    public string? Pais
    {
        get { return _pais; }
        set { _pais = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Fecha de nacimiento del empleado
    /// </summary>
    [Column("fecha_nacimiento", TypeName = "datetime")]
    public DateTime? FechaNacimiento
    {
        get { return _fechaNacimiento; }
        set { _fechaNacimiento = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Fecha de contratación del empleado
    /// </summary>
    [Column("fecha_contratacion", TypeName = "datetime")]
    public DateTime? FechaContratacion
    {
        get { return _fechaContratacion; }
        set { _fechaContratacion = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Foto del empleado
    /// </summary>
    [Column("foto")]
    public byte[]? Foto
    {
        get { return _foto; }
        set { _foto = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// NIF del empleado
    /// </summary>
    [Column("nif")]
    [StringLength(9)]
    public string? Nif
    {
        get { return _nif; }
        set { _nif = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Formación del empleado
    /// </summary>
    [Column("formacion")]
    [StringLength(300)]
    public string? Formacion
    {
        get { return _formacion; }
        set { _formacion = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Indica si el trabajador ya no trabaja en la empresa
    /// </summary>
    [Column("extrabajador")]
    public bool Extrabajador
    {
        get { return _extrabajador; }
        set { _extrabajador = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Indica si es un técnico con cargo de especialista
    /// </summary>
    [Column("especialista")]
    public bool? Especialista { 
        get { return _especialista; } 
        set { _especialista = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Indica si el técnico utiliza vehículo de empresa
    /// </summary>
    [Column("vehiculo_empresa")]
    public bool? VehiculoEmpresa { 
        get { return _vehiculoEmpresa; }
        set { _vehiculoEmpresa = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Indica si es un técnico de taller
    /// </summary>
    [Column("es_tecnico_taller")]
    public bool EsTecnicoTaller 
    { 
        get { return _esTecnicoTaller; } 
        set { _esTecnicoTaller = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Indica si el técnico tiene certificado para poder reparar las piezas que lo requieren
    /// </summary>
    [Column("tiene_certificado")]
    public bool TieneCertificado
    {
        get { return _tieneCertificado; }
        set { _tieneCertificado = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Password del empleado
    /// </summary>
    [Column("password")]
    [StringLength(12)]
    public string? Password
    {
        get { return _password; }
        set { _password = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Clave ajena a Averias a partir de su Id
    /// </summary>
    [InverseProperty("Tecnico")]
    public virtual ICollection<Averia> Averia { get; set; } = new List<Averia>();

    /// <summary>
    /// Clave ajena a Avisos a partir de su Id
    /// </summary>
    [InverseProperty("Tecnico")]
    public virtual ICollection<Aviso> Avisos { get; set; } = new List<Aviso>();

    /// <summary>
    /// Colección de consumos de material
    /// </summary>
    [InverseProperty("Tecnico")]
    public virtual ICollection<ConsumosMaterial> ConsumosMaterials { get; set; } = new List<ConsumosMaterial>();

    /// <summary>
    /// Colección de reparaciones realizadas por el técnico
    /// </summary>
    [InverseProperty("Tecnico")]
    public virtual ICollection<Reparacione> Reparaciones { get; set; } = new List<Reparacione>();

    /// <summary>
    /// Colección con el inventario que tiene asignado el técnico
    /// </summary>
    [InverseProperty("IdTecnicoNavigation")]
    public virtual ICollection<InventarioTecnico> InventarioTecnicos { get; set; } = new List<InventarioTecnico>();


    /// <summary>
    /// Constructor sin parámetros
    /// </summary>
    public Tecnico()
    {
        _extrabajador = false;
        _especialista = false;
        _vehiculoEmpresa = true;
        _esTecnicoTaller = false;
        _tieneCertificado = false;
        _password = "password";
    }

    /// <summary>
    /// Constructor con todos los parámetros
    /// </summary>
    /// <param name="id">ID de empleado</param>
    /// <param name="nombre">Nombre</param>
    /// <param name="apellidos">Apellidos</param>
    /// <param name="telefono">Teléfono</param>
    /// <param name="direccion">Dirección</param>
    /// <param name="ciudad">Ciduad</param>
    /// <param name="provincia">Provincia</param>
    /// <param name="codigoPostal">Código postal</param>
    /// <param name="pais">País</param>
    /// <param name="fechaNacimiento">Fecha de nacimiento</param>
    /// <param name="fechaContratacion">Fecha de contratación</param>
    /// <param name="foto">Foto</param>
    /// <param name="nif">NIF</param>
    /// <param name="formacion">Formación</param>
    /// <param name="especialista">Indica si el técnico es un especialista</param>
    /// <param name="vehiculoEmpresa">Indica si el técnico usa vehículo de empresa</param>
    /// <param name="esTecnicoTaller">Indica si es un técnico de taller</param>
    /// <param name="tieneCertificado">Indica si tiene certificado para realizar las reparaciones que lo requieran</param>
    public Tecnico(int id, string nombre, string apellidos, string? telefono, string? direccion,
        string? ciudad, string? provincia, string? codigoPostal, string? pais, DateTime? fechaNacimiento,
        DateTime? fechaContratacion, byte[]? foto, string? nif, string? formacion, 
        bool? especialista, bool? vehiculoEmpresa, bool esTecnicoTaller, bool tieneCertificado)
    {
        _id = id;
        _nombre = nombre;
        _apellidos = apellidos;
        _telefono = telefono;
        _direccion = direccion;
        _ciudad = ciudad;
        _provincia = provincia;
        _codigoPostal = codigoPostal;
        _pais = pais;
        _fechaNacimiento = fechaNacimiento;
        _fechaContratacion = fechaContratacion;
        _foto = foto;
        _nif = nif;
        _formacion = formacion;
        _especialista = especialista;
        _vehiculoEmpresa = vehiculoEmpresa;
        _esTecnicoTaller = esTecnicoTaller;
        _tieneCertificado = tieneCertificado;
    }

    /// <summary>
    /// Constructor de copia para crear un técnico a partir de un empleado
    /// </summary>
    /// <param name="empleado"></param>
    public Tecnico(Empleado empleado) : this()
    {
        _id = empleado.Id;
        _nombre = empleado.Nombre;
        _apellidos = empleado.Apellidos;
        _telefono = empleado.Telefono;
        _direccion = empleado.Direccion;
        _ciudad = empleado.Ciudad;
        _provincia = empleado.Provincia;
        _codigoPostal = empleado.CodigoPostal;
        _pais = empleado.Pais;
        _fechaNacimiento = empleado.FechaNacimiento;
        _fechaContratacion = empleado.FechaContratacion;
        _foto = empleado.Foto;
        _nif = empleado.Nif;
        _formacion = empleado.Formacion;
    }

    /// <summary>
    /// ToString sobrecargado
    /// </summary>
    /// <returns>String con todos los campos separados por '__' excepto la foto</returns>
    public override string ToString()
    {
        return Id + "__" + Nombre + "__" + Apellidos + "__" + Telefono + "__" +
            Ciudad + "__" + Provincia + "__" + CodigoPostal + "__" + Pais + "__" +
            FechaNacimiento + "__" + FechaContratacion + "__" + Nif + "__" + Formacion + 
            "__" + (_especialista == true? "especialista" : "técnico") + "__" + 
            (_vehiculoEmpresa == true? "vehículo empresa" : "vehículo particular") + "__" +
            (_esTecnicoTaller == true? "técnico de taller" : "técnico de campo") + "__" + 
            (_tieneCertificado == true? "certificado" : "No certificado");
    }

    public event PropertyChangedEventHandler PropertyChanged;
    // Create the OnPropertyChanged method to raise the event
    // The calling member's name will be used as the parameter.
    protected void OnPropertyChanged([CallerMemberName] string name = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
