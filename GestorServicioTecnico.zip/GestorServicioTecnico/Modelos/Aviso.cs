﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using Microsoft.EntityFrameworkCore;

namespace Modelos;

/// <summary>
/// <autor>Javier Giménez Muñoz</autor>
/// Clase Aviso
/// Version 1.0
/// </summary>
[Table("avisos")]
public partial class Aviso : INotifyPropertyChanged
{
    private long _id;
    private int _coordinadorId;
    private string _descripcion;
    private int? _tecnicoId;
    private DateTime _fechaEntrada;
    private DateTime? _fechaMaximaFinalizacion;
    private DateTime? _fechaFinalizacion;
    private bool _facturable;
    private string _estado;
    private int? _km;
    private long _clienteId;    
    private string? _notas;
    private bool? _cierreConfirmado;
    private string _numeroSerie;
    private int? _horasResolucion;

    public bool AvisoFueraDePlazo => _fechaFinalizacion > _fechaMaximaFinalizacion;

    /// <summary>
    /// Clave primaria del aviso.
    /// Id autonumérico
    /// </summary>
    [Key]
    [Column("id")]
    public long Id 
    { 
        get { return _id; } 
        set { _id = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Id del coordinador
    /// </summary>
    [Column("coordinador_id")]
    public int CoordinadorId 
    { 
        get { return _coordinadorId; }
        set { _coordinadorId = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Descripción del aviso
    /// </summary>
    [Column("descripcion")]
    [StringLength(300)]
    public string Descripcion 
    { 
        get { return _descripcion; } 
        set { _descripcion = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Id del técnico
    /// </summary>
    [Column("tecnico_id")]
    public int? TecnicoId 
    { 
        get { return _tecnicoId; } 
        set { _tecnicoId = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Fecha de creación del aviso
    /// </summary>
    [Column("fecha_entrada", TypeName = "timestamp without time zone")]
    public DateTime FechaEntrada 
    { 
        get { return _fechaEntrada; } 
        set { _fechaEntrada = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Fecha máxima para finalizar el aviso
    /// </summary>
    [Column("fecha_maxima_finalizacion", TypeName = "timestamp without time zone")]
    public DateTime? FechaMaximaFinalizacion 
    { 
        get { return _fechaMaximaFinalizacion; } 
        set { _fechaMaximaFinalizacion = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Fecha de finalización del aviso
    /// </summary>
    [Column("fecha_finalizacion", TypeName = "timestamp without time zone")]
    public DateTime? FechaFinalizacion
    {
        get { return _fechaFinalizacion; }
        set { _fechaFinalizacion = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Indica si el aviso es facturable o no
    /// </summary>
    [Column("facturable")]
    public bool Facturable 
    { 
        get { return _facturable; } 
        set { _facturable = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Indica el estado en que se encuentra el aviso
    /// </summary>
    [Column("estado")]
    [StringLength(100)]
    public string Estado 
    { 
        get { return _estado; }
        set { _estado = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Kilómetros realizados en el desplazamiento
    /// </summary>
    [Column("km")]
    public int? Km 
    { 
        get { return _km; } 
        set { _km = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Id del cliente
    /// </summary>
    [Column("cliente_id")]
    public long ClienteId 
    { 
        get { return _clienteId; }
        set { _clienteId = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Información adicional sobre el aviso o la ubicación donde se realizará el aviso
    /// </summary>
    [Column("notas")]
    public string? Notas 
    { 
        get { return _notas; }
        set { _notas = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Indica si el cierre del aviso ha sido confirmado por un coordinador
    /// </summary>
    [Column("cierre_confirmado")]
    public bool? CierreConfirmado 
    { 
        get { return _cierreConfirmado; } 
        set { _cierreConfirmado = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Número de serie del producto a reparar
    /// </summary>
    [Column("numero_serie_producto")]
    [StringLength(30)]
    public string NumeroSerieProducto
    { 
        get { return _numeroSerie; } 
        set { _numeroSerie = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Horas de fin de resolución de averías
    /// </summary>
    [Column("horas_resolucion")]
    public int? HorasResolucion
    {
        get { return _horasResolucion; }
        set { _horasResolucion = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Clave ajena a clientes a partir de su id
    /// </summary>
    [ForeignKey("ClienteId")]
    [InverseProperty("Avisos")]
    public virtual Cliente Cliente { get; set; } = null!;


    /// <summary>
    /// Lista de consumos de material asociados al aviso
    /// </summary>
    [InverseProperty("Aviso")]
    public virtual ICollection<ConsumosMaterial> ConsumosMaterials { get; set; } = new List<ConsumosMaterial>();

    /// <summary>
    /// Clave ajena a Coordinadores a partir de su Id
    /// </summary>
    [ForeignKey("CoordinadorId")]
    [InverseProperty("Avisos")]
    public virtual Coordinadore Coordinador { get; set; } = null!;

    /// <summary>
    /// Clave ajena a Tecnicos a partir de su Id
    /// </summary>
    [ForeignKey("TecnicoId")]
    [InverseProperty("Avisos")]
    public virtual Tecnico? Tecnico { get; set; }

    /// <summary>
    /// Clave ajena al producto
    /// </summary>
    [ForeignKey("NumeroSerieProducto")]
    [InverseProperty("Avisos")]
    public virtual Producto NumeroSerieProductoNavigation { get; set; } = null!;

    /// <summary>
    /// Constructor sin parámetros
    /// </summary>
    public Aviso()
    {
        _fechaEntrada = DateTime.Now;
        _estado = "espera";
        _facturable = false;
        _cierreConfirmado = false;
        _horasResolucion = 24;
    }

    /// <summary>
    /// Constructor con todos los parámetros
    /// </summary>
    /// <param name="id">id del aviso</param>
    /// <param name="coordinadorId">id del coordinador</param>
    /// <param name="descripcion">descripción</param>
    /// <param name="tecnicoId">id del técnico</param>
    /// <param name="fechaEntrada">fecha de creación del aviso</param>
    /// <param name="fechaMaximaFinalizacion">fecha máxima de realización del aviso</param>
    /// <param name="fechaFinalizacion">fecha real de finalización del aviso</param>
    /// <param name="facturable">indica si el aviso es facturable</param>
    /// <param name="km">km de desplazamiento</param>
    /// <param name="estado">estado en el que se encuentra el aviso</param>
    /// <param name="clienteId">id del cliente</param>
    /// <param name="notas">anotaciones para destacar algún detalle necesario</paranm>
    /// <param name="numeroSerie">número de serie del producto a reparar</paran>
    public Aviso(long id, int coordinadorId, string descripcion, int? tecnicoId,
        DateTime fechaEntrada, DateTime? fechaMaximaFinalizacion, DateTime? fechaFinalizacion,
        bool facturable, int km, string estado, long clienteId, string notas, string numeroSerie)
    {
        _id = id;
        _coordinadorId = coordinadorId;
        _descripcion = descripcion;
        _tecnicoId = tecnicoId;
        _fechaEntrada = fechaEntrada;
        _fechaMaximaFinalizacion = fechaMaximaFinalizacion;
        _fechaFinalizacion = fechaFinalizacion;
        _facturable = facturable;
        _km = km;
        _estado = estado;
        _clienteId = clienteId;
        _notas = notas;
        _numeroSerie = numeroSerie;
    }

    /// <summary>
    /// ToString sobrecargado
    /// </summary>
    /// <returns>String con todos los campos separados por '__'</returns>
    public override string ToString()
    {
        return Id + "__" + ClienteId + "__" + NumeroSerieProducto + "__" + CoordinadorId + "__" + TecnicoId + "__" + 
            FechaEntrada + "__" + FechaMaximaFinalizacion + "__" + FechaFinalizacion + "__" 
            + Descripcion + "__" + Km + "__" + 
            (Facturable == true ? "Facturable" : "No facturable") + "__" + 
            Estado + "__" + ClienteId + "__" + Notas;            
    }

    /// <summary>
    /// Destructor.
    /// Se indica que vacíe la lista de consumos de material
    /// </summary>
    ~Aviso()
    {
        if (ConsumosMaterials != null)
        {
            ConsumosMaterials.Clear();
        }
    }

    public event PropertyChangedEventHandler PropertyChanged;
    // Create the OnPropertyChanged method to raise the event
    // The calling member's name will be used as the parameter.
    protected void OnPropertyChanged([CallerMemberName] string name = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
