﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using Microsoft.EntityFrameworkCore;

namespace Modelos;

/// <summary>
/// <autor>Javier Giménez Muñoz</autor>
/// Clase ConsumosMaterial
/// Version 1.0
/// </summary>
[PrimaryKey("TecnicoId", "PiezaId", "AvisoId")]
[Table("consumos_material")]
public partial class ConsumosMaterial : INotifyPropertyChanged
{
    private int _tecnicoId;
    private long _piezaId;
    private long _avisoId;
    private DateTime _fechaConsumo;
    private string? _anotaciones;
    private int _cantidad;

    /// <summary>
    /// Componente de la clave primaria.
    /// Id del técnico que realiza el consumo de material
    /// </summary>
    [Key]
    [Column("tecnico_id")]
    public int TecnicoId 
    { 
        get { return _tecnicoId; } 
        set { _tecnicoId = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Componente de la clave primaria.
    /// Id de la pieza consumida
    /// </summary>
    [Key]
    [Column("pieza_id")]
    public long PiezaId 
    { 
        get { return _piezaId; } 
        set { _piezaId = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Componente de la clave primaria.
    /// Id del aviso en el que se consume el material
    /// </summary>
    [Key]
    [Column("aviso_id")]
    public long AvisoId
    { 
        get { return _avisoId; } 
        set { _avisoId = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Fecha de consumo de la pieza
    /// </summary>
    [Column("fecha_consumo", TypeName = "timestamp without time zone")]
    public DateTime FechaConsumo 
    { 
        get { return _fechaConsumo; } 
        set { _fechaConsumo = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Información acerca de la avería de la pieza
    /// </summary>
    [Column("anotaciones")]
    [StringLength(300)]
    public string? Anotaciones 
    { 
        get { return _anotaciones; } 
        set { _anotaciones = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Cantidad consumida 
    /// </summary>
    [Column("cantidad")]
    public int Cantidad { 
        get { return _cantidad; } 
        set { _cantidad = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Clave ajena a Avisos a partir de su id
    /// </summary>
    [ForeignKey("AvisoId")]
    [InverseProperty("ConsumosMaterials")]
    public virtual Aviso Aviso { get; set; } = null!;

    /// <summary>
    /// Clave ajena a Piezas a partir de su id
    /// </summary>
    [ForeignKey("PiezaId")]
    [InverseProperty("ConsumosMaterials")]
    public virtual Pieza Pieza { get; set; } = null!;

    /// <summary>
    /// Clave ajena a Tecnicos a partir de su id
    /// </summary>
    [ForeignKey("TecnicoId")]
    [InverseProperty("ConsumosMaterials")]
    public virtual Tecnico Tecnico { get; set; } = null!;


    /// <summary>
    /// Constructor sin parámetros
    /// </summary>
    public ConsumosMaterial()
    {
        _fechaConsumo = DateTime.Now;
        _cantidad = 1;
    }
   
    /// <summary>
    /// Constructor con todos los parámetros
    /// </summary>
    /// <param name="tecnicoId">id del técnico</param>
    /// <param name="piezaId">id de la pieza</param>
    /// <param name="avisoId">id del aviso</param>
    /// <param name="fechaConsumo">Fecha en la que se realiza el consumo</param>
    /// <param name="anotaciones">Anotaciones</param>
    /// <param name="cantidad">Cantidad</param>
    public ConsumosMaterial(int tecnicoId, long piezaId, long avisoId, DateTime fechaConsumo, 
        string? anotaciones, int cantidad) : this()
    {
        _tecnicoId = tecnicoId;
        _piezaId = piezaId;
        _avisoId = avisoId;
        _fechaConsumo = fechaConsumo;
        _anotaciones = anotaciones;
        _cantidad = cantidad;
    }

    /// <summary>
    /// Crea un consumo de material con los datos del técnico, pieza y aviso
    /// </summary>
    /// <param name="pieza"></param>
    public ConsumosMaterial(int tecnicoId, long piezaId, long avisoId) : this()
    {
        _tecnicoId = tecnicoId;
        _piezaId = piezaId;
        _avisoId = avisoId;
    }

    /// <summary>
    /// Sobrecarga del método ToString
    /// </summary>
    /// <returns>String con todos los campos separados por '__'</returns>
    public override string ToString()
    {
        return TecnicoId + "__" + PiezaId + "__" + AvisoId + "__" + FechaConsumo + "__" 
            + Cantidad + "__" + Anotaciones;
    }


    public event PropertyChangedEventHandler PropertyChanged;
    // Create the OnPropertyChanged method to raise the event
    // The calling member's name will be used as the parameter.
    protected void OnPropertyChanged([CallerMemberName] string name = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
