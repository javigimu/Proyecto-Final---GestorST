﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using Microsoft.EntityFrameworkCore;

namespace Modelos;

/// <summary>
/// <autor>Javier Giménez Muñoz</autor>
/// Clase Producto
/// Version 1.0
/// </summary>
[Table("productos")]
public partial class Producto : INotifyPropertyChanged
{
    private string _numeroSerie;
    private string _nombre;
    private string _modelo;
    private string _fabricante;
    private string _direccion;
    private string _ciudad;
    private string _provincia;
    private long _clienteId;

    /// <summary>
    /// Clave primaria.
    /// Número de serie identificativo
    /// </summary>
    [Key]
    [Column("numero_serie")]
    [StringLength(30)]
    public string NumeroSerie 
    { 
        get { return _numeroSerie; }
        set { _numeroSerie = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Nombre
    /// </summary>
    [Column("nombre")]
    [StringLength(200)]
    public string Nombre 
    { 
        get { return _nombre; } 
        set { _nombre = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Modelo
    /// </summary>
    [Column("modelo")]
    [StringLength(100)]
    public string Modelo 
    { 
        get { return _modelo; } 
        set { _modelo = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Fabricante
    /// </summary>
    [Column("fabricante")]
    [StringLength(150)]
    public string Fabricante 
    { 
        get { return _fabricante; } 
        set { _fabricante = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Dirección donde se tiene que realizar el aviso, que puede ser diferente a la del cliente
    /// </summary>
    [Column("direccion")]
    [StringLength(150)]
    public string? Direccion
    {
        get { return _direccion; }
        set { _direccion = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Ciudad de realización del aviso
    /// </summary>
    [Column("ciudad")]
    [StringLength(150)]
    public string? Ciudad
    {
        get { return _ciudad; }
        set { _ciudad = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Provincia de realización del aviso
    /// </summary>
    [Column("provincia")]
    [StringLength(150)]
    public string? Provincia
    {
        get { return _provincia; }
        set { _provincia = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Id del cliente al que pertence el producto
    /// </summary>
    [Column("cliente_id")]
    public long ClienteId 
    { 
        get { return _clienteId; }
        set { _clienteId = value; OnPropertyChanged(); }
    }
        

    /// <summary>
    /// Clave ajena a los avisos que se han abierto para el producto
    /// </summary>
    [InverseProperty("NumeroSerieProductoNavigation")]
    public virtual ICollection<Aviso> Avisos { get; set; } = new List<Aviso>();

    /// <summary>
    /// Información completa del cliente al que pertenece el producto
    /// </summary>
    [ForeignKey("ClienteId")]
    [InverseProperty("Productos")]
    public virtual Cliente Cliente { get; set; } = null!;

    /// <summary>
    /// Constructor sin parámetros
    /// </summary>
    public Producto()
    {

    }
   
    /// <summary>
    /// Constructor con todos los parámetros
    /// </summary>
    /// <param name="numeroSerie">Número de serie</param>
    /// <param name="nombre">Nombre</param>
    /// <param name="modelo">Modelo</param>
    /// <param name="fabricante">Fabricante</param>
    /// <param name="direccion">Dirección</param>
    /// <param name="ciudad">Ciudad</param>
    /// <param name="provincia">Provincia</param>
    /// <param name="clienteId">Id del cliente</param>
    public Producto(string numeroSerie, string nombre, string modelo, string fabricante,
        string direccion, string ciudad, string provincia, long clienteId)
    {
        _numeroSerie = numeroSerie;
        _nombre = nombre;
        _modelo = modelo;
        _fabricante = fabricante;
        _direccion = direccion;
        _ciudad = ciudad;
        _provincia = provincia;
        _clienteId = clienteId;
    }

    /// <summary>
    /// ToString sobrecargado
    /// </summary>
    /// <returns>String con todos los campos separados por '__'</returns>
    public override string ToString()
    {
        return ClienteId + "__" + NumeroSerie + "__" + Nombre + "__" + Modelo + "__" + Fabricante + "__" +
            Direccion + "__" + Ciudad + "__" + Provincia;
    }


    public event PropertyChangedEventHandler PropertyChanged;
    // Create the OnPropertyChanged method to raise the event
    // The calling member's name will be used as the parameter.
    protected void OnPropertyChanged([CallerMemberName] string name = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
