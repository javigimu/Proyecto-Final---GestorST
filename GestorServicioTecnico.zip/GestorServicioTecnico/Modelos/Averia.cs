﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using Microsoft.EntityFrameworkCore;

namespace Modelos;

/// <summary>
/// <autor>Javier Giménez Muñoz</autor>
/// Clase Averia
/// Version 1.0
/// </summary>
[Table("averias")]
public partial class Averia : IComparable<Averia>, INotifyPropertyChanged
{
    private int _id;
    private long _piezaId;
    private int _tecnicoId;
    private DateTime _fechaAveria;
    private string _descripcion;
    private string _estado;

    /// <summary>
    /// Clave primaria de la avería.
    /// Id autonumérico
    /// </summary>
    [Key]
    [Column("id")]
    public int Id
    {
        get { return _id; }
        set { _id = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Clave ajena a Piezas
    /// </summary>
    [Column("pieza_id")]
    public long PiezaId 
    { 
        get { return _piezaId; } 
        set { _piezaId = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Clave ajena a Tecnicos
    /// </summary>
    [Column("tecnico_id")]
    public int TecnicoId 
    { 
        get { return _tecnicoId; }
        set { _tecnicoId = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Fecha de la avería
    /// </summary>
    [Column("fecha_averia", TypeName = "timestamp without time zone")]
    public DateTime FechaAveria 
    { 
        get { return _fechaAveria; } 
        set { _fechaAveria = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Descripción de la avería
    /// </summary>
    [Column("descripcion")]
    [StringLength(200)]
    public string Descripcion 
    { 
        get { return _descripcion; } 
        set { _descripcion = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Estado en el que se encuentra la avería
    /// </summary>
    [Column("estado")]
    [StringLength(100)]
    public string Estado 
    { 
        get { return _estado; }
        set { _estado = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Clave ajena a Piezas para enlazar con los datos de la pieza a través del id
    /// </summary>
    [ForeignKey("PiezaId")]
    [InverseProperty("Averia")]
    public virtual Pieza Pieza { get; set; } = null!;

    /// <summary>
    /// Clave ajena a Tecnicos para enlazar con los datos del técnico a través del id
    /// </summary>
    [ForeignKey("TecnicoId")]
    [InverseProperty("Averia")]
    public virtual Tecnico Tecnico { get; set; } = null!;

    /// <summary>
    /// Constructor sin parámetros
    /// </summary>
    public Averia()
    {
        _fechaAveria = DateTime.Now;
        _descripcion = "";
        _estado = "abierto";
    }

    /// <summary>
    /// Constructor con todos los parámetros
    /// </summary>
    /// <param name="id">id avería</param>
    /// <param name="piezaId">id pieza</param>
    /// <param name="tecnicoId">id técnico</param>
    /// <param name="fechaAveria">fecha avería</param>
    /// <param name="descripcion">descripción</param>
    public Averia(int id, long piezaId, int tecnicoId, DateTime fechaAveria, string descripcion)
    {
        _id = id;
        _piezaId = piezaId;
        _tecnicoId = tecnicoId;
        _fechaAveria = fechaAveria;
        _descripcion = descripcion;
    }

    /// <summary>
    /// Compara las averías por fecha descendente
    /// </summary>
    /// <param name="other">segunda avería a comparar</param>
    /// <returns>resultado < 0 si other es mayor o null, 0 si son iguales y > 0 si other es menor</returns>
    /// <exception cref="NotImplementedException"></exception>
    public int CompareTo(Averia? other)
    {
        return other != null ? other.FechaAveria.CompareTo(FechaAveria) : -1;
    }

    /// <summary>
    /// ToString sobrecargado
    /// </summary>
    /// <returns>String con todos los campos separados por '__'</returns>
    public override string ToString()
    {
        return Id + "__" + PiezaId + "__" + TecnicoId + "__" + FechaAveria + "__" + Descripcion + "__" + Estado;
    }

    public event PropertyChangedEventHandler PropertyChanged;

    // Create the OnPropertyChanged method to raise the event
    // The calling member's name will be used as the parameter.
    protected void OnPropertyChanged([CallerMemberName] string name = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
