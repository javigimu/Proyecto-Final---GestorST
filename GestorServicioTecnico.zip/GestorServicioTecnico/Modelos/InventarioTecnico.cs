﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using Microsoft.EntityFrameworkCore;

namespace Modelos;

/// <summary>
/// <autor>Javier Giménez Muñoz</autor>
/// Clase InventarioTecnico
/// Version 1.0
/// </summary>
[PrimaryKey("IdPieza", "IdTecnico")]
[Table("inventario_tecnicos")]
public partial class InventarioTecnico : INotifyPropertyChanged
{
    private long _idPieza;
    private int _idTecnico;
    private int _cantidad;

    /// <summary>
    /// id de la pieza
    /// </summary>
    [Key]
    [Column("id_pieza")]
    public long IdPieza
    {
        get { return _idPieza; }
        set { _idPieza = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// id del técnico
    /// </summary>
    [Key]
    [Column("id_tecnico")]
    public int IdTecnico
    {
        get { return _idTecnico; }
        set { _idTecnico = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// cantidad
    /// </summary>
    [Column("cantidad")]
    public int Cantidad
    {
        get { return _cantidad; }
        set { _cantidad = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Clave ajena a Piezas a partir de su id
    /// </summary>
    [ForeignKey("IdPieza")]
    [InverseProperty("InventarioTecnicos")]
    public virtual Pieza IdPiezaNavigation { get; set; } = null!;

    /// <summary>
    /// Clave ajena a Tecnicos a partir de su id
    /// </summary>
    [ForeignKey("IdTecnico")]
    [InverseProperty("InventarioTecnicos")]
    public virtual Tecnico IdTecnicoNavigation { get; set; } = null!;

    /// <summary>
    /// Constructor sin parámetros, con la cantidad a 1 por defecto
    /// </summary>
    public InventarioTecnico()
    {
        _cantidad = 1;
    }

    /// <summary>
    /// Constructor con todos los parámetros
    /// </summary>
    /// <param name="idPieza">id de la pieza</param>
    /// <param name="idTecnico">id del técnico</param>
    /// <param name="cantidad">cantidad</param>
    public InventarioTecnico(long idPieza, int idTecnico, int cantidad)
    {
        _idPieza = idPieza;
        _idTecnico = idTecnico;
        _cantidad = cantidad;
    }

    /// <summary>
    /// sobrecarga del método ToString()
    /// </summary>
    /// <returns>String con todos los campos separados por '__'</returns>
    public override string ToString()
    {
        return IdPieza + "__" + IdTecnico + "__" + Cantidad;
    }

    public event PropertyChangedEventHandler PropertyChanged;

    // Create the OnPropertyChanged method to raise the event
    // The calling member's name will be used as the parameter.
    protected void OnPropertyChanged([CallerMemberName] string name = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
