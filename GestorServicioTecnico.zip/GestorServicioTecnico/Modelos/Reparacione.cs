﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using Microsoft.EntityFrameworkCore;

namespace Modelos;

/// <summary>
/// <autor>Javier Giménez Muñoz</autor>
/// Clase Reparacione
/// Version 1.0
/// </summary>
[Table("reparaciones")]
public partial class Reparacione : INotifyPropertyChanged
{
    private int _id;
    private DateTime _fechaReparacion;
    private string _descripcion;
    private bool _irreparable;
    private long _piezaId;
    private int _tecnicoId;

    /// <summary>
    /// Clave primaria.
    /// Id de la reparación
    /// </summary>
    [Key]
    [Column("id")]
    public int Id { 
        get { return _id; }
        set { _id = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Fecha de reparación
    /// </summary>
    [Column("fecha_reparacion", TypeName = "timestamp without time zone")]
    public DateTime FechaReparacion 
    { 
        get { return _fechaReparacion; } 
        set { _fechaReparacion = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Descripción
    /// </summary>
    [Column("descripcion")]
    [StringLength(300)]
    public string Descripcion 
    { 
        get { return _descripcion; } 
        set { _descripcion = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Indica si la pieza es irreparable
    /// </summary>
    [Column("irreparable")]
    public bool Irreparable 
    { 
        get { return _irreparable; } 
        set { _irreparable = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Id de la pieza reparada
    /// </summary>
    [Column("pieza_id")]
    public long PiezaId 
    { 
        get { return _piezaId; }
        set { _piezaId = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Id del técnico que realiza la reparación
    /// </summary>
    [Column("tecnico_id")]
    public int TecnicoId 
    { 
        get { return _tecnicoId; }
        set { _tecnicoId = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Clave ajena a Piezas a partir de su Id
    /// </summary>
    [ForeignKey("PiezaId")]
    [InverseProperty("Reparaciones")]
    public virtual Pieza Pieza { get; set; } = null!;

    /// <summary>
    /// Clave ajena a Tecnicos a partir de su Id
    /// </summary>
    [ForeignKey("TecnicoId")]
    [InverseProperty("Reparaciones")]
    public virtual Tecnico Tecnico { get; set; } = null!;

    /// <summary>
    /// Constructor sin parámetros
    /// </summary>
    public Reparacione()
    {
        _fechaReparacion = DateTime.Now;
    }
    
    /// <summary>
    /// Constructor con todos los parámetros
    /// </summary>
    /// <param name="id">Id de la reparación</param>
    /// <param name="fechaReparacion">Fecha de finalización de la reparación</param>
    /// <param name="descripcion">Descripción de la reparación realizada</param>
    /// <param name="irreparable">Indica si es irreparable</param>
    /// <param name="piezaId">Id de la pieza reparada</param>
    /// <param name="tecnicoId">Id del técnico que ha realizado la reparación</param>
    public Reparacione(int id, DateTime fechaReparacion, string descripcion, bool irreparable,
        long piezaId, int tecnicoId)
    {
        _id = id;
        _fechaReparacion = fechaReparacion;
        _descripcion = descripcion;
        _irreparable = irreparable;
        _piezaId = piezaId;
        _tecnicoId = tecnicoId;
    }

    /// <summary>
    /// Sobrecarga del método ToString()
    /// </summary>
    /// <returns>Todos los atributos de la reaparación separados por '__'</returns>
    public override string ToString()
    {
        return Id + "__" + FechaReparacion + "__" + Descripcion + "__" +
            (Irreparable == true ? "Irreparable" : "Reparado") + "__" +
            PiezaId + "__" + TecnicoId;
    }


    public event PropertyChangedEventHandler PropertyChanged;
    // Create the OnPropertyChanged method to raise the event
    // The calling member's name will be used as the parameter.
    protected void OnPropertyChanged([CallerMemberName] string name = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
