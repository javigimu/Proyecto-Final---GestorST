﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using Microsoft.EntityFrameworkCore;

namespace Modelos;

/// <summary>
/// <autor>Javier Giménez Muñoz</autor>
/// Clase Pieza
/// Version 1.0
/// </summary>
[Table("piezas")]
[Index("Nombre", Name = "pieza_unica", IsUnique = true)]
public partial class Pieza : INotifyPropertyChanged
{
    private long _id;
    private string _nombre;
    private string? _descripcion;
    private bool _necesitaCertificado;
    private bool _baja;
    private bool _consumible;
    private byte[]? _imagen;
    private int _stock;

    /// <summary>
    /// Clave primaria.
    /// Id de la pieza
    /// </summary>
    [Key]
    [Column("id")]
    public long Id { 
        get { return _id; } 
        set { _id = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Nombre identificativo de la pieza
    /// </summary>
    [Column("nombre")]
    [StringLength(50)]
    public string Nombre { 
        get { return _nombre; } 
        set { _nombre = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Descripción
    /// </summary>
    [Column("descripcion")]
    [StringLength(100)]
    public string? Descripcion 
    { 
        get { return _descripcion; }
        set { _descripcion = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Indica si la pieza necesita certificación para su reparación
    /// </summary>
    [Column("necesita_certificado")]
    public bool NecesitaCertificado 
    { 
        get { return _necesitaCertificado; } 
        set { _necesitaCertificado = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Indica si la pieza está dada de baja
    /// </summary>
    [Column("baja")]
    public bool Baja { 
        get { return _baja; } 
        set { _baja = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Indica si la pieza es consumible (de un solo uso)
    /// </summary>
    [Column("consumible")]
    public bool Consumible { 
        get { return _consumible; } 
        set { _consumible= value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Imagen de la pieza
    /// </summary>
    [Column("imagen")]
    public byte[]? Imagen { 
        get { return _imagen; } 
        set { _imagen = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Cantidad de la pieza en stock
    /// </summary>
    [Column("stock")]
    public int Stock 
    { 
        get { return _stock; } 
        set { _stock = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Clave ajena a Averias a partir de su Id
    /// </summary>
    [InverseProperty("Pieza")]
    public virtual ICollection<Averia> Averia { get; set; } = new List<Averia>();

    /// <summary>
    /// Clave ajena a ConsumosMaterials a partir de su Id
    /// </summary>
    [InverseProperty("Pieza")]
    public virtual ICollection<ConsumosMaterial> ConsumosMaterials { get; set; } = new List<ConsumosMaterial>();

    /// <summary>
    /// Clave ajena a Inventarios a partir de su Id
    /// </summary>
    [InverseProperty("IdPiezaNavigation")]
    public virtual ICollection<InventarioTecnico> InventarioTecnicos { get; set; } = new List<InventarioTecnico>();

    /// <summary>
    /// Clave ajena a Reparaciones a partir de su Id
    /// </summary>
    [InverseProperty("Pieza")]
    public virtual ICollection<Reparacione> Reparaciones { get; set; } = new List<Reparacione>();

    /// <summary>
    /// Constructor sin parámetros
    /// </summary>
    public Pieza()
    {
        _baja = false;
        _consumible = true;
        _necesitaCertificado = false;
        _stock = 1;
        Imagen = null;
    }

    /// <summary>
    /// Constructor con todos los parámetros
    /// </summary>
    /// <param name="id">Id de la pieza</param>
    /// <param name="nombre">Nombre</param>
    /// <param name="descripcion">Descripción</param>
    /// <param name="necesitaCertificado">Indica si necesita certificado</param>
    /// <param name="baja">Indica si está de baja</param>
    /// <param name="consumible">Indica si es consumible (de un solo uso)</param>
    /// <param name="imagen">Imagen</param>
    /// <param name="stock">Stock</param>
    public Pieza(long id, string nombre, string descripcion, bool necesitaCertificado, 
        bool baja, bool consumible, byte[]? imagen, int stock)
    {
        _id = id;
        _nombre = nombre;
        _descripcion = descripcion;
        _necesitaCertificado = necesitaCertificado;
        _baja = baja;
        _consumible = consumible;
        _imagen = imagen;
        _stock= stock;
    }

    /// <summary>
    /// Sobrecarga del método ToString() sin incluir la imagen
    /// </summary>
    /// <returns></returns>
    public override string ToString()
    {
        return Id + "__" + Nombre + "__" + Descripcion + "__" + Stock + "__" +
            (NecesitaCertificado == true ? "Necesita certificado" : "Sin certificado") + "__" +
            (Baja == true ? "Baja" : "Alta") + "__" +
            (Consumible == true ? "Consumible" : "Piezaa principal");
    }


    public event PropertyChangedEventHandler PropertyChanged;
    // Create the OnPropertyChanged method to raise the event
    // The calling member's name will be used as the parameter.
    protected void OnPropertyChanged([CallerMemberName] string name = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
