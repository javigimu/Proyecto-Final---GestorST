﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using Microsoft.EntityFrameworkCore;

namespace Modelos;

/// <summary>
/// <autor>Javier Giménez Muñoz</autor>
/// Clase Logísitico
/// Version 1.0
/// </summary>
[Table("logisticos")]
public partial class Logistico : INotifyPropertyChanged
{
    private int _id;
    private string _nombre;
    private string _apellidos;
    private string? _telefono;
    private string? _direccion;
    private string? _ciudad;
    private string? _provincia;
    private string? _codigoPostal;
    private string? _pais;
    private DateTime? _fechaNacimiento;
    private DateTime? _fechaContratacion;
    private byte[]? _foto;
    private string? _nif;
    private string? _formacion;
    private bool _extrabajador;
    private string _password;

    // propiedad autocalculada para mostrar nombre y apellidos juntos
    public string NombreCompleto => Nombre + " " + Apellidos;

    /// <summary>
    /// Clave primaria.
    /// Id de empleado
    /// </summary>
    [Key]
    [Column("id")]
    public int Id
    {
        get { return _id; }
        set { _id = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Nombre del logístico
    /// </summary>
    [Column("nombre")]
    [StringLength(100)]
    public string Nombre
    {
        get { return _nombre; }
        set { _nombre = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Apellidos del logístico
    /// </summary>
    [Column("apellidos")]
    [StringLength(150)]
    public string Apellidos
    {
        get { return _apellidos; }
        set { _apellidos = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Teléfono del logístico
    /// </summary>
    [Column("telefono")]
    [StringLength(12)]
    public string? Telefono
    {
        get { return _telefono; }
        set { _telefono = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Dirección del logístico
    /// </summary>
    [Column("direccion")]
    [StringLength(150)]
    public string? Direccion
    {
        get { return _direccion; }
        set { _direccion = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Ciudad 
    /// </summary>
    [Column("ciudad")]
    [StringLength(100)]
    public string? Ciudad
    {
        get { return _ciudad; }
        set { _ciudad = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Provincia
    /// </summary>
    [Column("provincia")]
    [StringLength(100)]
    public string? Provincia
    {
        get { return _provincia; }
        set { _provincia = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Código Postal
    /// </summary>
    [Column("codigo_postal")]
    public string? CodigoPostal
    {
        get { return _codigoPostal; }
        set { _codigoPostal = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// País
    /// </summary>
    [Column("pais")]
    [StringLength(100)]
    public string? Pais
    {
        get { return _pais; }
        set { _pais = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Fecha de nacimiento del logístico
    /// </summary>
    [Column("fecha_nacimiento", TypeName = "datetime")]
    public DateTime? FechaNacimiento
    {
        get { return _fechaNacimiento; }
        set { _fechaNacimiento = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Fecha de contratación del logístico
    /// </summary>
    [Column("fecha_contratacion", TypeName = "datetime")]
    public DateTime? FechaContratacion
    {
        get { return _fechaContratacion; }
        set { _fechaContratacion = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Foto del logístico
    /// </summary>
    [Column("foto")]
    public byte[]? Foto
    {
        get { return _foto; }
        set { _foto = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// NIF del logístico
    /// </summary>
    [Column("nif")]
    [StringLength(9)]
    public string? Nif
    {
        get { return _nif; }
        set { _nif = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Formación del logístico
    /// </summary>
    [Column("formacion")]
    [StringLength(300)]
    public string? Formacion
    {
        get { return _formacion; }
        set { _formacion = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Indica si el trabajador ya no trabaja en la empresa
    /// </summary>
    [Column("extrabajador")]
    public bool Extrabajador
    {
        get { return _extrabajador; }
        set { _extrabajador = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Password del empleado
    /// </summary>
    [Column("password")]
    [StringLength(12)]
    public string? Password
    {
        get { return _password; }
        set { _password = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Constructor sin parámetros del logístico
    /// </summary>
    public Logistico()
    {
        _extrabajador = false;
        _password = "password";
    }

    /// <summary>
    /// Constructor con todos los parámetros
    /// </summary>
    /// <param name="id">ID de empleado</param>
    /// <param name="nombre">Nombre</param>
    /// <param name="apellidos">Apellidos</param>
    /// <param name="telefono">Teléfono</param>
    /// <param name="direccion">Dirección</param>
    /// <param name="ciudad">Ciduad</param>
    /// <param name="provincia">Provincia</param>
    /// <param name="codigoPostal">Código postal</param>
    /// <param name="pais">País</param>
    /// <param name="fechaNacimiento">Fecha de nacimiento</param>
    /// <param name="fechaContratacion">Fecha de contratación</param>
    /// <param name="foto">Foto</param>
    /// <param name="nif">NIF</param>
    /// <param name="formacion">Formación</param>
    public Logistico(int id, string nombre, string apellidos, string? telefono, string? direccion,
        string? ciudad, string? provincia, string? codigoPostal, string? pais, DateTime? fechaNacimiento,
        DateTime? fechaContratacion, byte[]? foto, string? nif, string? formacion)
    {
        _id = id;
        _nombre = nombre;
        _apellidos = apellidos;
        _telefono = telefono;
        _direccion = direccion;
        _ciudad = ciudad;
        _provincia = provincia;
        _codigoPostal = codigoPostal;
        _pais = pais;
        _fechaNacimiento = fechaNacimiento;
        _fechaContratacion = fechaContratacion;
        _foto = foto;
        _nif = nif;
        _formacion = formacion;
    }


    /// <summary>
    /// Constructor de copia para crear un logístico a partir de un empleado
    /// </summary>
    /// <param name="empleado"></param>
    public Logistico(Empleado empleado) : this()
    {
        _id = empleado.Id;
        _nombre = empleado.Nombre;
        _apellidos = empleado.Apellidos;
        _telefono = empleado.Telefono;
        _direccion = empleado.Direccion;
        _ciudad = empleado.Ciudad;
        _provincia = empleado.Provincia;
        _codigoPostal = empleado.CodigoPostal;
        _pais = empleado.Pais;
        _fechaNacimiento = empleado.FechaNacimiento;
        _fechaContratacion = empleado.FechaContratacion;
        _foto = empleado.Foto;
        _nif = empleado.Nif;
        _formacion = empleado.Formacion;
    }

    /// <summary>
    /// ToString sobrecargado
    /// </summary>
    /// <returns>String con todos los campos separados por '__' excepto la foto</returns>
    public override string ToString()
    {
        return Id + "__" + Nombre + "__" + Apellidos + "__" + Telefono + "__" +
            Ciudad + "__" + Provincia + "__" + CodigoPostal + "__" + Pais + "__" +
            FechaNacimiento + "__" + FechaContratacion + "__" + Nif + "__" + Formacion;
    }

    public event PropertyChangedEventHandler PropertyChanged;
    // Create the OnPropertyChanged method to raise the event
    // The calling member's name will be used as the parameter.
    protected void OnPropertyChanged([CallerMemberName] string name = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
