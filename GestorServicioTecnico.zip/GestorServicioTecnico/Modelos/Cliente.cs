﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using Microsoft.EntityFrameworkCore;

namespace Modelos;

/// <summary>
/// <autor>Javier Giménez Muñoz</autor>
/// Clase Cliente
/// Version 1.0
/// </summary>
[Table("clientes")]
public partial class Cliente : INotifyPropertyChanged
{
    private long _id;
    private string _nombre;
    private string _telefono;
    private string? _mail;
    private string _direccion;
    private string _ciudad;
    private string _provincia;

    /// <summary>
    /// Clave primaria del cliente.
    /// Id autonumérico
    /// </summary>
    [Key]
    [Column("id")]
    public long Id 
    { 
        get { return _id; } 
        set { _id = value; OnPropertyChanged(); } 
    }

    /// <summary>
    /// Nombre del cliente (nombre completo para particulares o nombre de la empresa)
    /// </summary>
    [Column("nombre")]
    [StringLength(300)]
    public string Nombre 
    {
        get { return _nombre; } 
        set { _nombre = value; OnPropertyChanged(); }
    } 

    /// <summary>
    /// Teléfono de contacto
    /// </summary>
    [Column("telefono")]
    [StringLength(12)]
    public string Telefono 
    { 
        get { return _telefono; } 
        set { _telefono = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Email
    /// </summary>
    [Column("mail")]
    [StringLength(150)]
    public string? Mail 
    { 
        get { return _mail; } 
        set { _mail = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Dirección
    /// </summary>
    [Column("direccion")]
    [StringLength(150)]
    public string Direccion 
    { 
        get { return _direccion; }
        set { _direccion = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Ciudad
    /// </summary>
    [Column("ciudad")]
    [StringLength(150)]
    public string Ciudad 
    { 
        get { return _ciudad; }
        set { _ciudad = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Provincia
    /// </summary>
    [Column("provincia")]
    [StringLength(150)]
    public string Provincia 
    { 
        get { return _provincia; } 
        set { _provincia = value; OnPropertyChanged(); }
    }

    /// <summary>
    /// Clave ajena a los avisos del cliente a partir de su id
    /// </summary>
    [InverseProperty("Cliente")]
    public virtual ICollection<Aviso> Avisos { get; set; } = new List<Aviso>();

    /// <summary>
    /// Productos asociados a un cliente
    /// </summary>
    [InverseProperty("Cliente")]
    public virtual ICollection<Producto> Productos { get; set; } = new List<Producto>();

    /// <summary>
    /// Constructor sin parámetros
    /// </summary>
    public Cliente()
    {

    }

    /// <summary>
    /// Constructor con todos los parámetros
    /// </summary>
    /// <param name="id">id del cliente</param>
    /// <param name="nombre">nombre</param>
    /// <param name="telefono">teléfono</param>
    /// <param name="mail">email</param>
    /// <param name="direccion">dirección</param>
    /// <param name="ciudad">ciudad</param>
    /// <param name="provincia">provincia</param>
    public Cliente(long id, string nombre, string telefono, string mail, 
        string direccion, string ciudad, string provincia)
    {
        _id = id;
        _nombre = nombre;
        _telefono = telefono;
        _mail = mail;
        _direccion = direccion;
        _ciudad = ciudad;
        _provincia = provincia;
    }

    /// <summary>
    /// Método ToString sobrecargado con los atributos separados por "__"
    /// </summary>
    /// <returns>cadena de texto con todos los atributos separados por "__"</returns>
    public override string ToString()
    {
        return Id + "__" + Nombre + "__" + Telefono + "__" + Mail + "__" +
            Direccion + "__" + Ciudad + "__" + Provincia;
    }

    public event PropertyChangedEventHandler PropertyChanged;
    // Create the OnPropertyChanged method to raise the event
    // The calling member's name will be used as the parameter.
    protected void OnPropertyChanged([CallerMemberName] string name = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
